﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Other_Transaction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rdcredit = New System.Windows.Forms.RadioButton
        Me.rddebit = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.dt = New System.Windows.Forms.DateTimePicker
        Me.txtdes = New System.Windows.Forms.TextBox
        Me.txtamt = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.butok = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'rdcredit
        '
        Me.rdcredit.AutoSize = True
        Me.rdcredit.Checked = True
        Me.rdcredit.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdcredit.Location = New System.Drawing.Point(28, 40)
        Me.rdcredit.Name = "rdcredit"
        Me.rdcredit.Size = New System.Drawing.Size(68, 21)
        Me.rdcredit.TabIndex = 0
        Me.rdcredit.TabStop = True
        Me.rdcredit.Text = "Credit"
        Me.rdcredit.UseVisualStyleBackColor = True
        '
        'rddebit
        '
        Me.rddebit.AutoSize = True
        Me.rddebit.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rddebit.Location = New System.Drawing.Point(173, 40)
        Me.rddebit.Name = "rddebit"
        Me.rddebit.Size = New System.Drawing.Size(62, 21)
        Me.rddebit.TabIndex = 1
        Me.rddebit.TabStop = True
        Me.rddebit.Text = "Debit"
        Me.rddebit.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dt)
        Me.GroupBox1.Controls.Add(Me.txtdes)
        Me.GroupBox1.Controls.Add(Me.txtamt)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(28, 100)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(307, 148)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        '
        'dt
        '
        Me.dt.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dt.Location = New System.Drawing.Point(128, 24)
        Me.dt.Name = "dt"
        Me.dt.Size = New System.Drawing.Size(121, 25)
        Me.dt.TabIndex = 6
        '
        'txtdes
        '
        Me.txtdes.Location = New System.Drawing.Point(128, 101)
        Me.txtdes.Name = "txtdes"
        Me.txtdes.Size = New System.Drawing.Size(121, 25)
        Me.txtdes.TabIndex = 5
        '
        'txtamt
        '
        Me.txtamt.Location = New System.Drawing.Point(128, 62)
        Me.txtamt.Name = "txtamt"
        Me.txtamt.Size = New System.Drawing.Size(121, 25)
        Me.txtamt.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 101)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(84, 17)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Description"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(60, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Amount"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Date"
        '
        'butok
        '
        Me.butok.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butok.Location = New System.Drawing.Point(136, 278)
        Me.butok.Name = "butok"
        Me.butok.Size = New System.Drawing.Size(75, 45)
        Me.butok.TabIndex = 3
        Me.butok.Text = "OK"
        Me.butok.UseVisualStyleBackColor = True
        '
        'Other_Transaction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.IndianRed
        Me.ClientSize = New System.Drawing.Size(434, 335)
        Me.Controls.Add(Me.butok)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.rddebit)
        Me.Controls.Add(Me.rdcredit)
        Me.Name = "Other_Transaction"
        Me.Text = "Other_Transaction"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents rdcredit As System.Windows.Forms.RadioButton
    Friend WithEvents rddebit As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents dt As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtdes As System.Windows.Forms.TextBox
    Friend WithEvents txtamt As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents butok As System.Windows.Forms.Button
End Class
