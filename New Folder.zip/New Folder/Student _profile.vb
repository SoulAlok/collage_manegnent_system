﻿
Imports System.Data.SqlClient

Public Class Student_Profile
    Public gender

    Sub opt()
        If rdmale.Checked = True Then
            gender = "Male"
        Else
            gender = "Female"
        End If

    End Sub

    Private Sub stdadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stdadd.Click
        'connection_close()
        connection_open()
        qry = " insert into Tbl_std1(Adno,Name,Gender,DOB,Course,Class,Religion,Cast_grp,Prev_coll,Tc_no,Tc_date,Year_Admin,Parent_name,Qualification,Occupation,Phone,Mobile,Email,Address,Annual_Income,Status) values (" & txtadno.Text & " ,' " & txtname.Text & " ', '" & gender & "' ,' " & dt1.Value & " ','" & cmbcourse.Text & " '," & cmbclass.Text & ",'" & txtrelegion.Text & "','" & cmbcast.Text & "','" & txtcoll.Text & " '," & txttcno.Text & ",' " & dt2.Text & " ',' " & dtadminyr.Text & " ',' " & txtparent.Text & " ',' " & txtqua.Text & " ',' " & txtocc.Text & " '," & txtphone.Text & "," & txtmobile.Text & ",' " & txtemail.Text & " ',' " & txtadd.Text & "'," & txtincome.Text & ",'" & cmbstatus.Text & "')"
        If txtadno.Text = "" Then
            MsgBox("Enter Admission No", MsgBoxStyle.Information, "Fields")
        Else
            Dim dr1 As SqlDataReader '
            Dim qry1 As String
            Dim cmd1 As SqlCommand
            qry1 = "select * from Tbl_std1 where Adno=" & txtadno.Text & " "
            cmd1 = New SqlCommand(qry1, cnn)
            dr1 = cmd1.ExecuteReader()
            If dr1.Read = False Then
                cmd = New SqlCommand(qry, cnn)
                dr1.Close()
                cmd.ExecuteNonQuery()
                MsgBox("Successfully Entered into the DataBase", MsgBoxStyle.MsgBoxRight, "Office Automation")
                ds.Clear()
                qry = "select * from Tbl_std1 where status ='False' and Course='" & cmbcourse.Text & "' and Class=" & cmbclass.Text & ""
                adp = New SqlDataAdapter(qry, cnn)
                adp.Fill(ds, "Tbl_std1")
                Grid.DataSource = ds
                Grid.DataMember = ds.Tables(0).ToString
                connection_close()
            Else
                MsgBox("Record Exists", MsgBoxStyle.Information, "Office Automation")
            End If
        End If
        connection_close()
    End Sub

    Private Sub stddelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles stddelete.Click
        opt()
        'connection_close()
        connection_open()
        qry = " Update Tbl_std1 set status='True' where Adno='" & txtadno.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        cmd.ExecuteNonQuery()
        MsgBox("Record Deleted Successfully", MsgBoxStyle.MsgBoxRight, "Office Automation")

        ds.Clear()

        'grid fill
        ds.Clear()

        qry = "select * from Tbl_std1 where status ='false'"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_std1")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()


    End Sub


    Private Sub butreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butreset.Click

        txtadno.Text = ""
        txtname.Text = ""
        txtcoll.Text = ""
        txttcno.Text = ""
        txtparent.Text = ""
        txtqua.Text = ""
        txtocc.Text = ""
        txtphone.Text = ""
        txtmobile.Text = ""
        txtemail.Text = ""
        txtadd.Text = ""
        admno()

    End Sub

    Private Sub butupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butupdate.Click

        opt()
        ' connection_close()
        connection_open()

        qry1 = "update Tbl_std1 set Name='" & txtname.Text & "',Gender='" & gender & "' ,DOB='" & dt1.Value & "',Course='" & cmbcourse.Text & "',Class=" & cmbclass.Text & ",Religion='" & txtrelegion.Text & "', Cast_grp='" & cmbcast.Text & "',Prev_coll='" & txtcoll.Text & "',Tc_no=" & txttcno.Text & ",Tc_date= '" & dt2.Value & "',Year_Admin='" & dtadminyr.Value & "',Parent_name='" & txtparent.Text & "',Qualification='" & txtqua.Text & "',Occupation='" & txtocc.Text & "',Phone=" & txtphone.Text & ",Mobile=" & txtmobile.Text & ",Email='" & txtemail.Text & "',Address='" & txtadd.Text & " ',Annual_Income=" & txtincome.Text & ",Status='" & cmbstatus.Text & "' where Adno=" & txtadno.Text & ""
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()
        'grid fill
        qry = "select * from Tbl_std1 where Status='false'"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_std1")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub
    Private Sub error__free_Student_profile_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ds.Clear()
        opt()
        admno()
        cmbcourse.Refresh()
        load_course()
        'connection_close()
        connection_open()
        txtadno.Focus()
        qry = "select * from Tbl_std1 where status ='False'"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_std1")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub


    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        Dim a
        a = Grid.CurrentRow.Index
        txtadno.Text = Grid.Item(0, a).Value
        txtname.Text = Grid.Item(1, a).Value
        gender = Grid.Item(2, a).Value
        dt1.Value = Grid.Item(3, a).Value
        cmbcourse.Text = Grid.Item(4, a).Value
        cmbclass.Text = Grid.Item(5, a).Value
        txtrelegion.Text = Grid.Item(6, a).Value
        cmbcast.Text = Grid.Item(7, a).Value
        txtcoll.Text = Grid.Item(8, a).Value
        txttcno.Text = Grid.Item(9, a).Value
        dt2.Value = Grid.Item(10, a).Value
        dtadminyr.Value = Grid.Item(11, a).Value
        txtparent.Text = Grid.Item(12, a).Value
        txtqua.Text = Grid.Item(13, a).Value
        txtocc.Text = Grid.Item(14, a).Value
        txtphone.Text = Grid.Item(15, a).Value
        txtmobile.Text = Grid.Item(16, a).Value
        txtemail.Text = Grid.Item(17, a).Value
        txtadd.Text = Grid.Item(18, a).Value
        txtincome.Text = Grid.Item(19, a).Value
        cmbstatus.Text = Grid.Item(20, a).Value



    End Sub

    Private Sub ln_hidden_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles ln_hidden.LinkClicked
        Student_hidden_records.Show()

    End Sub
    Sub load_course()

        ' connection_close()
        connection_open()

        qry = "select distinct(C_Name) from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)

        End While

        connection_close()
    End Sub


    Private Sub btview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btview.Click
        ' connection_close()
        connection_open()
        opt()
        cmbcourse.Refresh()
        load_course()

        ds.Clear()
        qry = "select * from Tbl_std1 where status ='False' and Course='" & cmbcourse.Text & "' and Class=" & cmbclass.Text & ""
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_std1")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub


    Sub admno()
        'connection_close()
        connection_open()
        qry = "Select * from Tbl_std1"
        Try
            cmd = New SqlCommand(qry, cnn)
            dr = cmd.ExecuteReader()
            While dr.Read()
                txtadno.Text = dr.Item(0) + 1
            End While
            dr.Close()
            cmd.Dispose()
        Catch ex As Exception
            MsgBox("Invalid Userid! ")
        End Try
        connection_close()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click

        connection_open()

        If rd1.Checked = True Then
            updateclass1()
            ds.Clear()
            qry = "Select * from Tbl_std1 where Class='2'"
            adp = New SqlDataAdapter(qry, cnn)
            adp.Fill(ds, "Tbl_std1")
            Grid.DataSource = ds
            Grid.DataMember = ds.Tables(0).ToString
            connection_close()
        ElseIf rd2.Checked = True Then
            updateclass2()
            ds.Clear()
            qry = "Select * from Tbl_std1 where Class='3'"
            adp = New SqlDataAdapter(qry, cnn)
            adp.Fill(ds, "Tbl_std1")
            Grid.DataSource = ds
            Grid.DataMember = ds.Tables(0).ToString
            connection_close()
        ElseIf rd3.Checked = True Then
            updateclass3()
            ds.Clear()
            qry = "Select * from Tbl_std1 where status='True'"
            adp = New SqlDataAdapter(qry, cnn)
            adp.Fill(ds, "Tbl_std1")
            Grid.DataSource = ds
            Grid.DataMember = ds.Tables(0).ToString
            connection_close()
        End If


        connection_close()


    End Sub

    Public Sub updateclass1()
        'connection_close()
        connection_open()
        qry = "update Tbl_std1 set Class='2' where Class='1'"
        cmd = New SqlCommand(qry, cnn)
        cmd.ExecuteNonQuery()
        connection_close()
    End Sub
    Public Sub updateclass2()
        'connection_close()
        connection_open()
        qry = "update Tbl_std1 set Class='3' where Class='2'"
        cmd = New SqlCommand(qry, cnn)
        cmd.ExecuteNonQuery()
        connection_close()
    End Sub
    Public Sub updateclass3()
        ' connection_close()
        connection_open()
        qry = "update Tbl_std1 set Status='True' where Class='3'"
        cmd = New SqlCommand(qry, cnn)
        cmd.ExecuteNonQuery()
        connection_close()
    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub txtname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    
    Private Sub txtrelegion_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtrelegion.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtrelegion.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtcoll_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtcoll.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtcoll.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtparent_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtparent.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtparent.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtqua_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtqua.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtqua.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtocc_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtocc.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtocc.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtadd_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtadd.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtadd.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

   

    
    Private Sub txtincome_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtincome.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtincome.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtmobile_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtmobile.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtmobile.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

 
    Private Sub txtphone_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtphone.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtphone.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txttcno_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttcno.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txttcno.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub


    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        MDIParent1.Show()
    End Sub

    Private Sub Label22_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label22.Click
        lbupdate.Visible = True
    End Sub

    Private Sub lbupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lbupdate.Click
        grp3.Visible = True
        rd1.Visible = True
        rd2.Visible = True
        rd3.Visible = True
        btnok.Visible = True
    End Sub
End Class

