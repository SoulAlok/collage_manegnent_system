﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MDIParent1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.StatusStrip = New System.Windows.Forms.StatusStrip
        Me.ToolStripStatusLabel = New System.Windows.Forms.ToolStripStatusLabel
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem
        Me.DepartmentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CourseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem4 = New System.Windows.Forms.ToolStripMenuItem
        Me.FeesDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StudentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ProfileEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EditingRollNoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OtherDetailsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ResultEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StaffToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.TransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StudentTransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeTransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.OtherTransactionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ScholarshipPaymentToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.StudentInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ClasswiseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.CourseWiseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.CastGroupWiseToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ScholarshipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.FeesPaymentInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeInformationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.DepartmentwiseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem
        Me.ReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.StudentToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.ResultReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.EmployeeToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem
        Me.SalaryReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem5 = New System.Windows.Forms.ToolStripMenuItem
        Me.ToolStripMenuItem6 = New System.Windows.Forms.ToolStripMenuItem
        Me.StatusStrip.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'StatusStrip
        '
        Me.StatusStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel})
        Me.StatusStrip.Location = New System.Drawing.Point(0, 598)
        Me.StatusStrip.Name = "StatusStrip"
        Me.StatusStrip.Size = New System.Drawing.Size(914, 22)
        Me.StatusStrip.TabIndex = 7
        Me.StatusStrip.Text = "StatusStrip"
        '
        'ToolStripStatusLabel
        '
        Me.ToolStripStatusLabel.Name = "ToolStripStatusLabel"
        Me.ToolStripStatusLabel.Size = New System.Drawing.Size(39, 17)
        Me.ToolStripStatusLabel.Text = "Status"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.White
        Me.MenuStrip1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem2, Me.StudentToolStripMenuItem, Me.EmployeeToolStripMenuItem, Me.TransactionToolStripMenuItem, Me.ToolStripMenuItem1, Me.ReportToolStripMenuItem, Me.ToolStripMenuItem5, Me.ToolStripMenuItem6})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Padding = New System.Windows.Forms.Padding(11, 4, 0, 4)
        Me.MenuStrip1.Size = New System.Drawing.Size(914, 34)
        Me.MenuStrip1.TabIndex = 10
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DepartmentToolStripMenuItem, Me.CourseToolStripMenuItem, Me.ToolStripMenuItem4, Me.FeesDetailsToolStripMenuItem})
        Me.ToolStripMenuItem2.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem2.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(81, 26)
        Me.ToolStripMenuItem2.Text = "Master"
        '
        'DepartmentToolStripMenuItem
        '
        Me.DepartmentToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.DepartmentToolStripMenuItem.Name = "DepartmentToolStripMenuItem"
        Me.DepartmentToolStripMenuItem.Size = New System.Drawing.Size(180, 26)
        Me.DepartmentToolStripMenuItem.Text = "Department"
        '
        'CourseToolStripMenuItem
        '
        Me.CourseToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.CourseToolStripMenuItem.Name = "CourseToolStripMenuItem"
        Me.CourseToolStripMenuItem.Size = New System.Drawing.Size(180, 26)
        Me.CourseToolStripMenuItem.Text = "Course"
        '
        'ToolStripMenuItem4
        '
        Me.ToolStripMenuItem4.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripMenuItem4.Name = "ToolStripMenuItem4"
        Me.ToolStripMenuItem4.Size = New System.Drawing.Size(180, 26)
        Me.ToolStripMenuItem4.Text = "Scholarship"
        '
        'FeesDetailsToolStripMenuItem
        '
        Me.FeesDetailsToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.FeesDetailsToolStripMenuItem.Name = "FeesDetailsToolStripMenuItem"
        Me.FeesDetailsToolStripMenuItem.Size = New System.Drawing.Size(180, 26)
        Me.FeesDetailsToolStripMenuItem.Text = "Fees Details"
        '
        'StudentToolStripMenuItem
        '
        Me.StudentToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProfileEntryToolStripMenuItem, Me.EditingRollNoToolStripMenuItem, Me.OtherDetailsToolStripMenuItem, Me.ResultEntryToolStripMenuItem})
        Me.StudentToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.StudentToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.StudentToolStripMenuItem.Name = "StudentToolStripMenuItem"
        Me.StudentToolStripMenuItem.Size = New System.Drawing.Size(84, 26)
        Me.StudentToolStripMenuItem.Text = "Student"
        '
        'ProfileEntryToolStripMenuItem
        '
        Me.ProfileEntryToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.ProfileEntryToolStripMenuItem.Name = "ProfileEntryToolStripMenuItem"
        Me.ProfileEntryToolStripMenuItem.Size = New System.Drawing.Size(267, 26)
        Me.ProfileEntryToolStripMenuItem.Text = "Profile Entry"
        '
        'EditingRollNoToolStripMenuItem
        '
        Me.EditingRollNoToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.EditingRollNoToolStripMenuItem.Name = "EditingRollNoToolStripMenuItem"
        Me.EditingRollNoToolStripMenuItem.Size = New System.Drawing.Size(267, 26)
        Me.EditingRollNoToolStripMenuItem.Text = "Register number Entry"
        '
        'OtherDetailsToolStripMenuItem
        '
        Me.OtherDetailsToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.OtherDetailsToolStripMenuItem.Name = "OtherDetailsToolStripMenuItem"
        Me.OtherDetailsToolStripMenuItem.Size = New System.Drawing.Size(267, 26)
        Me.OtherDetailsToolStripMenuItem.Text = "Other Details"
        '
        'ResultEntryToolStripMenuItem
        '
        Me.ResultEntryToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.ResultEntryToolStripMenuItem.Name = "ResultEntryToolStripMenuItem"
        Me.ResultEntryToolStripMenuItem.Size = New System.Drawing.Size(267, 26)
        Me.ResultEntryToolStripMenuItem.Text = "Internal Marks Entry"
        '
        'EmployeeToolStripMenuItem
        '
        Me.EmployeeToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StaffToolStripMenuItem})
        Me.EmployeeToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EmployeeToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.EmployeeToolStripMenuItem.Name = "EmployeeToolStripMenuItem"
        Me.EmployeeToolStripMenuItem.Size = New System.Drawing.Size(102, 26)
        Me.EmployeeToolStripMenuItem.Text = "Employee"
        '
        'StaffToolStripMenuItem
        '
        Me.StaffToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.StaffToolStripMenuItem.Name = "StaffToolStripMenuItem"
        Me.StaffToolStripMenuItem.Size = New System.Drawing.Size(186, 26)
        Me.StaffToolStripMenuItem.Text = "Profile Entry"
        '
        'TransactionToolStripMenuItem
        '
        Me.TransactionToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentTransactionToolStripMenuItem, Me.EmployeeTransactionToolStripMenuItem, Me.OtherTransactionToolStripMenuItem, Me.ScholarshipPaymentToolStripMenuItem})
        Me.TransactionToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TransactionToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.TransactionToolStripMenuItem.Name = "TransactionToolStripMenuItem"
        Me.TransactionToolStripMenuItem.Size = New System.Drawing.Size(120, 26)
        Me.TransactionToolStripMenuItem.Text = "Transaction"
        '
        'StudentTransactionToolStripMenuItem
        '
        Me.StudentTransactionToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.StudentTransactionToolStripMenuItem.Name = "StudentTransactionToolStripMenuItem"
        Me.StudentTransactionToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.StudentTransactionToolStripMenuItem.Text = "Fees Payment"
        '
        'EmployeeTransactionToolStripMenuItem
        '
        Me.EmployeeTransactionToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.EmployeeTransactionToolStripMenuItem.Name = "EmployeeTransactionToolStripMenuItem"
        Me.EmployeeTransactionToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.EmployeeTransactionToolStripMenuItem.Text = "Employee Salary "
        '
        'OtherTransactionToolStripMenuItem
        '
        Me.OtherTransactionToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.OtherTransactionToolStripMenuItem.Name = "OtherTransactionToolStripMenuItem"
        Me.OtherTransactionToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.OtherTransactionToolStripMenuItem.Text = "Other Transaction"
        '
        'ScholarshipPaymentToolStripMenuItem
        '
        Me.ScholarshipPaymentToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.ScholarshipPaymentToolStripMenuItem.Name = "ScholarshipPaymentToolStripMenuItem"
        Me.ScholarshipPaymentToolStripMenuItem.Size = New System.Drawing.Size(252, 26)
        Me.ScholarshipPaymentToolStripMenuItem.Text = "Scholarship Payment"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentInformationToolStripMenuItem, Me.EmployeeInformationToolStripMenuItem, Me.ToolStripMenuItem3})
        Me.ToolStripMenuItem1.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem1.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(79, 26)
        Me.ToolStripMenuItem1.Text = "Search"
        '
        'StudentInformationToolStripMenuItem
        '
        Me.StudentInformationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ClasswiseToolStripMenuItem, Me.CourseWiseToolStripMenuItem1, Me.CastGroupWiseToolStripMenuItem1, Me.ScholarshipToolStripMenuItem, Me.FeesPaymentInformationToolStripMenuItem})
        Me.StudentInformationToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.StudentInformationToolStripMenuItem.Name = "StudentInformationToolStripMenuItem"
        Me.StudentInformationToolStripMenuItem.Size = New System.Drawing.Size(315, 26)
        Me.StudentInformationToolStripMenuItem.Text = "Student Information"
        '
        'ClasswiseToolStripMenuItem
        '
        Me.ClasswiseToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.ClasswiseToolStripMenuItem.Name = "ClasswiseToolStripMenuItem"
        Me.ClasswiseToolStripMenuItem.Size = New System.Drawing.Size(314, 26)
        Me.ClasswiseToolStripMenuItem.Text = "Classwise"
        '
        'CourseWiseToolStripMenuItem1
        '
        Me.CourseWiseToolStripMenuItem1.ForeColor = System.Drawing.Color.Blue
        Me.CourseWiseToolStripMenuItem1.Name = "CourseWiseToolStripMenuItem1"
        Me.CourseWiseToolStripMenuItem1.Size = New System.Drawing.Size(314, 26)
        Me.CourseWiseToolStripMenuItem1.Text = "Course wise"
        '
        'CastGroupWiseToolStripMenuItem1
        '
        Me.CastGroupWiseToolStripMenuItem1.ForeColor = System.Drawing.Color.Blue
        Me.CastGroupWiseToolStripMenuItem1.Name = "CastGroupWiseToolStripMenuItem1"
        Me.CastGroupWiseToolStripMenuItem1.Size = New System.Drawing.Size(314, 26)
        Me.CastGroupWiseToolStripMenuItem1.Text = "Cast group wise"
        '
        'ScholarshipToolStripMenuItem
        '
        Me.ScholarshipToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.ScholarshipToolStripMenuItem.Name = "ScholarshipToolStripMenuItem"
        Me.ScholarshipToolStripMenuItem.Size = New System.Drawing.Size(314, 26)
        Me.ScholarshipToolStripMenuItem.Text = "Scholarship Payment Details"
        '
        'FeesPaymentInformationToolStripMenuItem
        '
        Me.FeesPaymentInformationToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.FeesPaymentInformationToolStripMenuItem.Name = "FeesPaymentInformationToolStripMenuItem"
        Me.FeesPaymentInformationToolStripMenuItem.Size = New System.Drawing.Size(314, 26)
        Me.FeesPaymentInformationToolStripMenuItem.Text = "Fees Payment information"
        '
        'EmployeeInformationToolStripMenuItem
        '
        Me.EmployeeInformationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.DepartmentwiseToolStripMenuItem})
        Me.EmployeeInformationToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.EmployeeInformationToolStripMenuItem.Name = "EmployeeInformationToolStripMenuItem"
        Me.EmployeeInformationToolStripMenuItem.Size = New System.Drawing.Size(315, 26)
        Me.EmployeeInformationToolStripMenuItem.Text = "Employee Information"
        '
        'DepartmentwiseToolStripMenuItem
        '
        Me.DepartmentwiseToolStripMenuItem.Name = "DepartmentwiseToolStripMenuItem"
        Me.DepartmentwiseToolStripMenuItem.Size = New System.Drawing.Size(213, 26)
        Me.DepartmentwiseToolStripMenuItem.Text = "Departmentwise"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(315, 26)
        Me.ToolStripMenuItem3.Text = "College Account Information"
        '
        'ReportToolStripMenuItem
        '
        Me.ReportToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.StudentToolStripMenuItem1, Me.EmployeeToolStripMenuItem1})
        Me.ReportToolStripMenuItem.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ReportToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.ReportToolStripMenuItem.Name = "ReportToolStripMenuItem"
        Me.ReportToolStripMenuItem.Size = New System.Drawing.Size(79, 26)
        Me.ReportToolStripMenuItem.Text = "Report"
        '
        'StudentToolStripMenuItem1
        '
        Me.StudentToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ResultReportToolStripMenuItem})
        Me.StudentToolStripMenuItem1.ForeColor = System.Drawing.Color.Blue
        Me.StudentToolStripMenuItem1.Name = "StudentToolStripMenuItem1"
        Me.StudentToolStripMenuItem1.Size = New System.Drawing.Size(160, 26)
        Me.StudentToolStripMenuItem1.Text = "Student"
        '
        'ResultReportToolStripMenuItem
        '
        Me.ResultReportToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.ResultReportToolStripMenuItem.Name = "ResultReportToolStripMenuItem"
        Me.ResultReportToolStripMenuItem.Size = New System.Drawing.Size(197, 26)
        Me.ResultReportToolStripMenuItem.Text = "Marks Report"
        '
        'EmployeeToolStripMenuItem1
        '
        Me.EmployeeToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SalaryReportToolStripMenuItem})
        Me.EmployeeToolStripMenuItem1.ForeColor = System.Drawing.Color.Blue
        Me.EmployeeToolStripMenuItem1.Name = "EmployeeToolStripMenuItem1"
        Me.EmployeeToolStripMenuItem1.Size = New System.Drawing.Size(160, 26)
        Me.EmployeeToolStripMenuItem1.Text = "Employee"
        '
        'SalaryReportToolStripMenuItem
        '
        Me.SalaryReportToolStripMenuItem.ForeColor = System.Drawing.Color.Blue
        Me.SalaryReportToolStripMenuItem.Name = "SalaryReportToolStripMenuItem"
        Me.SalaryReportToolStripMenuItem.Size = New System.Drawing.Size(195, 26)
        Me.SalaryReportToolStripMenuItem.Text = "Salary Report"
        '
        'ToolStripMenuItem5
        '
        Me.ToolStripMenuItem5.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem5.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripMenuItem5.Name = "ToolStripMenuItem5"
        Me.ToolStripMenuItem5.Size = New System.Drawing.Size(170, 26)
        Me.ToolStripMenuItem5.Text = "Change Password"
        '
        'ToolStripMenuItem6
        '
        Me.ToolStripMenuItem6.Font = New System.Drawing.Font("Times New Roman", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripMenuItem6.ForeColor = System.Drawing.Color.Blue
        Me.ToolStripMenuItem6.Name = "ToolStripMenuItem6"
        Me.ToolStripMenuItem6.Size = New System.Drawing.Size(55, 26)
        Me.ToolStripMenuItem6.Text = "Exit"
        '
        'MDIParent1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(914, 620)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.StatusStrip)
        Me.IsMdiContainer = True
        Me.Name = "MDIParent1"
        Me.Text = "MDIParent1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip.ResumeLayout(False)
        Me.StatusStrip.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents ToolStripStatusLabel As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip As System.Windows.Forms.StatusStrip
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DepartmentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CourseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem4 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FeesDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ProfileEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditingRollNoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OtherDetailsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResultEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StaffToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentTransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeTransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OtherTransactionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScholarshipPaymentToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ClasswiseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CourseWiseToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CastGroupWiseToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ScholarshipToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FeesPaymentInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeInformationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DepartmentwiseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StudentToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ResultReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EmployeeToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SalaryReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem5 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem6 As System.Windows.Forms.ToolStripMenuItem

End Class
