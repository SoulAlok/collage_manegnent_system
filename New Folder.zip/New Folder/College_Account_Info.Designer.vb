﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class College_Account_Info
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.butcredit = New System.Windows.Forms.Button
        Me.butdebit = New System.Windows.Forms.Button
        Me.butamt = New System.Windows.Forms.Button
        Me.txtamt = New System.Windows.Forms.TextBox
        Me.Grid = New System.Windows.Forms.DataGridView
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'butcredit
        '
        Me.butcredit.Location = New System.Drawing.Point(106, 64)
        Me.butcredit.Margin = New System.Windows.Forms.Padding(4)
        Me.butcredit.Name = "butcredit"
        Me.butcredit.Size = New System.Drawing.Size(112, 34)
        Me.butcredit.TabIndex = 0
        Me.butcredit.Text = "Credit"
        Me.butcredit.UseVisualStyleBackColor = True
        '
        'butdebit
        '
        Me.butdebit.Location = New System.Drawing.Point(276, 64)
        Me.butdebit.Margin = New System.Windows.Forms.Padding(4)
        Me.butdebit.Name = "butdebit"
        Me.butdebit.Size = New System.Drawing.Size(112, 34)
        Me.butdebit.TabIndex = 1
        Me.butdebit.Text = "Debit"
        Me.butdebit.UseVisualStyleBackColor = True
        '
        'butamt
        '
        Me.butamt.Location = New System.Drawing.Point(440, 64)
        Me.butamt.Margin = New System.Windows.Forms.Padding(4)
        Me.butamt.Name = "butamt"
        Me.butamt.Size = New System.Drawing.Size(140, 34)
        Me.butamt.TabIndex = 2
        Me.butamt.Text = "Current Amount"
        Me.butamt.UseVisualStyleBackColor = True
        '
        'txtamt
        '
        Me.txtamt.Location = New System.Drawing.Point(467, 120)
        Me.txtamt.Name = "txtamt"
        Me.txtamt.Size = New System.Drawing.Size(100, 26)
        Me.txtamt.TabIndex = 3
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(67, 207)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(462, 209)
        Me.Grid.TabIndex = 4
        '
        'College_Account_Info
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(654, 538)
        Me.Controls.Add(Me.Grid)
        Me.Controls.Add(Me.txtamt)
        Me.Controls.Add(Me.butamt)
        Me.Controls.Add(Me.butdebit)
        Me.Controls.Add(Me.butcredit)
        Me.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "College_Account_Info"
        Me.Text = "College_Account_Info"
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents butcredit As System.Windows.Forms.Button
    Friend WithEvents butdebit As System.Windows.Forms.Button
    Friend WithEvents butamt As System.Windows.Forms.Button
    Friend WithEvents txtamt As System.Windows.Forms.TextBox
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
End Class
