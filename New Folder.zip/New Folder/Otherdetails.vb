﻿Imports System.Data.SqlClient
Public Class Otherdetails


    Private Sub othsclr_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        con.Open()
        qry = "select Schlor from Tbl_sc "
    End Sub

   
    Private Sub Otherdetails_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        course_load()
        scr_load()

    End Sub

    Private Sub LinkLabel2_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs)

        mainpage.BringToFront()

    End Sub
    Sub course_load()
        con.Open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, con)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)
        Loop
        con.Close()

    End Sub
   
    Private Sub cmbclass_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbclass.SelectedIndexChanged
        con.Open()


        qry = "select regno,name from Tbl_reg_no where course='" & cmbcourse.Text & "' and class=" & cmbclass.Text & ""

        adp = New SqlDataAdapter(qry, con)
        ds.Clear()
        adp.Fill(ds, "Tbl_reg_no")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        con.Close()
    End Sub

   

    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick

        con.Open()
        Dim a
        a = Grid.CurrentRow.Index
        txtregno.Text = Grid.Item(0, a).Value.ToString
        txtname.Text = Grid.Item(1, a).Value.ToString
        con.Close()
    End Sub
    Sub scr_load()
        con.Open()
        qry = "select Name from Tbl_scr"
        cmd = New SqlCommand(qry, con)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbsclor.Items.Add(dr(0).ToString)
        Loop
        con.Close()
    End Sub
End Class