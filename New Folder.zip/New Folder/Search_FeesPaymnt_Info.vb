﻿Imports System.Data.SqlClient
Public Class Search_FeesPaymnt_Info

    
    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click

        connection_open()
        If rdpaid.Checked = True Then
            qry = "select * from Tbl_feespayment where pay_type='Complete' and course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
            adp = New SqlDataAdapter(qry, cnn)
            ds1.Clear()
            adp.Fill(ds, "Tbl_feespayment")

            Grid.DataSource = ds
            Grid.DataMember = ds.Tables(0).ToString
            connection_close()
        Else
            qry = "select regno,name,course,year from Tbl_feespayment where pay_type='Partial' and course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
            adp = New SqlDataAdapter(qry, cnn)
            ds.Clear()
            adp.Fill(ds1, "Tbl_feespayment")

            Grid.DataSource = ds1
            Grid.DataMember = ds1.Tables(0).ToString
            connection_close()
        End If

    End Sub
    Sub load_course()
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)

        Loop
        connection_close()
    End Sub

    Private Sub cmbcourse_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcourse.SelectedIndexChanged
        cmbcourse.Text = "----Select-----"
    End Sub

    Private Sub cmbclass_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbclass.SelectedIndexChanged
        cmbclass.Text = "-----Select-----"
    End Sub

    Private Sub Search_FeesPaymnt_Info_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_course()

    End Sub
End Class