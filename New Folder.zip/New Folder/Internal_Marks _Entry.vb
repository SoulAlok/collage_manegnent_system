﻿Imports System.Data.SqlClient

Public Class Internal_Marks__Entry

    Private Sub Internal_Marks__Entry_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_course()
        'load_subcode()

    End Sub
    Sub load_course()

        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)
        End While
        connection_close()
    End Sub

    Sub load_subcode()

        connection_open()
        qry = "select Subcode from Tbl_crs where C_Name='" & cmbcourse.Text & "' and Sem='" & cmbsem.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        While dr.Read = True
            cmbscode.Items.Add(dr(0).ToString)
        End While
        connection_close()
    End Sub

    Private Sub butOK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butOK.Click
        Panel2.Visible = False
        Gridview.Visible = False
        view1()
    End Sub

    Private Sub butsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butsave.Click
        'connection_close()
        connection_open()
        qry = "select * from Tbl_mark where regno=" & txtregno.Text & " and course='" & cmbcourse.Text & "' and sem='" & cmbsem.Text & "' and exam='" & cmbexam.Text & "' and subcode='" & cmbscode.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        If dr.Read = False Then
            dr.Close()
            qry = "insert into Tbl_mark (course,sem,exam,subcode,regno,name,min,max,Obtained) values('" & cmbcourse.Text & "','" & cmbsem.Text & "','" & cmbexam.Text & "','" & cmbscode.Text & "'," & txtregno.Text & ",'" & txtname.Text & "'," & txtmin.Text & "," & txtmax.Text & "," & txtobt.Text & ")"
            cmd = New SqlCommand(qry, cnn)
            cmd.ExecuteNonQuery()
            MsgBox("Record Entered Successfully", MsgBoxStyle.Information, "Office Automation")
            connection_close()
        Else
            MsgBox("Record already exists", MsgBoxStyle.Information, "Office Automation")
            cmbcourse.Focus()
            connection_close()
        End If
        connection_close()



    End Sub

    Private Sub cmbsem_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbsem.TextChanged
        cmbscode.Refresh()

        load_subcode()
    End Sub




    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        connection_open()
        Dim a
        a = Grid.CurrentRow.Index

        txtregno.Text = Grid.Item(0, a).Value.ToString
        txtname.Text = Grid.Item(1, a).Value.ToString

        connection_close()
    End Sub

    Private Sub resclear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles resclear.Click
        'ds.Tables(0).Clear()

        cmbcourse.Text = ""

        cmbsem.Text = ""
        cmbexam.Text = ""
        cmbscode.Text = ""
        cmbscode.Items.Clear()
        txtregno.Text = ""
        txtname.Text = ""
        txtmin.Text = ""
        txtmax.Text = ""
        txtobt.Text = ""
    End Sub



    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click

        Panel2.Visible = True
        Gridview.Visible = True

        connection_close()
        connection_open()

        qry1 = "update Tbl_mark set min=" & txtmin.Text & ",max=" & txtmax.Text & " ,Obtained=" & txtobt.Text & " where regno=" & txtregno.Text & " and subcode='" & cmbscode.Text & "'"
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()
        'grid fill
        'qry = "select * from Tbl_mark where regno=" & txtregno.Text & " and subcode='" & cmbscode.Text & "'"
        'adp = New SqlDataAdapter(qry, cnn)

        'adp.Fill(ds, "Tbl_mark")
        'Grid.DataSource = ds
        'Grid.DataMember = ds.Tables(0).ToString
        view2()
        connection_close()


    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Panel1.Visible = False
        Grid.Visible = False
        view2()
        

    End Sub


    Private Sub Gridview_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Gridview.DoubleClick
        connection_open()
        Dim a
        a = Gridview.CurrentRow.Index
        cmbcourse.Text = Gridview.Item(0, a).Value.ToString
        cmbsem.Text = Gridview.Item(1, a).Value.ToString
        cmbexam.Text = Gridview.Item(2, a).Value.ToString
        cmbscode.Text = Gridview.Item(3, a).Value.ToString
        txtregno.Text = Gridview.Item(4, a).Value.ToString
        txtname.Text = Gridview.Item(5, a).Value.ToString
        txtmin.Text = Gridview.Item(6, a).Value.ToString
        txtmax.Text = Gridview.Item(7, a).Value.ToString
        txtobt.Text = Gridview.Item(8, a).Value.ToString
        connection_close()
    End Sub
    Sub view1()
        ds.Clear()
        Panel1.Visible = True
        Grid.Visible = True
        connection_open()
        If cmbsem.Text = "ISem" Or cmbsem.Text = "IISem" Then
            qry = "select regNo,name from Tbl_Regno where course='" & cmbcourse.Text & "'and class='1'"
        ElseIf cmbsem.Text = "IIISem" Or cmbsem.Text = "IVSem" Then
            qry = "select regNo,name from Tbl_Regno where course='" & cmbcourse.Text & "'and class='2'"
        Else
            qry = "select regNo,name from Tbl_Regno where course='" & cmbcourse.Text & "'and class='3'"
        End If

        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_Regno")

        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub
    Sub view2()
        ds1.Clear()
        Panel2.Visible = True
        Gridview.Visible = True
        connection_open()
        ds1.Clear()
        qry = "select * from Tbl_mark where course='" & cmbcourse.Text & "' and exam='" & cmbexam.Text & "'"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds1, "Tbl_mark")
        Gridview.DataSource = ds1
        Gridview.DataMember = ds1.Tables(0).ToString
        connection_close()
    End Sub
End Class