﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class departmententry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtid = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.deptupdate = New System.Windows.Forms.Button
        Me.deptdelete = New System.Windows.Forms.Button
        Me.deptadd = New System.Windows.Forms.Button
        Me.deptrst = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnclose = New System.Windows.Forms.Button
        Me.dept_id = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Dept_name = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GroupBox1.SuspendLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Yellow
        Me.Label1.Location = New System.Drawing.Point(19, 50)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Department ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Yellow
        Me.Label2.Location = New System.Drawing.Point(19, 108)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(121, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Department Name"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(154, 50)
        Me.txtid.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(133, 23)
        Me.txtid.TabIndex = 4
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Maroon
        Me.GroupBox1.Controls.Add(Me.txtname)
        Me.GroupBox1.Controls.Add(Me.Grid)
        Me.GroupBox1.Controls.Add(Me.txtid)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.White
        Me.GroupBox1.Location = New System.Drawing.Point(12, 13)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(328, 350)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Department Details"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(154, 101)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(133, 23)
        Me.txtname.TabIndex = 11
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.dept_id, Me.Dept_name})
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.PapayaWhip
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Grid.DefaultCellStyle = DataGridViewCellStyle1
        Me.Grid.Location = New System.Drawing.Point(29, 168)
        Me.Grid.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(258, 163)
        Me.Grid.TabIndex = 10
        '
        'deptupdate
        '
        Me.deptupdate.BackColor = System.Drawing.Color.Snow
        Me.deptupdate.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deptupdate.ForeColor = System.Drawing.Color.Red
        Me.deptupdate.Location = New System.Drawing.Point(403, 293)
        Me.deptupdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.deptupdate.Name = "deptupdate"
        Me.deptupdate.Size = New System.Drawing.Size(87, 37)
        Me.deptupdate.TabIndex = 12
        Me.deptupdate.Text = "UPDATE"
        Me.deptupdate.UseVisualStyleBackColor = False
        '
        'deptdelete
        '
        Me.deptdelete.BackColor = System.Drawing.Color.Snow
        Me.deptdelete.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deptdelete.ForeColor = System.Drawing.Color.Red
        Me.deptdelete.Location = New System.Drawing.Point(534, 246)
        Me.deptdelete.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.deptdelete.Name = "deptdelete"
        Me.deptdelete.Size = New System.Drawing.Size(87, 39)
        Me.deptdelete.TabIndex = 9
        Me.deptdelete.Text = "DELETE"
        Me.deptdelete.UseVisualStyleBackColor = False
        '
        'deptadd
        '
        Me.deptadd.BackColor = System.Drawing.Color.Snow
        Me.deptadd.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deptadd.ForeColor = System.Drawing.Color.Red
        Me.deptadd.Location = New System.Drawing.Point(403, 246)
        Me.deptadd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.deptadd.Name = "deptadd"
        Me.deptadd.Size = New System.Drawing.Size(87, 39)
        Me.deptadd.TabIndex = 7
        Me.deptadd.Text = "ADD"
        Me.deptadd.UseVisualStyleBackColor = False
        '
        'deptrst
        '
        Me.deptrst.BackColor = System.Drawing.Color.White
        Me.deptrst.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deptrst.ForeColor = System.Drawing.Color.Red
        Me.deptrst.Location = New System.Drawing.Point(534, 293)
        Me.deptrst.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.deptrst.Name = "deptrst"
        Me.deptrst.Size = New System.Drawing.Size(87, 37)
        Me.deptrst.TabIndex = 2
        Me.deptrst.Text = "RESET"
        Me.deptrst.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.Teamwork_1_
        Me.PictureBox1.Location = New System.Drawing.Point(390, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(252, 195)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'btnclose
        '
        Me.btnclose.BackColor = System.Drawing.Color.White
        Me.btnclose.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclose.ForeColor = System.Drawing.Color.Red
        Me.btnclose.Location = New System.Drawing.Point(477, 337)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(75, 38)
        Me.btnclose.TabIndex = 13
        Me.btnclose.Text = "CLOSE"
        Me.btnclose.UseVisualStyleBackColor = False
        '
        'dept_id
        '
        Me.dept_id.HeaderText = "Dept_Id"
        Me.dept_id.Name = "dept_id"
        '
        'Dept_name
        '
        Me.Dept_name.HeaderText = "Dept_Name"
        Me.Dept_name.Name = "Dept_name"
        '
        'departmententry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Maroon
        Me.ClientSize = New System.Drawing.Size(673, 399)
        Me.Controls.Add(Me.btnclose)
        Me.Controls.Add(Me.deptupdate)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.deptrst)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.deptadd)
        Me.Controls.Add(Me.deptdelete)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Black
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "departmententry"
        Me.Text = "departmententry"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents deptdelete As System.Windows.Forms.Button
    Friend WithEvents deptadd As System.Windows.Forms.Button
    Friend WithEvents deptrst As System.Windows.Forms.Button
    Friend WithEvents deptupdate As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents btnclose As System.Windows.Forms.Button
    Friend WithEvents dept_id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dept_name As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
