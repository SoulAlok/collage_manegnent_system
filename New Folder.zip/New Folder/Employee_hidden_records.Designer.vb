﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Employee_hidden_records
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.linkback = New System.Windows.Forms.LinkLabel
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtid = New System.Windows.Forms.TextBox
        Me.GridRestore = New System.Windows.Forms.DataGridView
        Me.btrestore = New System.Windows.Forms.Button
        CType(Me.GridRestore, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'linkback
        '
        Me.linkback.AutoSize = True
        Me.linkback.Location = New System.Drawing.Point(12, 279)
        Me.linkback.Name = "linkback"
        Me.linkback.Size = New System.Drawing.Size(35, 13)
        Me.linkback.TabIndex = 0
        Me.linkback.TabStop = True
        Me.linkback.Text = "BACK"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(129, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(41, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Staff Id"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(266, 23)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(100, 20)
        Me.txtid.TabIndex = 2
        '
        'GridRestore
        '
        Me.GridRestore.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridRestore.Location = New System.Drawing.Point(27, 61)
        Me.GridRestore.Name = "GridRestore"
        Me.GridRestore.Size = New System.Drawing.Size(490, 150)
        Me.GridRestore.TabIndex = 3
        '
        'btrestore
        '
        Me.btrestore.Location = New System.Drawing.Point(163, 269)
        Me.btrestore.Name = "btrestore"
        Me.btrestore.Size = New System.Drawing.Size(75, 23)
        Me.btrestore.TabIndex = 4
        Me.btrestore.Text = "RESTORE"
        Me.btrestore.UseVisualStyleBackColor = True
        '
        'Employee_hidden_records
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(604, 311)
        Me.Controls.Add(Me.btrestore)
        Me.Controls.Add(Me.GridRestore)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.linkback)
        Me.Name = "Employee_hidden_records"
        Me.Text = "Employee_hidden_records"
        CType(Me.GridRestore, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents linkback As System.Windows.Forms.LinkLabel
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents GridRestore As System.Windows.Forms.DataGridView
    Friend WithEvents btrestore As System.Windows.Forms.Button
End Class
