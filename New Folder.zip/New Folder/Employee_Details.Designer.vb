﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Employee_Details
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.cmbdept = New System.Windows.Forms.ComboBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtexp = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.txtqua = New System.Windows.Forms.TextBox
        Me.doj = New System.Windows.Forms.DateTimePicker
        Me.txtdesg = New System.Windows.Forms.TextBox
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtper = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtid = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.txtfname = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtmob = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.label12 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.txttemp = New System.Windows.Forms.TextBox
        Me.txtphone = New System.Windows.Forms.TextBox
        Me.rdfemale = New System.Windows.Forms.RadioButton
        Me.rdmale = New System.Windows.Forms.RadioButton
        Me.Label14 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.cbstatus = New System.Windows.Forms.ComboBox
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Label22 = New System.Windows.Forms.Label
        Me.txtbasic = New System.Windows.Forms.TextBox
        Me.txtother = New System.Windows.Forms.TextBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.txtloan = New System.Windows.Forms.TextBox
        Me.txtfbf = New System.Windows.Forms.TextBox
        Me.txtgi = New System.Windows.Forms.TextBox
        Me.txtit = New System.Windows.Forms.TextBox
        Me.txtlic = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.btupdate = New System.Windows.Forms.Button
        Me.btdelete = New System.Windows.Forms.Button
        Me.btadd = New System.Windows.Forms.Button
        Me.btreset = New System.Windows.Forms.Button
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.btview = New System.Windows.Forms.Button
        Me.Staff_Id = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Staff_Name = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.F_Name = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Per_Address = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Temp_Address = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Phone_No = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Mobile_No = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Email_Id = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Gendr = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Qualification = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Experience = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Dt_of_Jn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Designation = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Department = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Basic = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.LIC = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.In_Tax = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Grp_Ins = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.FBF = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Loan = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Other_Ded = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.Location = New System.Drawing.Point(16, 11)
        Me.TabControl1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1066, 635)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.TabPage1.Controls.Add(Me.cmbdept)
        Me.TabPage1.Controls.Add(Me.Label21)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.Label14)
        Me.TabPage1.Controls.Add(Me.PictureBox1)
        Me.TabPage1.Controls.Add(Me.Grid)
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Location = New System.Drawing.Point(4, 26)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage1.Size = New System.Drawing.Size(1058, 605)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Profile Entry"
        '
        'cmbdept
        '
        Me.cmbdept.FormattingEnabled = True
        Me.cmbdept.Items.AddRange(New Object() {"All.."})
        Me.cmbdept.Location = New System.Drawing.Point(147, 11)
        Me.cmbdept.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cmbdept.Name = "cmbdept"
        Me.cmbdept.Size = New System.Drawing.Size(161, 25)
        Me.cmbdept.TabIndex = 79
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(803, 357)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(48, 17)
        Me.Label21.TabIndex = 76
        Me.Label21.Text = "Status"
        Me.Label21.Visible = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtexp)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.txtemail)
        Me.GroupBox2.Controls.Add(Me.txtqua)
        Me.GroupBox2.Controls.Add(Me.doj)
        Me.GroupBox2.Controls.Add(Me.txtdesg)
        Me.GroupBox2.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox2.Location = New System.Drawing.Point(388, 48)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox2.Size = New System.Drawing.Size(366, 379)
        Me.GroupBox2.TabIndex = 75
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Other Details"
        '
        'txtexp
        '
        Me.txtexp.Location = New System.Drawing.Point(204, 115)
        Me.txtexp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtexp.Name = "txtexp"
        Me.txtexp.Size = New System.Drawing.Size(153, 25)
        Me.txtexp.TabIndex = 70
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(10, 293)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(98, 19)
        Me.Label3.TabIndex = 45
        Me.Label3.Text = "Designation"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(8, 345)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(54, 19)
        Me.Label7.TabIndex = 52
        Me.Label7.Text = "Email"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(10, 136)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 19)
        Me.Label9.TabIndex = 54
        Me.Label9.Text = "Qualification"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.White
        Me.Label13.Location = New System.Drawing.Point(6, 245)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(147, 19)
        Me.Label13.TabIndex = 71
        Me.Label13.Text = "Year of Experience"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(8, 34)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(118, 19)
        Me.Label11.TabIndex = 55
        Me.Label11.Text = "Date of joining"
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(126, 334)
        Me.txtemail.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(231, 25)
        Me.txtemail.TabIndex = 59
        '
        'txtqua
        '
        Me.txtqua.Location = New System.Drawing.Point(200, 69)
        Me.txtqua.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtqua.Multiline = True
        Me.txtqua.Name = "txtqua"
        Me.txtqua.Size = New System.Drawing.Size(153, 25)
        Me.txtqua.TabIndex = 60
        '
        'doj
        '
        Me.doj.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.doj.Location = New System.Drawing.Point(200, 30)
        Me.doj.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.doj.Name = "doj"
        Me.doj.Size = New System.Drawing.Size(153, 25)
        Me.doj.TabIndex = 64
        '
        'txtdesg
        '
        Me.txtdesg.Location = New System.Drawing.Point(154, 245)
        Me.txtdesg.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtdesg.Name = "txtdesg"
        Me.txtdesg.Size = New System.Drawing.Size(204, 25)
        Me.txtdesg.TabIndex = 61
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtper)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.txtid)
        Me.GroupBox1.Controls.Add(Me.txtname)
        Me.GroupBox1.Controls.Add(Me.txtfname)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtmob)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.label12)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.txttemp)
        Me.GroupBox1.Controls.Add(Me.txtphone)
        Me.GroupBox1.Controls.Add(Me.rdfemale)
        Me.GroupBox1.Controls.Add(Me.rdmale)
        Me.GroupBox1.ForeColor = System.Drawing.Color.Blue
        Me.GroupBox1.Location = New System.Drawing.Point(1, 48)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(381, 379)
        Me.GroupBox1.TabIndex = 74
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personel Profile"
        '
        'txtper
        '
        Me.txtper.Location = New System.Drawing.Point(200, 175)
        Me.txtper.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtper.Name = "txtper"
        Me.txtper.Size = New System.Drawing.Size(153, 25)
        Me.txtper.TabIndex = 56
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(10, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(64, 19)
        Me.Label1.TabIndex = 43
        Me.Label1.Text = "Staff ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(10, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(85, 19)
        Me.Label2.TabIndex = 44
        Me.Label2.Text = "Staff name"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(198, 23)
        Me.txtid.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(153, 25)
        Me.txtid.TabIndex = 46
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(198, 61)
        Me.txtname.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(153, 25)
        Me.txtname.TabIndex = 47
        '
        'txtfname
        '
        Me.txtfname.Location = New System.Drawing.Point(200, 128)
        Me.txtfname.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtfname.Name = "txtfname"
        Me.txtfname.Size = New System.Drawing.Size(153, 25)
        Me.txtfname.TabIndex = 69
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(4, 185)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(156, 19)
        Me.Label4.TabIndex = 49
        Me.Label4.Text = " Permanent Address"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(10, 137)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 19)
        Me.Label10.TabIndex = 68
        Me.Label10.Text = "Father's Name"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(12, 228)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 19)
        Me.Label5.TabIndex = 50
        Me.Label5.Text = "Temporary Address"
        '
        'txtmob
        '
        Me.txtmob.Location = New System.Drawing.Point(200, 313)
        Me.txtmob.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtmob.Name = "txtmob"
        Me.txtmob.Size = New System.Drawing.Size(153, 25)
        Me.txtmob.TabIndex = 67
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(12, 278)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(77, 19)
        Me.Label6.TabIndex = 51
        Me.Label6.Text = "Phone no"
        '
        'label12
        '
        Me.label12.AutoSize = True
        Me.label12.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.label12.ForeColor = System.Drawing.Color.White
        Me.label12.Location = New System.Drawing.Point(15, 324)
        Me.label12.Name = "label12"
        Me.label12.Size = New System.Drawing.Size(63, 19)
        Me.label12.TabIndex = 66
        Me.label12.Text = "Mobile"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(13, 102)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(65, 19)
        Me.Label8.TabIndex = 53
        Me.Label8.Text = "Gender"
        '
        'txttemp
        '
        Me.txttemp.Location = New System.Drawing.Point(202, 217)
        Me.txttemp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txttemp.Name = "txttemp"
        Me.txttemp.Size = New System.Drawing.Size(153, 25)
        Me.txttemp.TabIndex = 57
        '
        'txtphone
        '
        Me.txtphone.Location = New System.Drawing.Point(200, 267)
        Me.txtphone.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(153, 25)
        Me.txtphone.TabIndex = 58
        '
        'rdfemale
        '
        Me.rdfemale.AutoSize = True
        Me.rdfemale.ForeColor = System.Drawing.Color.White
        Me.rdfemale.Location = New System.Drawing.Point(276, 102)
        Me.rdfemale.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdfemale.Name = "rdfemale"
        Me.rdfemale.Size = New System.Drawing.Size(77, 21)
        Me.rdfemale.TabIndex = 63
        Me.rdfemale.Text = "Female"
        Me.rdfemale.UseVisualStyleBackColor = True
        '
        'rdmale
        '
        Me.rdmale.AutoSize = True
        Me.rdmale.Checked = True
        Me.rdmale.ForeColor = System.Drawing.Color.White
        Me.rdmale.Location = New System.Drawing.Point(198, 102)
        Me.rdmale.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rdmale.Name = "rdmale"
        Me.rdmale.Size = New System.Drawing.Size(63, 21)
        Me.rdmale.TabIndex = 62
        Me.rdmale.TabStop = True
        Me.rdmale.Text = "Male"
        Me.rdmale.UseVisualStyleBackColor = True
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.White
        Me.Label14.Location = New System.Drawing.Point(24, 14)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(86, 17)
        Me.Label14.TabIndex = 72
        Me.Label14.Text = "Department"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.staff1
        Me.PictureBox1.Location = New System.Drawing.Point(782, 48)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(254, 292)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 65
        Me.PictureBox1.TabStop = False
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Staff_Id, Me.Staff_Name, Me.F_Name, Me.Per_Address, Me.Temp_Address, Me.Phone_No, Me.Mobile_No, Me.Email_Id, Me.Gendr, Me.Qualification, Me.Experience, Me.Dt_of_Jn, Me.Designation, Me.Department, Me.Basic, Me.LIC, Me.In_Tax, Me.Grp_Ins, Me.FBF, Me.Loan, Me.Other_Ded})
        Me.Grid.Location = New System.Drawing.Point(6, 435)
        Me.Grid.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Grid.Name = "Grid"
        Me.Grid.RowTemplate.Height = 24
        Me.Grid.Size = New System.Drawing.Size(1029, 167)
        Me.Grid.TabIndex = 48
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cbstatus)
        Me.Panel1.Enabled = False
        Me.Panel1.Location = New System.Drawing.Point(782, 352)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(254, 60)
        Me.Panel1.TabIndex = 78
        Me.Panel1.Visible = False
        '
        'cbstatus
        '
        Me.cbstatus.FormattingEnabled = True
        Me.cbstatus.Items.AddRange(New Object() {"True", "False"})
        Me.cbstatus.Location = New System.Drawing.Point(90, 11)
        Me.cbstatus.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.cbstatus.Name = "cbstatus"
        Me.cbstatus.Size = New System.Drawing.Size(161, 25)
        Me.cbstatus.TabIndex = 77
        Me.cbstatus.Visible = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.TabPage2.Controls.Add(Me.Label22)
        Me.TabPage2.Controls.Add(Me.txtbasic)
        Me.TabPage2.Controls.Add(Me.txtother)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.txtloan)
        Me.TabPage2.Controls.Add(Me.txtfbf)
        Me.TabPage2.Controls.Add(Me.txtgi)
        Me.TabPage2.Controls.Add(Me.txtit)
        Me.TabPage2.Controls.Add(Me.txtlic)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.Label16)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.PictureBox2)
        Me.TabPage2.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabPage2.Location = New System.Drawing.Point(4, 31)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.TabPage2.Size = New System.Drawing.Size(1058, 655)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Other Details"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Label22.Location = New System.Drawing.Point(24, 39)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(114, 23)
        Me.Label22.TabIndex = 15
        Me.Label22.Text = "Basic Salary"
        '
        'txtbasic
        '
        Me.txtbasic.Location = New System.Drawing.Point(269, 39)
        Me.txtbasic.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtbasic.Name = "txtbasic"
        Me.txtbasic.Size = New System.Drawing.Size(132, 30)
        Me.txtbasic.TabIndex = 14
        '
        'txtother
        '
        Me.txtother.Location = New System.Drawing.Point(269, 501)
        Me.txtother.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtother.Name = "txtother"
        Me.txtother.Size = New System.Drawing.Size(132, 30)
        Me.txtother.TabIndex = 13
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label20.Location = New System.Drawing.Point(24, 505)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(151, 23)
        Me.Label20.TabIndex = 12
        Me.Label20.Text = "Other Deduction"
        '
        'txtloan
        '
        Me.txtloan.Location = New System.Drawing.Point(269, 437)
        Me.txtloan.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtloan.Name = "txtloan"
        Me.txtloan.Size = New System.Drawing.Size(132, 30)
        Me.txtloan.TabIndex = 9
        '
        'txtfbf
        '
        Me.txtfbf.Location = New System.Drawing.Point(269, 359)
        Me.txtfbf.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtfbf.Name = "txtfbf"
        Me.txtfbf.Size = New System.Drawing.Size(132, 30)
        Me.txtfbf.TabIndex = 8
        '
        'txtgi
        '
        Me.txtgi.Location = New System.Drawing.Point(269, 267)
        Me.txtgi.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtgi.Name = "txtgi"
        Me.txtgi.Size = New System.Drawing.Size(132, 30)
        Me.txtgi.TabIndex = 7
        '
        'txtit
        '
        Me.txtit.Location = New System.Drawing.Point(269, 155)
        Me.txtit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtit.Name = "txtit"
        Me.txtit.Size = New System.Drawing.Size(132, 30)
        Me.txtit.TabIndex = 6
        '
        'txtlic
        '
        Me.txtlic.Location = New System.Drawing.Point(269, 91)
        Me.txtlic.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtlic.Name = "txtlic"
        Me.txtlic.Size = New System.Drawing.Size(132, 30)
        Me.txtlic.TabIndex = 5
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.Color.White
        Me.Label19.Location = New System.Drawing.Point(22, 437)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(61, 23)
        Me.Label19.TabIndex = 4
        Me.Label19.Text = "Loans"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.Color.White
        Me.Label18.Location = New System.Drawing.Point(22, 359)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(174, 23)
        Me.Label18.TabIndex = 3
        Me.Label18.Text = "Family Benifit Fund"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.Color.White
        Me.Label17.Location = New System.Drawing.Point(22, 267)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(151, 23)
        Me.Label17.TabIndex = 2
        Me.Label17.Text = "Group Insurance"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.White
        Me.Label16.Location = New System.Drawing.Point(22, 155)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(107, 23)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "Income Tax"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.White
        Me.Label15.Location = New System.Drawing.Point(24, 91)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(44, 23)
        Me.Label15.TabIndex = 0
        Me.Label15.Text = "LIC"
        '
        'PictureBox2
        '
        Me.PictureBox2.Location = New System.Drawing.Point(434, 4)
        Me.PictureBox2.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(595, 286)
        Me.PictureBox2.TabIndex = 10
        Me.PictureBox2.TabStop = False
        '
        'btupdate
        '
        Me.btupdate.BackColor = System.Drawing.Color.White
        Me.btupdate.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btupdate.ForeColor = System.Drawing.Color.Blue
        Me.btupdate.Location = New System.Drawing.Point(338, 649)
        Me.btupdate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btupdate.Name = "btupdate"
        Me.btupdate.Size = New System.Drawing.Size(115, 34)
        Me.btupdate.TabIndex = 37
        Me.btupdate.Text = "UPDATE"
        Me.btupdate.UseVisualStyleBackColor = False
        '
        'btdelete
        '
        Me.btdelete.BackColor = System.Drawing.Color.White
        Me.btdelete.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btdelete.ForeColor = System.Drawing.Color.Blue
        Me.btdelete.Location = New System.Drawing.Point(565, 650)
        Me.btdelete.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btdelete.Name = "btdelete"
        Me.btdelete.Size = New System.Drawing.Size(115, 34)
        Me.btdelete.TabIndex = 36
        Me.btdelete.Text = "DELETE"
        Me.btdelete.UseVisualStyleBackColor = False
        '
        'btadd
        '
        Me.btadd.BackColor = System.Drawing.Color.White
        Me.btadd.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btadd.ForeColor = System.Drawing.Color.Blue
        Me.btadd.Location = New System.Drawing.Point(215, 649)
        Me.btadd.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btadd.Name = "btadd"
        Me.btadd.Size = New System.Drawing.Size(115, 34)
        Me.btadd.TabIndex = 35
        Me.btadd.Text = "ADD"
        Me.btadd.UseVisualStyleBackColor = False
        '
        'btreset
        '
        Me.btreset.BackColor = System.Drawing.Color.White
        Me.btreset.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btreset.ForeColor = System.Drawing.Color.Blue
        Me.btreset.Location = New System.Drawing.Point(690, 650)
        Me.btreset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btreset.Name = "btreset"
        Me.btreset.Size = New System.Drawing.Size(115, 34)
        Me.btreset.TabIndex = 34
        Me.btreset.Text = "RESET"
        Me.btreset.UseVisualStyleBackColor = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(866, 741)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(110, 17)
        Me.LinkLabel1.TabIndex = 39
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Hidden Records"
        '
        'btview
        '
        Me.btview.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btview.ForeColor = System.Drawing.Color.Blue
        Me.btview.Location = New System.Drawing.Point(463, 650)
        Me.btview.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btview.Name = "btview"
        Me.btview.Size = New System.Drawing.Size(99, 34)
        Me.btview.TabIndex = 40
        Me.btview.Text = "VIEW"
        Me.btview.UseVisualStyleBackColor = True
        '
        'Staff_Id
        '
        Me.Staff_Id.HeaderText = "Staff_Id"
        Me.Staff_Id.Name = "Staff_Id"
        '
        'Staff_Name
        '
        Me.Staff_Name.HeaderText = "Staff_Name"
        Me.Staff_Name.Name = "Staff_Name"
        '
        'F_Name
        '
        Me.F_Name.HeaderText = "F_Name"
        Me.F_Name.Name = "F_Name"
        '
        'Per_Address
        '
        Me.Per_Address.HeaderText = "Per_Address"
        Me.Per_Address.Name = "Per_Address"
        '
        'Temp_Address
        '
        Me.Temp_Address.HeaderText = "Temp_Address"
        Me.Temp_Address.Name = "Temp_Address"
        '
        'Phone_No
        '
        Me.Phone_No.HeaderText = "Phone_No"
        Me.Phone_No.Name = "Phone_No"
        '
        'Mobile_No
        '
        Me.Mobile_No.HeaderText = "Mobile_No"
        Me.Mobile_No.Name = "Mobile_No"
        '
        'Email_Id
        '
        Me.Email_Id.HeaderText = "Email_Id"
        Me.Email_Id.Name = "Email_Id"
        '
        'Gendr
        '
        Me.Gendr.HeaderText = "Gender"
        Me.Gendr.Name = "Gendr"
        '
        'Qualification
        '
        Me.Qualification.HeaderText = "Qualification"
        Me.Qualification.Name = "Qualification"
        '
        'Experience
        '
        Me.Experience.HeaderText = "Experience"
        Me.Experience.Name = "Experience"
        '
        'Dt_of_Jn
        '
        Me.Dt_of_Jn.HeaderText = "DOJ"
        Me.Dt_of_Jn.Name = "Dt_of_Jn"
        '
        'Designation
        '
        Me.Designation.HeaderText = "Designation"
        Me.Designation.Name = "Designation"
        '
        'Department
        '
        Me.Department.HeaderText = "Department"
        Me.Department.Name = "Department"
        '
        'Basic
        '
        Me.Basic.HeaderText = "Basic"
        Me.Basic.Name = "Basic"
        '
        'LIC
        '
        Me.LIC.HeaderText = "LIC"
        Me.LIC.Name = "LIC"
        '
        'In_Tax
        '
        Me.In_Tax.HeaderText = "Income_Tax"
        Me.In_Tax.Name = "In_Tax"
        '
        'Grp_Ins
        '
        Me.Grp_Ins.HeaderText = "Group_Insurence"
        Me.Grp_Ins.Name = "Grp_Ins"
        '
        'FBF
        '
        Me.FBF.HeaderText = "Family_Benifit_Fund"
        Me.FBF.Name = "FBF"
        '
        'Loan
        '
        Me.Loan.HeaderText = "Loan"
        Me.Loan.Name = "Loan"
        '
        'Other_Ded
        '
        Me.Other_Ded.HeaderText = "Other_Deduction"
        Me.Other_Ded.Name = "Other_Ded"
        '
        'Employee_Details
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1098, 690)
        Me.Controls.Add(Me.btview)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.btupdate)
        Me.Controls.Add(Me.btdelete)
        Me.Controls.Add(Me.btadd)
        Me.Controls.Add(Me.btreset)
        Me.Controls.Add(Me.TabControl1)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "Employee_Details"
        Me.Text = "Employee_Details"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtexp As System.Windows.Forms.TextBox
    Friend WithEvents txtfname As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtmob As System.Windows.Forms.TextBox
    Friend WithEvents label12 As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents doj As System.Windows.Forms.DateTimePicker
    Friend WithEvents rdfemale As System.Windows.Forms.RadioButton
    Friend WithEvents rdmale As System.Windows.Forms.RadioButton
    Friend WithEvents txtdesg As System.Windows.Forms.TextBox
    Friend WithEvents txtqua As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtphone As System.Windows.Forms.TextBox
    Friend WithEvents txttemp As System.Windows.Forms.TextBox
    Friend WithEvents txtper As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents txtloan As System.Windows.Forms.TextBox
    Friend WithEvents txtfbf As System.Windows.Forms.TextBox
    Friend WithEvents txtgi As System.Windows.Forms.TextBox
    Friend WithEvents txtit As System.Windows.Forms.TextBox
    Friend WithEvents txtlic As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents btupdate As System.Windows.Forms.Button
    Friend WithEvents btdelete As System.Windows.Forms.Button
    Friend WithEvents btadd As System.Windows.Forms.Button
    Friend WithEvents btreset As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtother As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents cbstatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cmbdept As System.Windows.Forms.ComboBox
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents txtbasic As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents btview As System.Windows.Forms.Button
    Friend WithEvents Staff_Id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Staff_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents F_Name As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Per_Address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Temp_Address As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Phone_No As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Mobile_No As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Email_Id As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Gendr As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Qualification As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Experience As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Dt_of_Jn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Designation As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Department As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Basic As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents LIC As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents In_Tax As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Grp_Ins As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents FBF As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Loan As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Other_Ded As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
