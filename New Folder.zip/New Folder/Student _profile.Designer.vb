﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_Profile
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.cmbclass = New System.Windows.Forms.ComboBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.cmbcourse = New System.Windows.Forms.ComboBox
        Me.Label21 = New System.Windows.Forms.Label
        Me.cmbcast = New System.Windows.Forms.ComboBox
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtrelegion = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.rdfemale = New System.Windows.Forms.RadioButton
        Me.rdmale = New System.Windows.Forms.RadioButton
        Me.dtadminyr = New System.Windows.Forms.DateTimePicker
        Me.dt2 = New System.Windows.Forms.DateTimePicker
        Me.dt1 = New System.Windows.Forms.DateTimePicker
        Me.txtcoll = New System.Windows.Forms.TextBox
        Me.txttcno = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.txtadno = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtincome = New System.Windows.Forms.TextBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtadd = New System.Windows.Forms.TextBox
        Me.txtemail = New System.Windows.Forms.TextBox
        Me.txtmobile = New System.Windows.Forms.TextBox
        Me.txtphone = New System.Windows.Forms.TextBox
        Me.txtocc = New System.Windows.Forms.TextBox
        Me.txtqua = New System.Windows.Forms.TextBox
        Me.txtparent = New System.Windows.Forms.TextBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.stdadd = New System.Windows.Forms.Button
        Me.stddelete = New System.Windows.Forms.Button
        Me.butreset = New System.Windows.Forms.Button
        Me.butupdate = New System.Windows.Forms.Button
        Me.ln_hidden = New System.Windows.Forms.LinkLabel
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.cmbstatus = New System.Windows.Forms.ComboBox
        Me.Label20 = New System.Windows.Forms.Label
        Me.btview = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnok = New System.Windows.Forms.Button
        Me.rd1 = New System.Windows.Forms.RadioButton
        Me.rd2 = New System.Windows.Forms.RadioButton
        Me.rd3 = New System.Windows.Forms.RadioButton
        Me.grp3 = New System.Windows.Forms.GroupBox
        Me.btnclose = New System.Windows.Forms.Button
        Me.Label22 = New System.Windows.Forms.Label
        Me.lbupdate = New System.Windows.Forms.Label
        Me.GroupBox1.SuspendLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.cmbclass)
        Me.GroupBox1.Controls.Add(Me.Label19)
        Me.GroupBox1.Controls.Add(Me.cmbcourse)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Controls.Add(Me.cmbcast)
        Me.GroupBox1.Controls.Add(Me.Label18)
        Me.GroupBox1.Controls.Add(Me.txtrelegion)
        Me.GroupBox1.Controls.Add(Me.Label17)
        Me.GroupBox1.Controls.Add(Me.rdfemale)
        Me.GroupBox1.Controls.Add(Me.rdmale)
        Me.GroupBox1.Controls.Add(Me.dtadminyr)
        Me.GroupBox1.Controls.Add(Me.dt2)
        Me.GroupBox1.Controls.Add(Me.dt1)
        Me.GroupBox1.Controls.Add(Me.txtcoll)
        Me.GroupBox1.Controls.Add(Me.txttcno)
        Me.GroupBox1.Controls.Add(Me.txtname)
        Me.GroupBox1.Controls.Add(Me.txtadno)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.DarkMagenta
        Me.GroupBox1.Location = New System.Drawing.Point(0, 8)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(375, 396)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Student Profile"
        '
        'cmbclass
        '
        Me.cmbclass.FormattingEnabled = True
        Me.cmbclass.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbclass.Location = New System.Drawing.Point(177, 175)
        Me.cmbclass.Name = "cmbclass"
        Me.cmbclass.Size = New System.Drawing.Size(148, 23)
        Me.cmbclass.TabIndex = 25
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(16, 149)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(52, 17)
        Me.Label19.TabIndex = 24
        Me.Label19.Text = "Course"
        '
        'cmbcourse
        '
        Me.cmbcourse.FormattingEnabled = True
        Me.cmbcourse.Location = New System.Drawing.Point(177, 146)
        Me.cmbcourse.Name = "cmbcourse"
        Me.cmbcourse.Size = New System.Drawing.Size(148, 23)
        Me.cmbcourse.TabIndex = 23
        Me.cmbcourse.Text = "----- Select -----"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.ForeColor = System.Drawing.Color.Black
        Me.Label21.Location = New System.Drawing.Point(16, 178)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(110, 17)
        Me.Label21.TabIndex = 16
        Me.Label21.Text = "Year of Studying"
        '
        'cmbcast
        '
        Me.cmbcast.FormattingEnabled = True
        Me.cmbcast.Items.AddRange(New Object() {"SC", "ST", "2A", "2B", "3B", "Others"})
        Me.cmbcast.Location = New System.Drawing.Point(177, 233)
        Me.cmbcast.Name = "cmbcast"
        Me.cmbcast.Size = New System.Drawing.Size(150, 23)
        Me.cmbcast.TabIndex = 22
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(16, 236)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(78, 17)
        Me.Label18.TabIndex = 21
        Me.Label18.Text = "Cast Group"
        '
        'txtrelegion
        '
        Me.txtrelegion.Location = New System.Drawing.Point(177, 204)
        Me.txtrelegion.Name = "txtrelegion"
        Me.txtrelegion.Size = New System.Drawing.Size(150, 23)
        Me.txtrelegion.TabIndex = 19
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(16, 207)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(59, 17)
        Me.Label17.TabIndex = 18
        Me.Label17.Text = "Religion"
        '
        'rdfemale
        '
        Me.rdfemale.AutoSize = True
        Me.rdfemale.ForeColor = System.Drawing.Color.Black
        Me.rdfemale.Location = New System.Drawing.Point(244, 90)
        Me.rdfemale.Name = "rdfemale"
        Me.rdfemale.Size = New System.Drawing.Size(81, 21)
        Me.rdfemale.TabIndex = 17
        Me.rdfemale.Text = "FEMALE"
        Me.rdfemale.UseVisualStyleBackColor = True
        '
        'rdmale
        '
        Me.rdmale.AutoSize = True
        Me.rdmale.Checked = True
        Me.rdmale.ForeColor = System.Drawing.Color.Black
        Me.rdmale.Location = New System.Drawing.Point(173, 90)
        Me.rdmale.Name = "rdmale"
        Me.rdmale.Size = New System.Drawing.Size(65, 21)
        Me.rdmale.TabIndex = 16
        Me.rdmale.TabStop = True
        Me.rdmale.Text = "MALE"
        Me.rdmale.UseVisualStyleBackColor = True
        '
        'dtadminyr
        '
        Me.dtadminyr.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtadminyr.Location = New System.Drawing.Point(179, 349)
        Me.dtadminyr.Name = "dtadminyr"
        Me.dtadminyr.Size = New System.Drawing.Size(148, 23)
        Me.dtadminyr.TabIndex = 15
        '
        'dt2
        '
        Me.dt2.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dt2.Location = New System.Drawing.Point(179, 320)
        Me.dt2.Name = "dt2"
        Me.dt2.Size = New System.Drawing.Size(148, 23)
        Me.dt2.TabIndex = 14
        '
        'dt1
        '
        Me.dt1.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dt1.Location = New System.Drawing.Point(179, 117)
        Me.dt1.Name = "dt1"
        Me.dt1.Size = New System.Drawing.Size(148, 23)
        Me.dt1.TabIndex = 13
        '
        'txtcoll
        '
        Me.txtcoll.Location = New System.Drawing.Point(179, 262)
        Me.txtcoll.Name = "txtcoll"
        Me.txtcoll.Size = New System.Drawing.Size(148, 23)
        Me.txtcoll.TabIndex = 12
        '
        'txttcno
        '
        Me.txttcno.Location = New System.Drawing.Point(179, 291)
        Me.txttcno.Name = "txttcno"
        Me.txttcno.Size = New System.Drawing.Size(148, 23)
        Me.txttcno.TabIndex = 11
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(177, 61)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(148, 23)
        Me.txtname.TabIndex = 10
        '
        'txtadno
        '
        Me.txtadno.Location = New System.Drawing.Point(177, 32)
        Me.txtadno.Name = "txtadno"
        Me.txtadno.Size = New System.Drawing.Size(148, 23)
        Me.txtadno.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(16, 355)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(119, 17)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Year of Admission"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(16, 326)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 17)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "TC Date"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(16, 294)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(37, 17)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "TC #"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(16, 265)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(82, 17)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Alma Mater"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(16, 93)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(53, 17)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Gender"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(16, 123)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(58, 17)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "D. O. B."
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(16, 64)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(43, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(16, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(92, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Admission No"
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(405, 400)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(631, 180)
        Me.Grid.TabIndex = 1
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtincome)
        Me.GroupBox2.Controls.Add(Me.Label16)
        Me.GroupBox2.Controls.Add(Me.txtadd)
        Me.GroupBox2.Controls.Add(Me.txtemail)
        Me.GroupBox2.Controls.Add(Me.txtmobile)
        Me.GroupBox2.Controls.Add(Me.txtphone)
        Me.GroupBox2.Controls.Add(Me.txtocc)
        Me.GroupBox2.Controls.Add(Me.txtqua)
        Me.GroupBox2.Controls.Add(Me.txtparent)
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.DarkMagenta
        Me.GroupBox2.Location = New System.Drawing.Point(0, 414)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(375, 296)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Parent's Profile"
        '
        'txtincome
        '
        Me.txtincome.Location = New System.Drawing.Point(189, 256)
        Me.txtincome.Name = "txtincome"
        Me.txtincome.Size = New System.Drawing.Size(148, 23)
        Me.txtincome.TabIndex = 18
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(18, 259)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(103, 17)
        Me.Label16.TabIndex = 17
        Me.Label16.Text = "Annual Income"
        '
        'txtadd
        '
        Me.txtadd.Location = New System.Drawing.Point(189, 198)
        Me.txtadd.Multiline = True
        Me.txtadd.Name = "txtadd"
        Me.txtadd.Size = New System.Drawing.Size(148, 52)
        Me.txtadd.TabIndex = 16
        '
        'txtemail
        '
        Me.txtemail.Location = New System.Drawing.Point(189, 172)
        Me.txtemail.Name = "txtemail"
        Me.txtemail.Size = New System.Drawing.Size(148, 23)
        Me.txtemail.TabIndex = 15
        '
        'txtmobile
        '
        Me.txtmobile.Location = New System.Drawing.Point(189, 146)
        Me.txtmobile.Name = "txtmobile"
        Me.txtmobile.Size = New System.Drawing.Size(148, 23)
        Me.txtmobile.TabIndex = 14
        '
        'txtphone
        '
        Me.txtphone.Location = New System.Drawing.Point(189, 119)
        Me.txtphone.Name = "txtphone"
        Me.txtphone.Size = New System.Drawing.Size(148, 23)
        Me.txtphone.TabIndex = 13
        '
        'txtocc
        '
        Me.txtocc.Location = New System.Drawing.Point(189, 93)
        Me.txtocc.Name = "txtocc"
        Me.txtocc.Size = New System.Drawing.Size(148, 23)
        Me.txtocc.TabIndex = 12
        '
        'txtqua
        '
        Me.txtqua.Location = New System.Drawing.Point(187, 65)
        Me.txtqua.Multiline = True
        Me.txtqua.Name = "txtqua"
        Me.txtqua.Size = New System.Drawing.Size(150, 20)
        Me.txtqua.TabIndex = 11
        '
        'txtparent
        '
        Me.txtparent.Location = New System.Drawing.Point(187, 35)
        Me.txtparent.Name = "txtparent"
        Me.txtparent.Size = New System.Drawing.Size(148, 23)
        Me.txtparent.TabIndex = 10
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(16, 201)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(57, 17)
        Me.Label15.TabIndex = 6
        Me.Label15.Text = "Address"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(18, 175)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(43, 17)
        Me.Label14.TabIndex = 5
        Me.Label14.Text = "Email"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(18, 149)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(49, 17)
        Me.Label13.TabIndex = 4
        Me.Label13.Text = "Mobile"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.ForeColor = System.Drawing.Color.Black
        Me.Label12.Location = New System.Drawing.Point(18, 122)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(46, 17)
        Me.Label12.TabIndex = 3
        Me.Label12.Text = "Phone"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.ForeColor = System.Drawing.Color.Black
        Me.Label11.Location = New System.Drawing.Point(16, 68)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(88, 17)
        Me.Label11.TabIndex = 2
        Me.Label11.Text = "Qualification"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(16, 96)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(77, 17)
        Me.Label10.TabIndex = 1
        Me.Label10.Text = "Occupation"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(16, 38)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(168, 17)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Parent's/Guardian's name"
        '
        'stdadd
        '
        Me.stdadd.BackColor = System.Drawing.Color.White
        Me.stdadd.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stdadd.ForeColor = System.Drawing.Color.Red
        Me.stdadd.Location = New System.Drawing.Point(405, 610)
        Me.stdadd.Name = "stdadd"
        Me.stdadd.Size = New System.Drawing.Size(121, 57)
        Me.stdadd.TabIndex = 2
        Me.stdadd.Text = "ADD"
        Me.stdadd.UseVisualStyleBackColor = False
        '
        'stddelete
        '
        Me.stddelete.BackColor = System.Drawing.Color.White
        Me.stddelete.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.stddelete.ForeColor = System.Drawing.Color.Red
        Me.stddelete.Location = New System.Drawing.Point(659, 608)
        Me.stddelete.Name = "stddelete"
        Me.stddelete.Size = New System.Drawing.Size(121, 57)
        Me.stddelete.TabIndex = 5
        Me.stddelete.Text = "DELETE"
        Me.stddelete.UseVisualStyleBackColor = False
        '
        'butreset
        '
        Me.butreset.BackColor = System.Drawing.Color.White
        Me.butreset.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butreset.ForeColor = System.Drawing.Color.Red
        Me.butreset.Location = New System.Drawing.Point(786, 608)
        Me.butreset.Name = "butreset"
        Me.butreset.Size = New System.Drawing.Size(121, 57)
        Me.butreset.TabIndex = 10
        Me.butreset.Text = "RESET"
        Me.butreset.UseVisualStyleBackColor = False
        '
        'butupdate
        '
        Me.butupdate.BackColor = System.Drawing.Color.White
        Me.butupdate.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.butupdate.ForeColor = System.Drawing.Color.Red
        Me.butupdate.Location = New System.Drawing.Point(532, 608)
        Me.butupdate.Name = "butupdate"
        Me.butupdate.Size = New System.Drawing.Size(121, 57)
        Me.butupdate.TabIndex = 11
        Me.butupdate.Text = "UPDATE"
        Me.butupdate.UseVisualStyleBackColor = False
        '
        'ln_hidden
        '
        Me.ln_hidden.AutoSize = True
        Me.ln_hidden.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ln_hidden.Location = New System.Drawing.Point(932, 700)
        Me.ln_hidden.Name = "ln_hidden"
        Me.ln_hidden.Size = New System.Drawing.Size(104, 17)
        Me.ln_hidden.TabIndex = 13
        Me.ln_hidden.TabStop = True
        Me.ln_hidden.Text = "Hidden Records"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.cmbstatus)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Enabled = False
        Me.Panel1.Location = New System.Drawing.Point(514, 693)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(148, 36)
        Me.Panel1.TabIndex = 14
        Me.Panel1.Visible = False
        '
        'cmbstatus
        '
        Me.cmbstatus.FormattingEnabled = True
        Me.cmbstatus.Items.AddRange(New Object() {"True", "False"})
        Me.cmbstatus.Location = New System.Drawing.Point(39, 5)
        Me.cmbstatus.Name = "cmbstatus"
        Me.cmbstatus.Size = New System.Drawing.Size(94, 21)
        Me.cmbstatus.TabIndex = 1
        Me.cmbstatus.Visible = False
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(3, 8)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(37, 13)
        Me.Label20.TabIndex = 0
        Me.Label20.Text = "Status"
        Me.Label20.Visible = False
        '
        'btview
        '
        Me.btview.BackColor = System.Drawing.Color.White
        Me.btview.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btview.ForeColor = System.Drawing.Color.Red
        Me.btview.Location = New System.Drawing.Point(913, 608)
        Me.btview.Name = "btview"
        Me.btview.Size = New System.Drawing.Size(123, 57)
        Me.btview.TabIndex = 18
        Me.btview.Text = "VIEW"
        Me.btview.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.student_photo_1_
        Me.PictureBox1.Location = New System.Drawing.Point(469, 6)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(494, 269)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 4
        Me.PictureBox1.TabStop = False
        '
        'btnok
        '
        Me.btnok.BackColor = System.Drawing.Color.White
        Me.btnok.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnok.ForeColor = System.Drawing.Color.Red
        Me.btnok.Location = New System.Drawing.Point(671, 325)
        Me.btnok.Name = "btnok"
        Me.btnok.Size = New System.Drawing.Size(109, 55)
        Me.btnok.TabIndex = 19
        Me.btnok.Text = "OK"
        Me.btnok.UseVisualStyleBackColor = False
        Me.btnok.Visible = False
        '
        'rd1
        '
        Me.rd1.AutoSize = True
        Me.rd1.Checked = True
        Me.rd1.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rd1.Location = New System.Drawing.Point(553, 286)
        Me.rd1.Name = "rd1"
        Me.rd1.Size = New System.Drawing.Size(63, 21)
        Me.rd1.TabIndex = 20
        Me.rd1.TabStop = True
        Me.rd1.Text = "I Year"
        Me.rd1.UseVisualStyleBackColor = True
        Me.rd1.Visible = False
        '
        'rd2
        '
        Me.rd2.AutoSize = True
        Me.rd2.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rd2.Location = New System.Drawing.Point(690, 288)
        Me.rd2.Name = "rd2"
        Me.rd2.Size = New System.Drawing.Size(69, 21)
        Me.rd2.TabIndex = 21
        Me.rd2.Text = "II Year"
        Me.rd2.UseVisualStyleBackColor = True
        Me.rd2.Visible = False
        '
        'rd3
        '
        Me.rd3.AutoSize = True
        Me.rd3.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rd3.Location = New System.Drawing.Point(807, 286)
        Me.rd3.Name = "rd3"
        Me.rd3.Size = New System.Drawing.Size(75, 21)
        Me.rd3.TabIndex = 22
        Me.rd3.Text = "III Year"
        Me.rd3.UseVisualStyleBackColor = True
        Me.rd3.Visible = False
        '
        'grp3
        '
        Me.grp3.Location = New System.Drawing.Point(514, 273)
        Me.grp3.Name = "grp3"
        Me.grp3.Size = New System.Drawing.Size(416, 121)
        Me.grp3.TabIndex = 23
        Me.grp3.TabStop = False
        Me.grp3.Visible = False
        '
        'btnclose
        '
        Me.btnclose.BackColor = System.Drawing.Color.White
        Me.btnclose.Font = New System.Drawing.Font("Times New Roman", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclose.ForeColor = System.Drawing.Color.Red
        Me.btnclose.Location = New System.Drawing.Point(786, 682)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(117, 51)
        Me.btnclose.TabIndex = 24
        Me.btnclose.Text = "CLOSE"
        Me.btnclose.UseVisualStyleBackColor = False
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Blue
        Me.Label22.Location = New System.Drawing.Point(463, 286)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(26, 31)
        Me.Label22.TabIndex = 25
        Me.Label22.Text = "*"
        '
        'lbupdate
        '
        Me.lbupdate.AutoSize = True
        Me.lbupdate.Font = New System.Drawing.Font("Times New Roman", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbupdate.ForeColor = System.Drawing.Color.Blue
        Me.lbupdate.Location = New System.Drawing.Point(458, 317)
        Me.lbupdate.Name = "lbupdate"
        Me.lbupdate.Size = New System.Drawing.Size(50, 17)
        Me.lbupdate.TabIndex = 26
        Me.lbupdate.Text = "Update"
        Me.lbupdate.Visible = False
        '
        'Student_Profile
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1067, 741)
        Me.Controls.Add(Me.lbupdate)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.btnclose)
        Me.Controls.Add(Me.rd3)
        Me.Controls.Add(Me.rd2)
        Me.Controls.Add(Me.rd1)
        Me.Controls.Add(Me.btnok)
        Me.Controls.Add(Me.btview)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.ln_hidden)
        Me.Controls.Add(Me.butupdate)
        Me.Controls.Add(Me.butreset)
        Me.Controls.Add(Me.stddelete)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.stdadd)
        Me.Controls.Add(Me.Grid)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.grp3)
        Me.Name = "Student_Profile"
        Me.Text = "Student_Profile"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents stdadd As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents stddelete As System.Windows.Forms.Button
    Friend WithEvents rdfemale As System.Windows.Forms.RadioButton
    Friend WithEvents rdmale As System.Windows.Forms.RadioButton
    Friend WithEvents dtadminyr As System.Windows.Forms.DateTimePicker
    Friend WithEvents dt2 As System.Windows.Forms.DateTimePicker
    Friend WithEvents dt1 As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtcoll As System.Windows.Forms.TextBox
    Friend WithEvents txttcno As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtadno As System.Windows.Forms.TextBox
    Friend WithEvents txtadd As System.Windows.Forms.TextBox
    Friend WithEvents txtemail As System.Windows.Forms.TextBox
    Friend WithEvents txtmobile As System.Windows.Forms.TextBox
    Friend WithEvents txtphone As System.Windows.Forms.TextBox
    Friend WithEvents txtocc As System.Windows.Forms.TextBox
    Friend WithEvents txtqua As System.Windows.Forms.TextBox
    Friend WithEvents txtparent As System.Windows.Forms.TextBox
    Friend WithEvents butreset As System.Windows.Forms.Button
    Friend WithEvents butupdate As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtrelegion As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents txtincome As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents cmbcast As System.Windows.Forms.ComboBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents cmbcourse As System.Windows.Forms.ComboBox
    Friend WithEvents ln_hidden As System.Windows.Forms.LinkLabel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents cmbstatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents btview As System.Windows.Forms.Button
    Friend WithEvents cmbclass As System.Windows.Forms.ComboBox
    Friend WithEvents btnok As System.Windows.Forms.Button
    Friend WithEvents rd1 As System.Windows.Forms.RadioButton
    Friend WithEvents rd2 As System.Windows.Forms.RadioButton
    Friend WithEvents rd3 As System.Windows.Forms.RadioButton
    Friend WithEvents grp3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnclose As System.Windows.Forms.Button
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents lbupdate As System.Windows.Forms.Label




End Class
