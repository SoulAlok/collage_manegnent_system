﻿Imports System.Data.SqlClient
Public Class Search_Employee

    Private Sub Search_Employee_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connection_open()
        qry = "select Name from Tbl_dept"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbdept.Items.Add(dr(0).ToString)

        Loop
        connection_close()
    End Sub

    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        connection_open()
        qry = "select Name,Desg from Tbl_Employee where dept='" & cmbdept.Text & "'"
        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_Employee")

        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub
End Class