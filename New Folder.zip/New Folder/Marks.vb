﻿Imports System.Data.SqlClient

Public Class Marks

    Private Sub Marks_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_course()


    End Sub
    Sub load_course()
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)

        Loop
        connection_close()
    End Sub
    

    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        connection_close()
        connection_open()
        crs = cmbcourse.Text
        sem = cmbsem.Text
        exam = cmbexam.Text


        qry = "select * from Tbl_mark where course='" & cmbcourse.Text & "' and sem='" & cmbsem.Text & "' and exam='" & cmbexam.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        If dr.Read <> True Then
            MsgBox("No Records Are Found", MsgBoxStyle.Information, "NO RECORDS")
        Else
            crs = cmbcourse.Text
            sem = cmbsem.Text
            exam = cmbexam.Text
            Marks_report.Show()
        End If
    End Sub

End Class