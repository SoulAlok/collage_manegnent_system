﻿Imports System.Data.SqlClient

Public Class Marks_report

    Private Sub CrystalReportViewer1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CrystalReportViewer1.Load
        connection_close()
        connection_open()
        qry = "select * from Tbl_mark where course= '" & crs & "' and sem='" & sem & "' and exam='" & exam & "'"
        adp = New SqlDataAdapter(qry, cnn)
        ds = New DataSet

        adp.Fill(ds, "Tbl_mark")

        Dim mt As New CrystalReport1
        mt.SetDataSource(ds)

        CrystalReportViewer1.ReportSource = mt
        mt.Refresh()
        CrystalReportViewer1.Show()
        connection_close()

    End Sub
End Class