﻿Imports System.Data.SqlClient
Public Class Course

    

    Private Sub crsadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles crsadd.Click

        connection_open()
        qry = "insert into Tbl_crs(Code,C_Name,Sem,Subcode,S_Name) values (" & txtcode.Text & ",'" & txtname.Text & "','" & txtsem.Text & "','" & txtsubcode.Text & "','" & txtsbjname.Text & "')"
        If txtname.Text = "" Then
            MsgBox("Please Select the Course", MsgBoxStyle.Information, "Office Automation")

        ElseIf txtsem.Text = "" Then
            MsgBox("Please Select the Semester", MsgBoxStyle.Information, "Office Automation")
        ElseIf txtsubcode.Text = "" Then
            MsgBox("Please Enter the SubjectCode", MsgBoxStyle.Information, "Office Automation")
        ElseIf txtsbjname.Text = "" Then
            MsgBox("Please Enter the Subject Name", MsgBoxStyle.Information, "Office Automation")

        Else
            qry1 = "select * from Tbl_crs where Subcode='" & txtsubcode.Text & "'"
            cmd1 = New SqlCommand(qry1, cnn)
            dr = cmd1.ExecuteReader()
            If dr.Read = False Then
                cmd = New SqlCommand(qry, cnn)
                dr.Close()
                cmd.ExecuteNonQuery()
                MsgBox("Successfully Entered into the DataBase", MsgBoxStyle.MsgBoxRight, "Successful")
                'grid fill
                ds.Clear()


                qry = "select * from Tbl_crs"
                adp = New SqlDataAdapter(qry, cnn)

                adp.Fill(ds, "Tbl_crs")
                Grid.DataSource = ds
                Grid.DataMember = ds.Tables(0).ToString

                connection_close()
            End If
            connection_close()
        End If

    End Sub

    Private Sub crsrst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles crsrst.Click
        txtname.Text = ""
        txtsem.Text = ""
        txtsubcode.Text = ""
        txtsbjname.Text = ""

    End Sub

    Private Sub crupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles crupdate.Click
        connection_open()

        qry1 = "update Tbl_crs set Code=" & txtcode.Text & ",C_Name='" & txtname.Text & "',Sem='" & txtsem.Text & "',S_Name='" & txtsbjname.Text & "'where Subcode='" & txtsubcode.Text & "'"
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()



        'grid fill

        qry = "select * from Tbl_crs"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_crs")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub


    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        Dim a
        a = Grid.CurrentRow.Index
        txtname.Text = Grid.Item(0, a).Value
        txtsem.Text = Grid.Item(1, a).Value
        txtsubcode.Text = Grid.Item(2, a).Value
        txtsbjname.Text = Grid.Item(3, a).Value
    End Sub

    Private Sub Course_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ds.Clear()
        connection_open()
        qry = "select * from Tbl_crs"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_crs")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub

    Private Sub crsdelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles crsdelete.Click
        connection_open()
        qry = "delete from Tbl_crs where C_Name='" & txtname.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        Dim g = MsgBox("Are you Sure you want to delete the record?", MsgBoxStyle.YesNoCancel, "Fill")
        If g = MsgBoxResult.Yes Then
            cmd.ExecuteNonQuery()
            MsgBox("Successfully Deleted the Record of  '" & txtname.Text & "' ", MsgBoxStyle.MsgBoxRight, "Deleted")
        Else

            MsgBox("Operation Aborted", MsgBoxStyle.AbortRetryIgnore, "Fill")


        End If
        ds.Clear()
        qry = "select * from Tbl_crs"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_crs")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub

    Private Sub txtcode_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtcode.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtcode.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtsbjname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtsbjname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        MDIParent1.Show()
    End Sub
End Class