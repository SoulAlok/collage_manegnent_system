﻿Imports System.Data.SqlClient
Public Class Sports






    Private Sub Sports_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connection_open()
        qry = "select name from Tbl_Regno"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            ad_lstsch.Items.Add(dr(0).ToString)
        Loop
        connection_close()
    End Sub
End Class