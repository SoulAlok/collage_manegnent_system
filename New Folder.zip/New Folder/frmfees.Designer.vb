﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmfees
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.lblbal = New System.Windows.Forms.Label
        Me.rdpartial = New System.Windows.Forms.RadioButton
        Me.rdcomplete = New System.Windows.Forms.RadioButton
        Me.txtregno = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.txtdonation = New System.Windows.Forms.TextBox
        Me.txttuition = New System.Windows.Forms.TextBox
        Me.txtfee = New System.Windows.Forms.TextBox
        Me.txtcon = New System.Windows.Forms.TextBox
        Me.txttot = New System.Windows.Forms.TextBox
        Me.txtpaid = New System.Windows.Forms.TextBox
        Me.txtbalance = New System.Windows.Forms.TextBox
        Me.cmbcourse = New System.Windows.Forms.ComboBox
        Me.cmbclass = New System.Windows.Forms.ComboBox
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.regno = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.stdname = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Don = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Tuit = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Special = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Con = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Tot = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.paid = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.Bal = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.type = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.btnupdate = New System.Windows.Forms.Button
        Me.btnreset = New System.Windows.Forms.Button
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(33, 23)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Course"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(302, 26)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Class"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(33, 242)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Regno"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(33, 289)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Name"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 337)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Donation"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(33, 377)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(39, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Tuition"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(357, 242)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(42, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Special"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(357, 276)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(62, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Concession"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(357, 317)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(31, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Total"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(360, 394)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(28, 13)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Paid"
        '
        'lblbal
        '
        Me.lblbal.AutoSize = True
        Me.lblbal.Location = New System.Drawing.Point(357, 433)
        Me.lblbal.Name = "lblbal"
        Me.lblbal.Size = New System.Drawing.Size(46, 13)
        Me.lblbal.TabIndex = 10
        Me.lblbal.Text = "Balance"
        '
        'rdpartial
        '
        Me.rdpartial.AutoSize = True
        Me.rdpartial.Location = New System.Drawing.Point(360, 347)
        Me.rdpartial.Name = "rdpartial"
        Me.rdpartial.Size = New System.Drawing.Size(54, 17)
        Me.rdpartial.TabIndex = 11
        Me.rdpartial.TabStop = True
        Me.rdpartial.Text = "Partial"
        Me.rdpartial.UseVisualStyleBackColor = True
        '
        'rdcomplete
        '
        Me.rdcomplete.AutoSize = True
        Me.rdcomplete.Location = New System.Drawing.Point(515, 347)
        Me.rdcomplete.Name = "rdcomplete"
        Me.rdcomplete.Size = New System.Drawing.Size(69, 17)
        Me.rdcomplete.TabIndex = 12
        Me.rdcomplete.TabStop = True
        Me.rdcomplete.Text = "Complete"
        Me.rdcomplete.UseVisualStyleBackColor = True
        '
        'txtregno
        '
        Me.txtregno.Location = New System.Drawing.Point(97, 242)
        Me.txtregno.Name = "txtregno"
        Me.txtregno.Size = New System.Drawing.Size(100, 20)
        Me.txtregno.TabIndex = 13
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(97, 286)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 20)
        Me.txtname.TabIndex = 14
        '
        'txtdonation
        '
        Me.txtdonation.Location = New System.Drawing.Point(97, 337)
        Me.txtdonation.Name = "txtdonation"
        Me.txtdonation.Size = New System.Drawing.Size(100, 20)
        Me.txtdonation.TabIndex = 15
        '
        'txttuition
        '
        Me.txttuition.Location = New System.Drawing.Point(97, 377)
        Me.txttuition.Name = "txttuition"
        Me.txttuition.Size = New System.Drawing.Size(100, 20)
        Me.txttuition.TabIndex = 16
        '
        'txtfee
        '
        Me.txtfee.Location = New System.Drawing.Point(421, 239)
        Me.txtfee.Name = "txtfee"
        Me.txtfee.Size = New System.Drawing.Size(100, 20)
        Me.txtfee.TabIndex = 17
        '
        'txtcon
        '
        Me.txtcon.Location = New System.Drawing.Point(425, 276)
        Me.txtcon.Name = "txtcon"
        Me.txtcon.Size = New System.Drawing.Size(100, 20)
        Me.txtcon.TabIndex = 18
        '
        'txttot
        '
        Me.txttot.Location = New System.Drawing.Point(425, 317)
        Me.txttot.Name = "txttot"
        Me.txttot.Size = New System.Drawing.Size(100, 20)
        Me.txttot.TabIndex = 19
        '
        'txtpaid
        '
        Me.txtpaid.Location = New System.Drawing.Point(425, 391)
        Me.txtpaid.Name = "txtpaid"
        Me.txtpaid.Size = New System.Drawing.Size(100, 20)
        Me.txtpaid.TabIndex = 20
        '
        'txtbalance
        '
        Me.txtbalance.Location = New System.Drawing.Point(425, 430)
        Me.txtbalance.Name = "txtbalance"
        Me.txtbalance.Size = New System.Drawing.Size(100, 20)
        Me.txtbalance.TabIndex = 21
        '
        'cmbcourse
        '
        Me.cmbcourse.FormattingEnabled = True
        Me.cmbcourse.Location = New System.Drawing.Point(97, 23)
        Me.cmbcourse.Name = "cmbcourse"
        Me.cmbcourse.Size = New System.Drawing.Size(121, 21)
        Me.cmbcourse.TabIndex = 22
        '
        'cmbclass
        '
        Me.cmbclass.FormattingEnabled = True
        Me.cmbclass.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbclass.Location = New System.Drawing.Point(369, 23)
        Me.cmbclass.Name = "cmbclass"
        Me.cmbclass.Size = New System.Drawing.Size(121, 21)
        Me.cmbclass.TabIndex = 23
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.regno, Me.stdname, Me.Don, Me.Tuit, Me.Special, Me.Con, Me.Tot, Me.paid, Me.Bal, Me.type})
        Me.Grid.Location = New System.Drawing.Point(12, 52)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(750, 150)
        Me.Grid.TabIndex = 25
        '
        'regno
        '
        Me.regno.HeaderText = "RegNo"
        Me.regno.Name = "regno"
        '
        'stdname
        '
        Me.stdname.HeaderText = "StdName"
        Me.stdname.Name = "stdname"
        '
        'Don
        '
        Me.Don.HeaderText = "Donation"
        Me.Don.Name = "Don"
        '
        'Tuit
        '
        Me.Tuit.HeaderText = "Tuition"
        Me.Tuit.Name = "Tuit"
        '
        'Special
        '
        Me.Special.HeaderText = "Special"
        Me.Special.Name = "Special"
        '
        'Con
        '
        Me.Con.HeaderText = "Concession"
        Me.Con.Name = "Con"
        '
        'Tot
        '
        Me.Tot.HeaderText = "Total"
        Me.Tot.Name = "Tot"
        '
        'paid
        '
        Me.paid.HeaderText = "Paid"
        Me.paid.Name = "paid"
        '
        'Bal
        '
        Me.Bal.HeaderText = "Balance"
        Me.Bal.Name = "Bal"
        '
        'type
        '
        Me.type.HeaderText = "Paid/Unpaid"
        Me.type.Name = "type"
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(199, 491)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(75, 23)
        Me.btnupdate.TabIndex = 27
        Me.btnupdate.Text = "UPDATE"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btnreset
        '
        Me.btnreset.Location = New System.Drawing.Point(305, 491)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(75, 23)
        Me.btnreset.TabIndex = 29
        Me.btnreset.Text = "RESET"
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'frmfees
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(785, 531)
        Me.Controls.Add(Me.btnreset)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.Grid)
        Me.Controls.Add(Me.cmbclass)
        Me.Controls.Add(Me.cmbcourse)
        Me.Controls.Add(Me.txtbalance)
        Me.Controls.Add(Me.txtpaid)
        Me.Controls.Add(Me.txttot)
        Me.Controls.Add(Me.txtcon)
        Me.Controls.Add(Me.txtfee)
        Me.Controls.Add(Me.txttuition)
        Me.Controls.Add(Me.txtdonation)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.txtregno)
        Me.Controls.Add(Me.rdcomplete)
        Me.Controls.Add(Me.rdpartial)
        Me.Controls.Add(Me.lblbal)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmfees"
        Me.Text = "frmfees"
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents lblbal As System.Windows.Forms.Label
    Friend WithEvents rdpartial As System.Windows.Forms.RadioButton
    Friend WithEvents rdcomplete As System.Windows.Forms.RadioButton
    Friend WithEvents txtregno As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtdonation As System.Windows.Forms.TextBox
    Friend WithEvents txttuition As System.Windows.Forms.TextBox
    Friend WithEvents txtfee As System.Windows.Forms.TextBox
    Friend WithEvents txtcon As System.Windows.Forms.TextBox
    Friend WithEvents txttot As System.Windows.Forms.TextBox
    Friend WithEvents txtpaid As System.Windows.Forms.TextBox
    Friend WithEvents txtbalance As System.Windows.Forms.TextBox
    Friend WithEvents cmbcourse As System.Windows.Forms.ComboBox
    Friend WithEvents cmbclass As System.Windows.Forms.ComboBox
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btnreset As System.Windows.Forms.Button
    Friend WithEvents regno As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents stdname As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Don As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tuit As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Special As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Con As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Tot As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents paid As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Bal As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents type As System.Windows.Forms.DataGridViewTextBoxColumn
End Class
