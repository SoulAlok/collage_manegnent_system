﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Student_hidden_records
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GridRestore = New System.Windows.Forms.DataGridView
        Me.btrestore = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtadno = New System.Windows.Forms.TextBox
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        CType(Me.GridRestore, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GridRestore
        '
        Me.GridRestore.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridRestore.Location = New System.Drawing.Point(14, 84)
        Me.GridRestore.Name = "GridRestore"
        Me.GridRestore.Size = New System.Drawing.Size(897, 366)
        Me.GridRestore.TabIndex = 0
        '
        'btrestore
        '
        Me.btrestore.BackColor = System.Drawing.Color.White
        Me.btrestore.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btrestore.ForeColor = System.Drawing.Color.Red
        Me.btrestore.Location = New System.Drawing.Point(14, 465)
        Me.btrestore.Name = "btrestore"
        Me.btrestore.Size = New System.Drawing.Size(185, 54)
        Me.btrestore.TabIndex = 1
        Me.btrestore.Text = "RESTORE"
        Me.btrestore.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(285, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(118, 20)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Admission No"
        '
        'txtadno
        '
        Me.txtadno.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtadno.Location = New System.Drawing.Point(472, 25)
        Me.txtadno.Name = "txtadno"
        Me.txtadno.Size = New System.Drawing.Size(207, 26)
        Me.txtadno.TabIndex = 3
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LinkLabel1.Location = New System.Drawing.Point(802, 482)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(49, 20)
        Me.LinkLabel1.TabIndex = 4
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "Back"
        '
        'Student_hidden_records
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Peru
        Me.ClientSize = New System.Drawing.Size(925, 549)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.txtadno)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btrestore)
        Me.Controls.Add(Me.GridRestore)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Student_hidden_records"
        Me.Text = "STUDENT HIDDENT RECRDS"
        CType(Me.GridRestore, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GridRestore As System.Windows.Forms.DataGridView
    Friend WithEvents btrestore As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtadno As System.Windows.Forms.TextBox
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
End Class
