﻿Imports System.Data.SqlClient

Public Class Salary


    Private Sub Salary_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dept_load()
        connection_open()
        qry = "select * from Tbl_Employee"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_Employee")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()


    End Sub

    'Private Sub txtid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtid.TextChanged
    '    connection_open()
    '    qry = "select Name,Desg,Basic,dept,LIC,Other_Ded from Tbl_Employee where Id='" & txtid.Text & "'"
    '    cmd = New SqlCommand(qry,cnn)
    '    dr = cmd.ExecuteReader
    '    Do While dr.Read = True
    '        txtname.Text = dr.Item(0).ToString
    '        txtdesg.Text = dr.Item(1).ToString
    '        cmbdept.Text = dr.Item(3).ToString
    '        txtlic.Text = dr.Item(3).ToString
    '        txtother.Text = dr.Item(4).ToString

    '    Loop




    '    connection_close()

    'End Sub

    'Private Sub txtbasic_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtbasic.TextChanged

    '    Dim basic = 0
    '    Dim da, hra
    '    Dim gross = 0
    '    basic = txtbasic.Text
    '    da = txtda.Text
    '    hra = txthra.Text
    '    da = Val(basic * (da / 100))
    '    hra = Val(basic * (hra / 100))

    '    gross = Val(basic) + Val(da) + Val(hra)
    '    txtgross.Text = gross
    'End Sub





    'Private Sub txtdept_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbdept.TextChanged
    '    connection_close()
    '    connection_open()
    '    qry = "select * from Tbl_dept where Name='" & cmbdept.Text & "'"
    '    adp = New SqlDataAdapter(qry, cnn)
    '    ds = New DataSet
    '    adp.Fill(ds, "Tbl_dept")
    '    Grid.DataSource = ds
    '    Grid.DataMember = ds.Tables(0).ToString
    '    connection_close()
    'End Sub

    Sub dept_load()
        connection_open()
        qry = "select Name from Tbl_dept"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        While dr.Read = True
            cmbdept.Items.Add(dr(0).ToString)

        End While
        connection_close()
    End Sub

    Private Sub btcalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btcalculate.Click
        Dim basic = 0
        Dim lic = 0
        Dim itax = 0
        Dim gi = 0
        Dim fbf = 0
        Dim loan = 0
        Dim od = 0

        Dim da, hra

        Dim gross = 0
        Dim pf = 0
        Dim ptax = 0
        Dim total = 0
        Dim net = 0

        basic = txtbasic.Text
        lic = txtlic.Text
        itax = txtit.Text
        gi = txtgi.Text
        fbf = txtfbf.Text
        loan = txtloan.Text
        od = txtother.Text

        da = txtda.Text
        hra = txthra.Text


        da = Val(basic * (da / 100))
        hra = Val(basic * (hra / 100))


        If basic > 10000 And basic <= 14999 Then
            ptax = 150
        ElseIf basic > 15000 And basic < 20000 Then
            ptax = 200
        End If

        pf = Val(basic) * (12 / 100)
        If pf > 780 Then
            pf = 780
        End If

        gross = Val(basic) + Val(da) + Val(hra)
        total = Val(gross) - Val(itax + pf + lic + od + gi + fbf + loan)
        net = Val(total) - Val(ptax)
        txtgross.Text = Val(gross)
        txtpf.Text = Val(pf)
        txttotal.Text = Val(total)
        txtpt.Text = Val(ptax)
        txtnet.Text = Val(net)

        connection_open()
        qry = "insert into Tbl_Salary(Id,Name,Desg,dept,Month,Basic,DA,HRA,Gross,Grp_Ins,Loan,LIC,Other_Ded,FBF,PF,I_Tax,Total_Sal,Prof_Tax,Net_Pay)values('" & txtid.Text & "','" & txtname.Text & "','" & txtdesg.Text & "','" & cmbdept.Text & "','" & cmbmonth.Text & "'," & txtbasic.Text & "," & txtda.Text & "," & txthra.Text & "," & txtgross.Text & "," & txtgi.Text & "," & txtloan.Text & "," & txtlic.Text & "," & txtother.Text & "," & txtfbf.Text & "," & txtpf.Text & "," & txtit.Text & "," & txttotal.Text & "," & txtpt.Text & "," & txtnet.Text & " ) "
        cmd = New SqlCommand(qry, cnn)
        cmd.ExecuteNonQuery()
        connection_close()

    End Sub

    Private Sub btview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btview.Click
        connection_open()
        ds.Clear()
        qry = "select * from Tbl_Employee where status ='False' and dept='" & cmbdept.Text & "'"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_Employee")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub

    
    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        Dim a
        a = Grid.CurrentRow.Index
       
        txtid.Text = Grid.Item(0, a).Value
        txtname.Text = Grid.Item(1, a).Value
        txtdesg.Text = Grid.Item(12, a).Value
        txtbasic.Text = Grid.Item(14, a).Value
        txtlic.Text = Grid.Item(15, a).Value
        txtit.Text = Grid.Item(16, a).Value
        txtgi.Text = Grid.Item(17, a).Value
        txtfbf.Text = Grid.Item(18, a).Value
        txtloan.Text = Grid.Item(19, a).Value
        txtother.Text = Grid.Item(20, a).Value


    End Sub
End Class