﻿Imports System.Data.SqlClient

Public Class Feesdetails

    Private Sub Feesdetails_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbcourse.Text = "----- Select -----"
        cmbclass.Text = "----- Select -----"
        cmbcourse.Focus()
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)
        Loop
        connection_close()

    End Sub
    Sub amount()
        Dim a
        Dim b
        Dim c
        Dim d

        a = txtdonation.Text
        b = txttuition.Text
        c = txtspecial.Text
        d = Val(a) + Val(b) + Val(c)
        txttotal.Text = Val(d)
    End Sub



    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        connection_open()
        qry = "select * from Tbl_Fees where Course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        If dr.Read = False Then
            dr.Close()
            qry = "insert into Tbl_Fees (course,year,donation,tuition,special,total) values('" & cmbcourse.Text & "','" & cmbclass.Text & "'," & txtdonation.Text & "," & txttuition.Text & "," & txtspecial.Text & "," & txttotal.Text & ")"
            cmd = New SqlCommand(qry, cnn)
            cmd.ExecuteNonQuery()
            MsgBox("Record Entered Successfully", MsgBoxStyle.Information, "Office Automation")
            view()
            connection_close()
        Else
            MsgBox("Record already exists", MsgBoxStyle.Information, "Office Automation")
            cmbcourse.Focus()
            connection_close()
        End If
        connection_close()
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click


        connection_close()
        connection_open()
        qry1 = "update Tbl_Fees set donation=" & txtdonation.Text & ",tuition=" & txttuition.Text & ",special=" & txtspecial.Text & ",total=" & txttotal.Text & " where course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        view()

        connection_close()
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        view()
    End Sub

    Private Sub txtspecial_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtspecial.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtspecial.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtspecial_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtspecial.TextChanged
        amount()

    End Sub


    Private Sub Gridview_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Gridview.DoubleClick
        Dim a
        a = Gridview.CurrentRow.Index
        cmbcourse.Text = Gridview.Item(0, a).Value
        cmbclass.Text = Gridview.Item(1, a).Value
        txtdonation.Text = Gridview.Item(2, a).Value
        txttuition.Text = Gridview.Item(3, a).Value
        txtspecial.Text = Gridview.Item(4, a).Value
        txttotal.Text = Gridview.Item(5, a).Value

    End Sub
    Public Sub view()

        connection_close()
        connection_open()
        cmd = New SqlCommand("Select * From Tbl_Fees where course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & "", con)
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)

        Gridview.Rows.Clear()
        Do While dr.Read = True
            Gridview.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5))
        Loop
        connection_close()
    End Sub

    Private Sub txtdonation_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdonation.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtdonation.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtdonation_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtdonation.TextChanged
        amount()
    End Sub

    Private Sub txttuition_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttuition.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txttuition.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txttuition_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txttuition.TextChanged
        amount()

    End Sub

    Private Sub txttotal_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttotal.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txttotal.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub


    Private Sub btnreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        cmbcourse.Text = "----- Select -----"
        cmbclass.Text = "----- Select -----"
        txtdonation.Text = ""
        txttuition.Text = ""
        txtspecial.Text = ""
        txttotal.Text = ""
        cmbcourse.Focus()
    End Sub

End Class