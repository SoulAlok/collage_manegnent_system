﻿Imports System.Data.SqlClient

Public Class Employee_salaryReport

    Private Sub Employee_salaryReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        connection_open()
        qry = "select Name from Tbl_dept"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        While dr.Read = True
            cmbdept.Items.Add(dr(0).ToString)
        End While
        connection_close()
    End Sub

    Private Sub btnclose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclose.Click
        MDIParent1.Show()
    End Sub

    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        connection_close()
        connection_open()
        mon = cmbmonth.Text
        dpt = cmbdept.Text


        qry = "select Id,Name,Desg,Basic,DA,HRA,Gross,Grp_Ins,Loan,LIC,Other_Ded,FBF,PF,I_Tax,Total_Sal,Prof_tax,Net_Pay from Tbl_Salary where Month='" & cmbmonth.Text & "' and dept='" & cmbdept.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        If dr.Read <> True Then
            MsgBox("No Records Are Found", MsgBoxStyle.Information, "NO RECORDS")
        Else
            mon = cmbmonth.Text
            dpt = cmbdept.Text
            Employee_report.Show()
        End If
    End Sub

End Class