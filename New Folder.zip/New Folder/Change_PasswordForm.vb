﻿Imports System.Data.SqlClient

Public Class Change_PasswordForm

    Sub clear()
        txtuser.Text = ""
        txtold.Text = ""
        txtnew.Text = ""
        txtconfirm.Text = ""
        txtuser.Focus()
    End Sub
    Private Sub Change_PasswordForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtuser.Focus()
    End Sub
   

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        connection_close()
        connection_open()
        qry = "select * from TableLogin where username='" & txtuser.Text & "' and  password='" & txtold.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            dr.Close()


            qry = "update TableLogin set password='" & txtnew.Text & "' where password='" & txtold.Text & "'"
            cmd = New SqlCommand(qry, cnn)
            If txtnew.Text <> txtconfirm.Text Then
                lblpswd.Visible = True
                lblpswd.BringToFront()
                lblpswd.Text = "Password Mismatch"
                txtconfirm.Focus()
            Else
                cmd.ExecuteNonQuery()
                MsgBox("Password has been Changed", MsgBoxStyle.Information, "CHANGE PASSWORD")
                connection_close()
            End If
        Else
            MsgBox("Incorrect Username or Password", MsgBoxStyle.Information, "change")

            connection_close()

        End If

    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        clear()
    End Sub
End Class