﻿Imports System.Data.SqlClient

Public Class Load



    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If pgbar.Value >= 1000 Then
            pgbar.Value = 0
            Timer1.Enabled = False
            Me.Hide()

            MDIParent1.Show()
            MDIParent1.Enabled = False
            Loginform.Show()

        Else
            pgbar.Value = pgbar.Value + 20

        End If
    End Sub


    Private Sub Load_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Timer1.Enabled = True
        Timer1.Interval = 100

    End Sub



End Class