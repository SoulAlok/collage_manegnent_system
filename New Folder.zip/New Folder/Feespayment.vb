﻿Imports System.Data.SqlClient

Public Class Feespayment
    Public payment
    Sub pay()

        If rdcomplete.Checked = True Then
            payment = "Complete"
        Else
            payment = "Partial"
        End If
    End Sub

    Private Sub Feespayment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)
        Loop
        connection_close()
    End Sub

    Private Sub butok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butok.Click
        Panel1.Visible = True
        Panel1.Enabled = True
        connection_open()

        qry = "select regno,name from Tbl_Regno where course='" & cmbcourse.Text & "' and class=" & cmbclass.Text & ""

        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_Regno")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()

    End Sub


    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick

        connection_open()
        Dim b
        b = Grid.CurrentRow.Index

        txtregno.Text = Grid.Item(0, b).Value.ToString
        txtname.Text = Grid.Item(1, b).Value.ToString
        connection_close()




    End Sub


    Private Sub rdpartial_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdpartial.Click
        lblbal.Enabled = True
        txtbal.Enabled = True

    End Sub

    Private Sub btadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btadd.Click
        connection_open()
        qry = "select * from Tbl_fees_payment where regno=" & txtregno.Text & ""
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        If dr.Read = False Then
            dr.Close()
            qry = "insert into Tbl_fees_payment (course,class,regno,name,donation,tuition,fees_amt,con_amt,tot_fee,paid,balance,pay_type) values('" & cmbcourse.Text & "','" & cmbclass.Text & "'," & txtregno.Text & ",'" & txtname.Text & "'," & txtdonation.Text & "," & txttuition.Text & "," & txtfee.Text & "," & txtcon.Text & "," & txttot.Text & "," & txtpaid.Text & "," & txtbal.Text & ",'" & payment & "')"
            cmd = New SqlCommand(qry, cnn)
            cmd.ExecuteNonQuery()
            MsgBox("Record Entered Successfully", MsgBoxStyle.Information, "Office Automation")
            connection_close()
        Else
            MsgBox("Record already exists", MsgBoxStyle.Information, "Office Automation")
            cmbcourse.Focus()
            connection_close()
        End If
        connection_close()
    End Sub

    Private Sub btupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btupdate.Click
        'GridView.Visible = True
        'grp2.Visible = True

        connection_close()
        connection_open()
        pay()
        qry1 = "update  Tbl_fees_payment set course='" & cmbcourse.Text & "',class='" & cmbclass.Text & "',name='" & txtname.Text & "',donation=" & txtdonation.Text & ",tuition=" & txttuition.Text & ",fees_amt=" & txtfee.Text & ",con_amt=" & txtcon.Text & ",paid=" & txtpaid.Text & ",balance=" & txtbal.Text & ",pay_type='" & payment & "' where regno=" & txtregno.Text & ""
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()
        'grid fill
        qry = "select * from Tbl_fees_payment "
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_fees_payment")
        GridView.DataSource = ds
        GridView.DataMember = ds.Tables(0).ToString

        connection_close()


    End Sub


    Private Sub buttot_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles buttot.Click
        Dim a
        Dim b
        Dim c
        Dim d
        Dim f
        a = txtdonation.Text
        b = txttuition.Text
        c = txtfee.Text
        f = txtcon.Text
        If txtcon.Text = "" Then
            d = Val(a) + Val(b) + Val(c)
            txttot.Text = Val(d)
        Else
            d = (Val(a) + Val(b) + Val(c)) - Val(f)
            txttot.Text = Val(d)
        End If
    End Sub


    Private Sub txtpaid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpaid.TextChanged
        Dim x
        Dim y
        Dim z
        x = txttot.Text
        y = txtpaid.Text
        z = Val(x) - Val(y)
        txtbal.Text = Val(z)
    End Sub


    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click

        connection_open()

        Grid.Visible = False
        Panel1.Visible = False
        GridView.Visible = True
        Panel2.Visible = True
        ds.Clear()
        qry = "select * from Tbl_fees_payment where course='" & cmbcourse.Text & "' and class=" & cmbclass.Text & ""
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_fees_payment")
        GridView.DataSource = ds
        GridView.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub

    Private Sub btreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btreset.Click

        cmbcourse.Text = ""
        cmbclass.Text = ""
        txtregno.Text = ""
        txtname.Text = ""


        txtdonation.Text = ""
        txttuition.Text = ""
        txtfee.Text = ""
        txttot.Text = ""
        txtpaid.Text = ""
        txtbal.Text = ""
        rdpartial.Checked = False
        rdcomplete.Checked = False

    End Sub


    Private Sub rdcomplete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles rdcomplete.Click
        lblbal.Enabled = False
        txtbal.Enabled = False
    End Sub



    Private Sub GridView_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView.DoubleClick

        connection_open()
        Dim b
        b = GridView.CurrentRow.Index


        cmbcourse.Text = GridView.Item(0, b).Value.ToString
        cmbclass.Text = GridView.Item(1, b).Value.ToString
        txtregno.Text = GridView.Item(2, b).Value.ToString
        txtname.Text = GridView.Item(3, b).Value.ToString
        txtdonation.Text = GridView.Item(4, b).Value.ToString
        txttuition.Text = GridView.Item(5, b).Value.ToString
        txtfee.Text = GridView.Item(6, b).Value.ToString
        txtcon.Text = GridView.Item(7, b).Value.ToString
        txttot.Text = GridView.Item(8, b).Value.ToString
        txtpaid.Text = GridView.Item(9, b).Value.ToString
        txtbal.Text = GridView.Item(10, b).Value.ToString
        payment = GridView.Item(11, b).Value.ToString


    End Sub

    Private Sub Grid_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles Grid.CellContentClick

    End Sub
End Class