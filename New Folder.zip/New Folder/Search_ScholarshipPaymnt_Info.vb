﻿Imports System.Data.SqlClient

Public Class Search_ScholarshipPaymnt_Info


    Sub load_scholarship()
        connection_open()
        qry = "select Name from Tbl_scr"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbscholar.Items.Add(dr(0).ToString)
        Loop
        connection_close()
    End Sub


    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        connection_open()
        qry = "select * from Tbl_scr_pay where sch_name='" & cmbscholar.Text & "'"
        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_scr_pay")

        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()

    End Sub

    Private Sub Search_ScholarshipPaymnt_Info_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_scholarship()

    End Sub
End Class