﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Change_Password
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnclr = New System.Windows.Forms.Button
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtcnewuname = New System.Windows.Forms.TextBox
        Me.txtnewuname = New System.Windows.Forms.TextBox
        Me.txtolduname = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.btnadd = New System.Windows.Forms.Button
        Me.btnbck = New System.Windows.Forms.Button
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.btnclrps = New System.Windows.Forms.Button
        Me.btnaddps = New System.Windows.Forms.Button
        Me.btnbkps = New System.Windows.Forms.Button
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtcnewupass = New System.Windows.Forms.TextBox
        Me.txtnewupass = New System.Windows.Forms.TextBox
        Me.txtoldupass = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnclr
        '
        Me.btnclr.BackColor = System.Drawing.Color.Gray
        Me.btnclr.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnclr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclr.Location = New System.Drawing.Point(194, 220)
        Me.btnclr.Name = "btnclr"
        Me.btnclr.Size = New System.Drawing.Size(164, 27)
        Me.btnclr.TabIndex = 18
        Me.btnclr.Text = "Clear"
        Me.btnclr.UseVisualStyleBackColor = False
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(11, 108)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(550, 299)
        Me.TabControl1.TabIndex = 1
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.Transparent
        Me.TabPage1.Controls.Add(Me.btnclr)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.txtcnewuname)
        Me.TabPage1.Controls.Add(Me.txtnewuname)
        Me.TabPage1.Controls.Add(Me.txtolduname)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.btnadd)
        Me.TabPage1.Controls.Add(Me.btnbck)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(542, 273)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Change UserName"
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Cyan
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label4.Font = New System.Drawing.Font("Algerian", 20.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(0, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(542, 30)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "CHANGING THE USERNAME"
        '
        'txtcnewuname
        '
        Me.txtcnewuname.Location = New System.Drawing.Point(290, 172)
        Me.txtcnewuname.Name = "txtcnewuname"
        Me.txtcnewuname.Size = New System.Drawing.Size(220, 20)
        Me.txtcnewuname.TabIndex = 16
        '
        'txtnewuname
        '
        Me.txtnewuname.Location = New System.Drawing.Point(290, 119)
        Me.txtnewuname.Name = "txtnewuname"
        Me.txtnewuname.Size = New System.Drawing.Size(220, 20)
        Me.txtnewuname.TabIndex = 15
        '
        'txtolduname
        '
        Me.txtolduname.Location = New System.Drawing.Point(290, 65)
        Me.txtolduname.Name = "txtolduname"
        Me.txtolduname.Size = New System.Drawing.Size(220, 20)
        Me.txtolduname.TabIndex = 14
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Transparent
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(42, 174)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(173, 23)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Confirm The New UserName:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Transparent
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(42, 121)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(173, 26)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Enter The New UserName:"
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(42, 67)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(173, 25)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Enter The Old UserName:"
        '
        'btnadd
        '
        Me.btnadd.BackColor = System.Drawing.Color.Gray
        Me.btnadd.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnadd.Location = New System.Drawing.Point(42, 220)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(146, 27)
        Me.btnadd.TabIndex = 10
        Me.btnadd.Text = "Change"
        Me.btnadd.UseVisualStyleBackColor = False
        '
        'btnbck
        '
        Me.btnbck.BackColor = System.Drawing.Color.Gray
        Me.btnbck.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnbck.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbck.Location = New System.Drawing.Point(364, 220)
        Me.btnbck.Name = "btnbck"
        Me.btnbck.Size = New System.Drawing.Size(146, 27)
        Me.btnbck.TabIndex = 9
        Me.btnbck.Text = "Back"
        Me.btnbck.UseVisualStyleBackColor = False
        '
        'TabPage2
        '
        Me.TabPage2.BackColor = System.Drawing.Color.Transparent
        Me.TabPage2.Controls.Add(Me.btnclrps)
        Me.TabPage2.Controls.Add(Me.btnaddps)
        Me.TabPage2.Controls.Add(Me.btnbkps)
        Me.TabPage2.Controls.Add(Me.Label5)
        Me.TabPage2.Controls.Add(Me.txtcnewupass)
        Me.TabPage2.Controls.Add(Me.txtnewupass)
        Me.TabPage2.Controls.Add(Me.txtoldupass)
        Me.TabPage2.Controls.Add(Me.Label6)
        Me.TabPage2.Controls.Add(Me.Label7)
        Me.TabPage2.Controls.Add(Me.Label8)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(542, 273)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Change Password"
        '
        'btnclrps
        '
        Me.btnclrps.BackColor = System.Drawing.Color.Gray
        Me.btnclrps.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnclrps.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnclrps.Location = New System.Drawing.Point(192, 213)
        Me.btnclrps.Name = "btnclrps"
        Me.btnclrps.Size = New System.Drawing.Size(172, 27)
        Me.btnclrps.TabIndex = 31
        Me.btnclrps.Text = "Clear"
        Me.btnclrps.UseVisualStyleBackColor = False
        '
        'btnaddps
        '
        Me.btnaddps.BackColor = System.Drawing.Color.Gray
        Me.btnaddps.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnaddps.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnaddps.Location = New System.Drawing.Point(40, 213)
        Me.btnaddps.Name = "btnaddps"
        Me.btnaddps.Size = New System.Drawing.Size(146, 27)
        Me.btnaddps.TabIndex = 30
        Me.btnaddps.Text = "Change"
        Me.btnaddps.UseVisualStyleBackColor = False
        '
        'btnbkps
        '
        Me.btnbkps.BackColor = System.Drawing.Color.Gray
        Me.btnbkps.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnbkps.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnbkps.Location = New System.Drawing.Point(370, 213)
        Me.btnbkps.Name = "btnbkps"
        Me.btnbkps.Size = New System.Drawing.Size(146, 27)
        Me.btnbkps.TabIndex = 29
        Me.btnbkps.Text = "Back"
        Me.btnbkps.UseVisualStyleBackColor = False
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Cyan
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label5.Font = New System.Drawing.Font("Algerian", 20.25!, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(0, 0)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(542, 37)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "CHANGING THE PASSWORD"
        '
        'txtcnewupass
        '
        Me.txtcnewupass.Location = New System.Drawing.Point(303, 166)
        Me.txtcnewupass.Margin = New System.Windows.Forms.Padding(4)
        Me.txtcnewupass.Name = "txtcnewupass"
        Me.txtcnewupass.Size = New System.Drawing.Size(213, 20)
        Me.txtcnewupass.TabIndex = 27
        Me.txtcnewupass.UseSystemPasswordChar = True
        '
        'txtnewupass
        '
        Me.txtnewupass.Location = New System.Drawing.Point(303, 116)
        Me.txtnewupass.Margin = New System.Windows.Forms.Padding(4)
        Me.txtnewupass.Name = "txtnewupass"
        Me.txtnewupass.Size = New System.Drawing.Size(213, 20)
        Me.txtnewupass.TabIndex = 26
        Me.txtnewupass.UseSystemPasswordChar = True
        '
        'txtoldupass
        '
        Me.txtoldupass.Location = New System.Drawing.Point(303, 69)
        Me.txtoldupass.Margin = New System.Windows.Forms.Padding(4)
        Me.txtoldupass.Name = "txtoldupass"
        Me.txtoldupass.Size = New System.Drawing.Size(213, 20)
        Me.txtoldupass.TabIndex = 25
        Me.txtoldupass.UseSystemPasswordChar = True
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.Transparent
        Me.Label6.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(40, 168)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(168, 18)
        Me.Label6.TabIndex = 24
        Me.Label6.Text = "Confirm The New Password:" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.Transparent
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(40, 118)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(168, 18)
        Me.Label7.TabIndex = 23
        Me.Label7.Text = "Enter The New Password:"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.Transparent
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(40, 71)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(168, 22)
        Me.Label8.TabIndex = 22
        Me.Label8.Text = "Enter The Old Password:"
        '
        'Change_Password
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(593, 515)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Change_Password"
        Me.Text = "Change_Password"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnclr As System.Windows.Forms.Button
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtcnewuname As System.Windows.Forms.TextBox
    Friend WithEvents txtnewuname As System.Windows.Forms.TextBox
    Friend WithEvents txtolduname As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents btnbck As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents btnclrps As System.Windows.Forms.Button
    Friend WithEvents btnaddps As System.Windows.Forms.Button
    Friend WithEvents btnbkps As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtcnewupass As System.Windows.Forms.TextBox
    Friend WithEvents txtnewupass As System.Windows.Forms.TextBox
    Friend WithEvents txtoldupass As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
End Class
