﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Course
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtcode = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.txtname = New System.Windows.Forms.TextBox
        Me.txtsubcode = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtsbjname = New System.Windows.Forms.TextBox
        Me.txtsem = New System.Windows.Forms.ListBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.Label2 = New System.Windows.Forms.Label
        Me.crupdate = New System.Windows.Forms.Button
        Me.crsdelete = New System.Windows.Forms.Button
        Me.crsadd = New System.Windows.Forms.Button
        Me.crsrst = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.btnclose = New System.Windows.Forms.Button
        Me.GroupBox1.SuspendLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtcode)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.txtname)
        Me.GroupBox1.Controls.Add(Me.txtsubcode)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.txtsbjname)
        Me.GroupBox1.Controls.Add(Me.txtsem)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Grid)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(3, 22)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(461, 351)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Course Details"
        '
        'txtcode
        '
        Me.txtcode.Location = New System.Drawing.Point(90, 24)
        Me.txtcode.Name = "txtcode"
        Me.txtcode.Size = New System.Drawing.Size(139, 22)
        Me.txtcode.TabIndex = 21
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 27)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 15)
        Me.Label5.TabIndex = 20
        Me.Label5.Text = "Course Code"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(90, 51)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(139, 22)
        Me.txtname.TabIndex = 19
        '
        'txtsubcode
        '
        Me.txtsubcode.Location = New System.Drawing.Point(90, 156)
        Me.txtsubcode.Name = "txtsubcode"
        Me.txtsubcode.Size = New System.Drawing.Size(139, 22)
        Me.txtsubcode.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(7, 156)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(78, 15)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Subject Code"
        '
        'txtsbjname
        '
        Me.txtsbjname.Location = New System.Drawing.Point(90, 202)
        Me.txtsbjname.Name = "txtsbjname"
        Me.txtsbjname.Size = New System.Drawing.Size(139, 22)
        Me.txtsbjname.TabIndex = 16
        '
        'txtsem
        '
        Me.txtsem.FormattingEnabled = True
        Me.txtsem.ItemHeight = 15
        Me.txtsem.Items.AddRange(New Object() {"I SEM", "II SEM", "III SEM", "IV SEM", "V SEM", "VI SEM"})
        Me.txtsem.Location = New System.Drawing.Point(90, 88)
        Me.txtsem.Name = "txtsem"
        Me.txtsem.Size = New System.Drawing.Size(139, 49)
        Me.txtsem.TabIndex = 15
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(7, 205)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(48, 15)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Subject"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(7, 88)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(59, 15)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "Semester"
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.SkyBlue
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.LightSalmon
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(192, Byte), Integer))
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.SaddleBrown
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Grid.DefaultCellStyle = DataGridViewCellStyle1
        Me.Grid.Location = New System.Drawing.Point(9, 229)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(438, 116)
        Me.Grid.TabIndex = 10
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(6, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(47, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Course"
        '
        'crupdate
        '
        Me.crupdate.BackColor = System.Drawing.Color.White
        Me.crupdate.ForeColor = System.Drawing.Color.Blue
        Me.crupdate.Location = New System.Drawing.Point(513, 319)
        Me.crupdate.Name = "crupdate"
        Me.crupdate.Size = New System.Drawing.Size(87, 27)
        Me.crupdate.TabIndex = 11
        Me.crupdate.Text = "UPDATE"
        Me.crupdate.UseVisualStyleBackColor = False
        '
        'crsdelete
        '
        Me.crsdelete.BackColor = System.Drawing.Color.White
        Me.crsdelete.ForeColor = System.Drawing.Color.Blue
        Me.crsdelete.Location = New System.Drawing.Point(620, 319)
        Me.crsdelete.Name = "crsdelete"
        Me.crsdelete.Size = New System.Drawing.Size(87, 27)
        Me.crsdelete.TabIndex = 9
        Me.crsdelete.Text = "DELETE"
        Me.crsdelete.UseVisualStyleBackColor = False
        '
        'crsadd
        '
        Me.crsadd.BackColor = System.Drawing.Color.White
        Me.crsadd.ForeColor = System.Drawing.Color.Blue
        Me.crsadd.Location = New System.Drawing.Point(513, 271)
        Me.crsadd.Name = "crsadd"
        Me.crsadd.Size = New System.Drawing.Size(87, 27)
        Me.crsadd.TabIndex = 7
        Me.crsadd.Text = "ADD"
        Me.crsadd.UseVisualStyleBackColor = False
        '
        'crsrst
        '
        Me.crsrst.BackColor = System.Drawing.Color.White
        Me.crsrst.ForeColor = System.Drawing.Color.Blue
        Me.crsrst.Location = New System.Drawing.Point(620, 271)
        Me.crsrst.Name = "crsrst"
        Me.crsrst.Size = New System.Drawing.Size(87, 27)
        Me.crsrst.TabIndex = 4
        Me.crsrst.Text = "RESET"
        Me.crsrst.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.courses_1_
        Me.PictureBox1.Location = New System.Drawing.Point(486, 22)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(221, 202)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 5
        Me.PictureBox1.TabStop = False
        '
        'btnclose
        '
        Me.btnclose.ForeColor = System.Drawing.Color.Blue
        Me.btnclose.Location = New System.Drawing.Point(570, 375)
        Me.btnclose.Name = "btnclose"
        Me.btnclose.Size = New System.Drawing.Size(75, 23)
        Me.btnclose.TabIndex = 12
        Me.btnclose.Text = "CLOSE"
        Me.btnclose.UseVisualStyleBackColor = True
        '
        'Course
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Teal
        Me.ClientSize = New System.Drawing.Size(750, 425)
        Me.Controls.Add(Me.btnclose)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.crsrst)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.crsdelete)
        Me.Controls.Add(Me.crupdate)
        Me.Controls.Add(Me.crsadd)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.White
        Me.Name = "Course"
        Me.Text = "Course"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents crsdelete As System.Windows.Forms.Button
    Friend WithEvents crsadd As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents crsrst As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents crupdate As System.Windows.Forms.Button
    Friend WithEvents txtsubcode As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtsbjname As System.Windows.Forms.TextBox
    Friend WithEvents txtsem As System.Windows.Forms.ListBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtcode As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnclose As System.Windows.Forms.Button
End Class
