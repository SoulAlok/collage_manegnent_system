﻿
Imports System.Data.SqlClient

Public Class Employee_Details

    Public gender
    Sub opt()
        If rdmale.Checked = True Then
            gender = "Male"
        Else
            gender = "Female"
        End If
    End Sub
    Private Sub staffentry_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        opt()
        department_load()
        view_all()
    End Sub

    Private Sub btadd_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btadd.Click
        connection_open()
        qry = "insert into Tbl_Employee(Id,Name,F_Name,Per_add,Tem_Add,Ph_No,Mob_No,Email,Gender,Qual,Exp,DOJ,Desg,dept,Basic,LIC,I_Tax,Grp_Ins,FBF,Loan,Other_Ded,status) values ('" & txtid.Text & "','" & txtname.Text & "','" & txtfname.Text & "','" & txtper.Text & "','" & txttemp.Text & "'," & txtphone.Text & "," & txtmob.Text & ",'" & txtemail.Text & "','" & gender & "' ,'" & txtqua.Text & "','" & txtexp.Text & "','" & doj.Value & "','" & txtdesg.Text & "','" & cmbdept.Text & "'," & txtbasic.Text & "," & txtlic.Text & "," & txtit.Text & "," & txtgi.Text & "," & txtfbf.Text & "," & txtloan.Text & "," & txtother.Text & ",'" & cbstatus.Text & "')"
        If txtid.Text = "" Then
            MsgBox("Please Enter the Id", MsgBoxStyle.Information, "Office Automation")
        Else


            qry1 = "select * from Tbl_Employee where Id='" & txtid.Text & "' "
            cmd1 = New SqlCommand(qry1, cnn)
            dr = cmd1.ExecuteReader()
            If dr.Read = False Then
                cmd = New SqlCommand(qry, cnn)
                dr.Close()
                cmd.ExecuteNonQuery()
                MsgBox("Successfully Entered into the DataBase", MsgBoxStyle.MsgBoxRight, "Successful")
                ds.Clear()

                view_all()
            Else
                MsgBox("Id Clash! Please change the Id.", MsgBoxStyle.Information, "Office Automation")
                txtid.Focus()
                connection_close()
            End If
            connection_close()
        End If
    End Sub
    Private Sub btupdate_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btupdate.Click
        opt()

        connection_open()

        qry1 = "update Tbl_Employee set Name='" & txtname.Text & "',F_Name='" & txtfname.Text & "',Per_Add='" & txtper.Text & "',Tem_Add='" & txttemp.Text & "',Ph_No=" & txtphone.Text & ",Mob_No=" & txtmob.Text & ",Email='" & txtemail.Text & "',Gender='" & gender & "' ,Qual='" & txtqua.Text & "',Exp='" & txtexp.Text & "',DOJ='" & doj.Value & "',Desg='" & txtdesg.Text & "',Dept='" & cmbdept.Text & "',Basic=" & txtbasic.Text & ",LIC=" & txtlic.Text & ",I_Tax=" & txtit.Text & ",Grp_Ins=" & txtgi.Text & ",FBF=" & txtfbf.Text & ",Loan=" & txtloan.Text & ",Other_Ded=" & txtother.Text & ",status='" & cbstatus.Text & "' where Id='" & txtid.Text & "' "
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()



        'grid fill
        view_all()
        connection_close()


    End Sub
    Private Sub btdelete_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btdelete.Click
        opt()
        connection_open()
        qry = " Update Tbl_Employee set status='True' where Id='" & txtid.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        cmd.ExecuteNonQuery()
        MsgBox("Record Deleted Successfully", MsgBoxStyle.MsgBoxRight, "Office Automation")

        ds.Clear()

        'grid fill
        ds.Clear()

         view_all()
        connection_close()



    End Sub

    Private Sub btreset_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btreset.Click
        txtid.Text = ""
        txtname.Text = ""
        txtfname.Text = ""
        txtper.Text = ""
        txttemp.Text = ""
        txtphone.Text = ""
        txtmob.Text = ""
        txtemail.Text = ""
        txtqua.Text = ""
        txtexp.Text = ""
        txtdesg.Text = ""
        cmbdept.Text = ""
        txtlic.Text = ""
        txtgi.Text = ""
        txtit.Text = ""
        txtfbf.Text = ""
        txtloan.Text = ""
        txtbasic.Text = ""
        txtother.Text = ""

        txtid.Focus()

    End Sub

    'Private Sub txtemail_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtemail.TextChanged
    '    If txtemail.Text = "a-zA-Z0-9@a-zA-Z0-9|.|" Then
    'End Sub



    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        connection_open()
        Dim a
        a = Grid.CurrentRow.Index
        txtid.Text = Grid.Item(0, a).Value
        txtname.Text = Grid.Item(1, a).Value
        txtfname.Text = Grid.Item(2, a).Value
        txtper.Text = Grid.Item(3, a).Value
        txttemp.Text = Grid.Item(4, a).Value
        txtphone.Text = Grid.Item(5, a).Value
        txtmob.Text = Grid.Item(6, a).Value
        txtemail.Text = Grid.Item(7, a).Value
        gender = Grid.Item(8, a).Value
        txtqua.Text = Grid.Item(9, a).Value
        txtexp.Text = Grid.Item(10, a).Value
        doj.Value = Grid.Item(11, a).Value
        txtdesg.Text = Grid.Item(12, a).Value
        cmbdept.Text = Grid.Item(13, a).Value
        txtbasic.Text = Grid.Item(14, a).Value
        txtlic.Text = Grid.Item(15, a).Value
        txtit.Text = Grid.Item(16, a).Value
        txtgi.Text = Grid.Item(17, a).Value
        txtfbf.Text = Grid.Item(18, a).Value
        txtloan.Text = Grid.Item(19, a).Value
        txtother.Text = Grid.Item(20, a).Value
        connection_close()
    End Sub



    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Employee_hidden_records.Show()
    End Sub
    Sub department_load()
        connection_open()
        qry = "select Name from Tbl_dept"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        While dr.Read = True
            cmbdept.Items.Add(dr(0).ToString)

        End While
        connection_close()
    End Sub

    Private Sub btview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btview.Click
        connection_open()
        ds.Clear()
        qry = "select * from Tbl_Employee where status ='False' and dept='" & cmbdept.Text & "'"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_Employee")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub
    Sub view()

        connection_open()
        cmd = New SqlCommand("select * from Tbl_Employee where status ='False' and dept='" & cmbdept.Text & "'", cnn)
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        Grid.Rows.Clear()
        Do While dr.Read = True
            Grid.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20))
        Loop
        connection_close()
    End Sub
    Sub view_all()

        connection_open()
        cmd = New SqlCommand("select * from Tbl_Employee where status ='False'", cnn)
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        Grid.Rows.Clear()
        Do While dr.Read = True
            Grid.Rows.Add(dr(0), dr(1), dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11), dr(12), dr(13), dr(14), dr(15), dr(16), dr(17), dr(18), dr(19), dr(20))
        Loop
        connection_close()
    End Sub

    Private Sub txtbasic_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtbasic.KeyPress

        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtbasic.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtfbf_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtfbf.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtfbf.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtgi_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtgi.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtgi.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtit_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtit.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtit.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtlic_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtlic.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtlic.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtloan_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtloan.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtloan.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtmob_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtmob.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtmob.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtother_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtother.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtother.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtphone_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtphone.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtphone.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtdesg_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtdesg.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtdesg.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtfname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtfname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtfname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtper_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtper.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtper.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtqua_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtqua.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtqua.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txttemp_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txttemp.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txttemp.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub cmbdept_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbdept.SelectedIndexChanged

        If cmbdept.Text = "All.." Then
            view_all()
        Else
            view()
        End If

    End Sub
End Class