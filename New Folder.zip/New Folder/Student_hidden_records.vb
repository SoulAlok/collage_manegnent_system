﻿Imports System.Data.SqlClient

Public Class Student_hidden_records

    Private Sub btrestore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btrestore.Click
        connection_open()
        qry = "update Tbl_std1 set status='false' where Adno='" & txtadno.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        ' Do While 
        cmd.ExecuteNonQuery()
        MsgBox("The Selected Record has been restored", MsgBoxStyle.MsgBoxRight, "Office Automation")
        GridRestore.ClearSelection()
        ds.Clear()

        qry = "select * from Tbl_std1 where status ='True'"
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_std1")
        GridRestore.DataSource = ds
        GridRestore.DataMember = ds.Tables(0).ToString
        txtadno.Text = ""
        connection_close()
        'loop
    End Sub

    Private Sub GridRestore_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles GridRestore.CellContentDoubleClick
        connection_open()
        Dim a = GridRestore.CurrentRow.Index
        txtadno.Text = GridRestore.Item(0, a).Value.ToString
        connection_close()

    End Sub

    Private Sub Student_hidden_records_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connection_open()

        qry = "select * from Tbl_std1 where status='true'"
        ds.Clear()
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_std1")
        GridRestore.DataSource = ds
        GridRestore.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        connection_open()

        Student_Profile.Show()
        ds.Clear()
        qry = "select * from Tbl_std1 where status ='False'"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_std1")
        Student_Profile.Grid.DataSource = ds
        Student_Profile.Grid.DataMember = ds.Tables(0).ToString
        connection_close()


        Me.Close()
    End Sub

    Private Sub txtadno_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtadno.TextChanged

    End Sub
End Class

