﻿Imports System.Data.SqlClient

Module general
    Public con As New SqlConnection("Data Source=PC17;Initial Catalog=SAM_OFFICEAUTOMATION;Integrated Security=True")
    Public qry As String
    Public cmd As SqlCommand
    Public dr As SqlDataReader


End Module
