﻿Imports System.Data.SqlClient

Public Class login
    Sub clear()
        cmbuser.Text = ""
        txtuser.Text = ""
        txtpasswd.Text = ""
    End Sub
    Private Sub btnreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        clear()

    End Sub

    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        con.Open()
        qry = "select * from Tbl_Log where usertype='" & cmbuser.Text & "' and username='" & txtuser.Text & "' and password= '" & txtpasswd.Text & "'"
        cmd = New SqlCommand(qry, con)
        dr = cmd.ExecuteReader()
        If dr.Read = True Then
            MsgBox("login successful", MsgBoxStyle.Information, "login")
            frmmain.Show()
            Me.Hide()
            con.Close()

        Else
            MsgBox("login failure", MsgBoxStyle.Critical, "failure")
            con.Close()

        End If
    End Sub

    Private Sub lnkpasswd_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkpasswd.LinkClicked
        frmchngpasswd.Show()

    End Sub

    Private Sub cmbuser_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbuser.SelectedIndexChanged
        If cmbuser.Text = "ADMIN" Then
            Panelpasswd.Visible = True
        End If
    End Sub

    Private Sub login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
