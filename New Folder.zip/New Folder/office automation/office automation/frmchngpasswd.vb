﻿Imports System.Data.SqlClient

Public Class frmchngpasswd
    Sub clear()
        txtold.Text = ""
        txtnew.Text = ""
        txtconfirm.Text = ""
    End Sub

    Private Sub btnReset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReset.Click
        clear()
    End Sub

    Private Sub btnOk_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOk.Click
        con.Close()
        con.Open()
        qry = "select password from Tbl_Log where username= '" & txtuser.Text & "'"
        cmd = New SqlCommand(qry, con)
        dr = cmd.ExecuteReader
        If dr.Read = True Then
            If txtold.Text = dr(0).ToString Then
                If txtnew.Text = txtconfirm.Text Then
                    con.Close()
                    con.Open()
                    Dim qry2 As String = "update  Tbl_Log set password='" & txtconfirm.Text & "' where username='" & txtuser.Text & "' "
                    cmd = New SqlCommand(qry, con)
                    cmd.ExecuteNonQuery()
                    MsgBox("password changed successfully", MsgBoxStyle.Information, "change")
                End If
            Else
                MsgBox("wrong old password", MsgBoxStyle.Information, "change")
            End If


        End If
        con.Close()
    End Sub
End Class