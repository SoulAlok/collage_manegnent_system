﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Sports
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.Add = New System.Windows.Forms.TabPage
        Me.ad_reset = New System.Windows.Forms.Button
        Me.btnadd = New System.Windows.Forms.Button
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.ad_rdartno = New System.Windows.Forms.RadioButton
        Me.ad_rdarty = New System.Windows.Forms.RadioButton
        Me.Label6 = New System.Windows.Forms.Label
        Me.ad_lstintsports = New System.Windows.Forms.CheckedListBox
        Me.ad_rdno = New System.Windows.Forms.RadioButton
        Me.ad_rdyes = New System.Windows.Forms.RadioButton
        Me.Label5 = New System.Windows.Forms.Label
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.ad_rdsno = New System.Windows.Forms.RadioButton
        Me.ad_rdsyes = New System.Windows.Forms.RadioButton
        Me.ad_lstextact = New System.Windows.Forms.CheckedListBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.ad_lstsports = New System.Windows.Forms.CheckedListBox
        Me.ad_lstscoact = New System.Windows.Forms.CheckedListBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.ad_lstsch = New System.Windows.Forms.CheckedListBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.ad_txtclass = New System.Windows.Forms.TextBox
        Me.ad_txtcourse = New System.Windows.Forms.TextBox
        Me.ad_txtname = New System.Windows.Forms.TextBox
        Me.ad_txtregno = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.label1 = New System.Windows.Forms.Label
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.Edit = New System.Windows.Forms.TabPage
        Me.Delete = New System.Windows.Forms.TabPage
        Me.View = New System.Windows.Forms.TabPage
        Me.ad_rdscyes = New System.Windows.Forms.RadioButton
        Me.ad_rdscno = New System.Windows.Forms.RadioButton
        Me.Button1 = New System.Windows.Forms.Button
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.CheckedListBox1 = New System.Windows.Forms.CheckedListBox
        Me.RadioButton1 = New System.Windows.Forms.RadioButton
        Me.RadioButton2 = New System.Windows.Forms.RadioButton
        Me.Label11 = New System.Windows.Forms.Label
        Me.CheckedListBox2 = New System.Windows.Forms.CheckedListBox
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.RadioButton4 = New System.Windows.Forms.RadioButton
        Me.Label12 = New System.Windows.Forms.Label
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.RadioButton5 = New System.Windows.Forms.RadioButton
        Me.RadioButton6 = New System.Windows.Forms.RadioButton
        Me.CheckedListBox3 = New System.Windows.Forms.CheckedListBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.CheckedListBox4 = New System.Windows.Forms.CheckedListBox
        Me.CheckedListBox5 = New System.Windows.Forms.CheckedListBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.RadioButton7 = New System.Windows.Forms.RadioButton
        Me.RadioButton8 = New System.Windows.Forms.RadioButton
        Me.CheckedListBox6 = New System.Windows.Forms.CheckedListBox
        Me.Label16 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        Me.TextBox2 = New System.Windows.Forms.TextBox
        Me.TextBox3 = New System.Windows.Forms.TextBox
        Me.TextBox4 = New System.Windows.Forms.TextBox
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.PictureBox2 = New System.Windows.Forms.PictureBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.CheckedListBox7 = New System.Windows.Forms.CheckedListBox
        Me.RadioButton9 = New System.Windows.Forms.RadioButton
        Me.RadioButton10 = New System.Windows.Forms.RadioButton
        Me.Label21 = New System.Windows.Forms.Label
        Me.CheckedListBox8 = New System.Windows.Forms.CheckedListBox
        Me.RadioButton11 = New System.Windows.Forms.RadioButton
        Me.RadioButton12 = New System.Windows.Forms.RadioButton
        Me.Label22 = New System.Windows.Forms.Label
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.RadioButton13 = New System.Windows.Forms.RadioButton
        Me.RadioButton14 = New System.Windows.Forms.RadioButton
        Me.CheckedListBox9 = New System.Windows.Forms.CheckedListBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.CheckedListBox10 = New System.Windows.Forms.CheckedListBox
        Me.CheckedListBox11 = New System.Windows.Forms.CheckedListBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.GroupBox9 = New System.Windows.Forms.GroupBox
        Me.RadioButton15 = New System.Windows.Forms.RadioButton
        Me.RadioButton16 = New System.Windows.Forms.RadioButton
        Me.CheckedListBox12 = New System.Windows.Forms.CheckedListBox
        Me.Label26 = New System.Windows.Forms.Label
        Me.TextBox5 = New System.Windows.Forms.TextBox
        Me.TextBox6 = New System.Windows.Forms.TextBox
        Me.TextBox7 = New System.Windows.Forms.TextBox
        Me.TextBox8 = New System.Windows.Forms.TextBox
        Me.Label27 = New System.Windows.Forms.Label
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.Label30 = New System.Windows.Forms.Label
        Me.PictureBox3 = New System.Windows.Forms.PictureBox
        Me.Label31 = New System.Windows.Forms.Label
        Me.ad_lstartsact = New System.Windows.Forms.CheckedListBox
        Me.TabControl1.SuspendLayout()
        Me.Add.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Edit.SuspendLayout()
        Me.Delete.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.Add)
        Me.TabControl1.Controls.Add(Me.Edit)
        Me.TabControl1.Controls.Add(Me.Delete)
        Me.TabControl1.Controls.Add(Me.View)
        Me.TabControl1.ItemSize = New System.Drawing.Size(62, 28)
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(745, 878)
        Me.TabControl1.TabIndex = 0
        '
        'Add
        '
        Me.Add.BackColor = System.Drawing.Color.LavenderBlush
        Me.Add.Controls.Add(Me.ad_reset)
        Me.Add.Controls.Add(Me.btnadd)
        Me.Add.Controls.Add(Me.GroupBox2)
        Me.Add.Controls.Add(Me.GroupBox3)
        Me.Add.Controls.Add(Me.GroupBox1)
        Me.Add.Controls.Add(Me.PictureBox1)
        Me.Add.Location = New System.Drawing.Point(4, 32)
        Me.Add.Name = "Add"
        Me.Add.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.Add.Size = New System.Drawing.Size(737, 842)
        Me.Add.TabIndex = 0
        Me.Add.Text = "Add "
        '
        'ad_reset
        '
        Me.ad_reset.Location = New System.Drawing.Point(226, 700)
        Me.ad_reset.Name = "ad_reset"
        Me.ad_reset.Size = New System.Drawing.Size(75, 46)
        Me.ad_reset.TabIndex = 20
        Me.ad_reset.Text = "Reset"
        Me.ad_reset.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(117, 700)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 46)
        Me.btnadd.TabIndex = 19
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox2.Controls.Add(Me.ad_lstartsact)
        Me.GroupBox2.Controls.Add(Me.ad_rdartno)
        Me.GroupBox2.Controls.Add(Me.ad_rdarty)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.ad_lstintsports)
        Me.GroupBox2.Controls.Add(Me.ad_rdno)
        Me.GroupBox2.Controls.Add(Me.ad_rdyes)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Location = New System.Drawing.Point(387, 431)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(299, 315)
        Me.GroupBox2.TabIndex = 0
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Inter College Events"
        '
        'ad_rdartno
        '
        Me.ad_rdartno.AutoSize = True
        Me.ad_rdartno.Location = New System.Drawing.Point(207, 163)
        Me.ad_rdartno.Name = "ad_rdartno"
        Me.ad_rdartno.Size = New System.Drawing.Size(39, 17)
        Me.ad_rdartno.TabIndex = 17
        Me.ad_rdartno.TabStop = True
        Me.ad_rdartno.Text = "No"
        Me.ad_rdartno.UseVisualStyleBackColor = True
        '
        'ad_rdarty
        '
        Me.ad_rdarty.AutoSize = True
        Me.ad_rdarty.Location = New System.Drawing.Point(111, 163)
        Me.ad_rdarty.Name = "ad_rdarty"
        Me.ad_rdarty.Size = New System.Drawing.Size(43, 17)
        Me.ad_rdarty.TabIndex = 16
        Me.ad_rdarty.TabStop = True
        Me.ad_rdarty.Text = "Yes"
        Me.ad_rdarty.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 165)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(57, 52)
        Me.Label6.TabIndex = 22
        Me.Label6.Text = "Performing" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Arts" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Literature"
        '
        'ad_lstintsports
        '
        Me.ad_lstintsports.FormattingEnabled = True
        Me.ad_lstintsports.Location = New System.Drawing.Point(111, 63)
        Me.ad_lstintsports.Name = "ad_lstintsports"
        Me.ad_lstintsports.Size = New System.Drawing.Size(120, 64)
        Me.ad_lstintsports.Sorted = True
        Me.ad_lstintsports.TabIndex = 15
        '
        'ad_rdno
        '
        Me.ad_rdno.AutoSize = True
        Me.ad_rdno.Location = New System.Drawing.Point(192, 38)
        Me.ad_rdno.Name = "ad_rdno"
        Me.ad_rdno.Size = New System.Drawing.Size(39, 17)
        Me.ad_rdno.TabIndex = 14
        Me.ad_rdno.TabStop = True
        Me.ad_rdno.Text = "No"
        Me.ad_rdno.UseVisualStyleBackColor = True
        '
        'ad_rdyes
        '
        Me.ad_rdyes.AutoSize = True
        Me.ad_rdyes.Location = New System.Drawing.Point(123, 38)
        Me.ad_rdyes.Name = "ad_rdyes"
        Me.ad_rdyes.Size = New System.Drawing.Size(43, 17)
        Me.ad_rdyes.TabIndex = 13
        Me.ad_rdyes.TabStop = True
        Me.ad_rdyes.Text = "Yes"
        Me.ad_rdyes.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(27, 42)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(37, 13)
        Me.Label5.TabIndex = 18
        Me.Label5.Text = "Sports"
        '
        'GroupBox3
        '
        Me.GroupBox3.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox3.Controls.Add(Me.ad_rdsno)
        Me.GroupBox3.Controls.Add(Me.ad_rdsyes)
        Me.GroupBox3.Controls.Add(Me.ad_lstextact)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.ad_lstsports)
        Me.GroupBox3.Controls.Add(Me.ad_lstscoact)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Location = New System.Drawing.Point(387, 17)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(299, 402)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Intra College Event"
        '
        'ad_rdsno
        '
        Me.ad_rdsno.AutoSize = True
        Me.ad_rdsno.Location = New System.Drawing.Point(192, 261)
        Me.ad_rdsno.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ad_rdsno.Name = "ad_rdsno"
        Me.ad_rdsno.Size = New System.Drawing.Size(39, 17)
        Me.ad_rdsno.TabIndex = 11
        Me.ad_rdsno.TabStop = True
        Me.ad_rdsno.Text = "No"
        Me.ad_rdsno.UseVisualStyleBackColor = True
        '
        'ad_rdsyes
        '
        Me.ad_rdsyes.AutoSize = True
        Me.ad_rdsyes.Location = New System.Drawing.Point(111, 261)
        Me.ad_rdsyes.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ad_rdsyes.Name = "ad_rdsyes"
        Me.ad_rdsyes.Size = New System.Drawing.Size(43, 17)
        Me.ad_rdsyes.TabIndex = 10
        Me.ad_rdsyes.TabStop = True
        Me.ad_rdsyes.Text = "Yes"
        Me.ad_rdsyes.UseVisualStyleBackColor = True
        '
        'ad_lstextact
        '
        Me.ad_lstextact.FormattingEnabled = True
        Me.ad_lstextact.Location = New System.Drawing.Point(111, 150)
        Me.ad_lstextact.Name = "ad_lstextact"
        Me.ad_lstextact.Size = New System.Drawing.Size(120, 79)
        Me.ad_lstextact.Sorted = True
        Me.ad_lstextact.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(16, 150)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(78, 26)
        Me.Label10.TabIndex = 16
        Me.Label10.Text = "Extra Curricular" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Activities"
        '
        'ad_lstsports
        '
        Me.ad_lstsports.FormattingEnabled = True
        Me.ad_lstsports.Location = New System.Drawing.Point(111, 292)
        Me.ad_lstsports.Name = "ad_lstsports"
        Me.ad_lstsports.Size = New System.Drawing.Size(120, 64)
        Me.ad_lstsports.Sorted = True
        Me.ad_lstsports.TabIndex = 12
        '
        'ad_lstscoact
        '
        Me.ad_lstscoact.FormattingEnabled = True
        Me.ad_lstscoact.Location = New System.Drawing.Point(111, 41)
        Me.ad_lstscoact.Name = "ad_lstscoact"
        Me.ad_lstscoact.Size = New System.Drawing.Size(120, 79)
        Me.ad_lstscoact.Sorted = True
        Me.ad_lstscoact.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(27, 262)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(37, 13)
        Me.Label8.TabIndex = 12
        Me.Label8.Text = "Sports"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(16, 41)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(67, 13)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Co-Curricular"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox1.Controls.Add(Me.Label31)
        Me.GroupBox1.Controls.Add(Me.ad_rdscno)
        Me.GroupBox1.Controls.Add(Me.ad_rdscyes)
        Me.GroupBox1.Controls.Add(Me.ad_lstsch)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.ad_txtclass)
        Me.GroupBox1.Controls.Add(Me.ad_txtcourse)
        Me.GroupBox1.Controls.Add(Me.ad_txtname)
        Me.GroupBox1.Controls.Add(Me.ad_txtregno)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.label1)
        Me.GroupBox1.Location = New System.Drawing.Point(25, 348)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(302, 329)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Student Info"
        '
        'ad_lstsch
        '
        Me.ad_lstsch.FormattingEnabled = True
        Me.ad_lstsch.Location = New System.Drawing.Point(124, 212)
        Me.ad_lstsch.Name = "ad_lstsch"
        Me.ad_lstsch.Size = New System.Drawing.Size(120, 79)
        Me.ad_lstsch.Sorted = True
        Me.ad_lstsch.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(50, 183)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(62, 13)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "Scholarship"
        '
        'ad_txtclass
        '
        Me.ad_txtclass.Location = New System.Drawing.Point(124, 150)
        Me.ad_txtclass.Name = "ad_txtclass"
        Me.ad_txtclass.Size = New System.Drawing.Size(100, 20)
        Me.ad_txtclass.TabIndex = 4
        '
        'ad_txtcourse
        '
        Me.ad_txtcourse.Location = New System.Drawing.Point(124, 114)
        Me.ad_txtcourse.Name = "ad_txtcourse"
        Me.ad_txtcourse.Size = New System.Drawing.Size(100, 20)
        Me.ad_txtcourse.TabIndex = 3
        '
        'ad_txtname
        '
        Me.ad_txtname.Location = New System.Drawing.Point(124, 83)
        Me.ad_txtname.Name = "ad_txtname"
        Me.ad_txtname.Size = New System.Drawing.Size(100, 20)
        Me.ad_txtname.TabIndex = 2
        '
        'ad_txtregno
        '
        Me.ad_txtregno.Location = New System.Drawing.Point(124, 50)
        Me.ad_txtregno.Name = "ad_txtregno"
        Me.ad_txtregno.Size = New System.Drawing.Size(100, 20)
        Me.ad_txtregno.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(50, 150)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(32, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Class"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(50, 114)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(40, 13)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Course"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(50, 83)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(35, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Name"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Location = New System.Drawing.Point(50, 53)
        Me.label1.Name = "label1"
        Me.label1.Size = New System.Drawing.Size(44, 13)
        Me.label1.TabIndex = 5
        Me.label1.Text = "Reg No"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.otheractivities
        Me.PictureBox1.Location = New System.Drawing.Point(25, 17)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(302, 313)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'Edit
        '
        Me.Edit.BackColor = System.Drawing.Color.LavenderBlush
        Me.Edit.Controls.Add(Me.Button1)
        Me.Edit.Controls.Add(Me.GroupBox4)
        Me.Edit.Controls.Add(Me.GroupBox5)
        Me.Edit.Controls.Add(Me.GroupBox6)
        Me.Edit.Controls.Add(Me.PictureBox2)
        Me.Edit.Location = New System.Drawing.Point(4, 32)
        Me.Edit.Name = "Edit"
        Me.Edit.Padding = New System.Windows.Forms.Padding(3, 3, 3, 3)
        Me.Edit.Size = New System.Drawing.Size(737, 842)
        Me.Edit.TabIndex = 1
        Me.Edit.Text = "Edit"
        '
        'Delete
        '
        Me.Delete.BackColor = System.Drawing.Color.LavenderBlush
        Me.Delete.Controls.Add(Me.Button2)
        Me.Delete.Controls.Add(Me.GroupBox7)
        Me.Delete.Controls.Add(Me.GroupBox8)
        Me.Delete.Controls.Add(Me.GroupBox9)
        Me.Delete.Controls.Add(Me.PictureBox3)
        Me.Delete.Location = New System.Drawing.Point(4, 32)
        Me.Delete.Name = "Delete"
        Me.Delete.Size = New System.Drawing.Size(737, 842)
        Me.Delete.TabIndex = 2
        Me.Delete.Text = "Delete"
        '
        'View
        '
        Me.View.BackColor = System.Drawing.Color.LavenderBlush
        Me.View.Location = New System.Drawing.Point(4, 32)
        Me.View.Name = "View"
        Me.View.Size = New System.Drawing.Size(737, 842)
        Me.View.TabIndex = 3
        Me.View.Text = "View"
        '
        'ad_rdscyes
        '
        Me.ad_rdscyes.AutoSize = True
        Me.ad_rdscyes.Location = New System.Drawing.Point(124, 183)
        Me.ad_rdscyes.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ad_rdscyes.Name = "ad_rdscyes"
        Me.ad_rdscyes.Size = New System.Drawing.Size(43, 17)
        Me.ad_rdscyes.TabIndex = 5
        Me.ad_rdscyes.TabStop = True
        Me.ad_rdscyes.Text = "Yes"
        Me.ad_rdscyes.UseVisualStyleBackColor = True
        '
        'ad_rdscno
        '
        Me.ad_rdscno.AutoSize = True
        Me.ad_rdscno.Location = New System.Drawing.Point(190, 183)
        Me.ad_rdscno.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.ad_rdscno.Name = "ad_rdscno"
        Me.ad_rdscno.Size = New System.Drawing.Size(39, 17)
        Me.ad_rdscno.TabIndex = 6
        Me.ad_rdscno.TabStop = True
        Me.ad_rdscno.Text = "No"
        Me.ad_rdscno.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(239, 704)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 46)
        Me.Button1.TabIndex = 25
        Me.Button1.Text = "Reset"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox4.Controls.Add(Me.CheckedListBox1)
        Me.GroupBox4.Controls.Add(Me.RadioButton1)
        Me.GroupBox4.Controls.Add(Me.RadioButton2)
        Me.GroupBox4.Controls.Add(Me.Label11)
        Me.GroupBox4.Controls.Add(Me.CheckedListBox2)
        Me.GroupBox4.Controls.Add(Me.RadioButton3)
        Me.GroupBox4.Controls.Add(Me.RadioButton4)
        Me.GroupBox4.Controls.Add(Me.Label12)
        Me.GroupBox4.Location = New System.Drawing.Point(381, 435)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(299, 315)
        Me.GroupBox4.TabIndex = 21
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Inter College Events"
        '
        'CheckedListBox1
        '
        Me.CheckedListBox1.FormattingEnabled = True
        Me.CheckedListBox1.Location = New System.Drawing.Point(111, 187)
        Me.CheckedListBox1.Name = "CheckedListBox1"
        Me.CheckedListBox1.Size = New System.Drawing.Size(120, 34)
        Me.CheckedListBox1.Sorted = True
        Me.CheckedListBox1.TabIndex = 18
        '
        'RadioButton1
        '
        Me.RadioButton1.AutoSize = True
        Me.RadioButton1.Location = New System.Drawing.Point(207, 163)
        Me.RadioButton1.Name = "RadioButton1"
        Me.RadioButton1.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton1.TabIndex = 17
        Me.RadioButton1.TabStop = True
        Me.RadioButton1.Text = "No"
        Me.RadioButton1.UseVisualStyleBackColor = True
        '
        'RadioButton2
        '
        Me.RadioButton2.AutoSize = True
        Me.RadioButton2.Location = New System.Drawing.Point(111, 163)
        Me.RadioButton2.Name = "RadioButton2"
        Me.RadioButton2.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton2.TabIndex = 16
        Me.RadioButton2.TabStop = True
        Me.RadioButton2.Text = "Yes"
        Me.RadioButton2.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(27, 165)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(57, 52)
        Me.Label11.TabIndex = 22
        Me.Label11.Text = "Performing" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Arts" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Literature"
        '
        'CheckedListBox2
        '
        Me.CheckedListBox2.FormattingEnabled = True
        Me.CheckedListBox2.Location = New System.Drawing.Point(111, 63)
        Me.CheckedListBox2.Name = "CheckedListBox2"
        Me.CheckedListBox2.Size = New System.Drawing.Size(120, 64)
        Me.CheckedListBox2.Sorted = True
        Me.CheckedListBox2.TabIndex = 15
        '
        'RadioButton3
        '
        Me.RadioButton3.AutoSize = True
        Me.RadioButton3.Location = New System.Drawing.Point(192, 38)
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton3.TabIndex = 14
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.Text = "No"
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AutoSize = True
        Me.RadioButton4.Location = New System.Drawing.Point(123, 38)
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton4.TabIndex = 13
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.Text = "Yes"
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(27, 42)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 13)
        Me.Label12.TabIndex = 18
        Me.Label12.Text = "Sports"
        '
        'GroupBox5
        '
        Me.GroupBox5.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox5.Controls.Add(Me.RadioButton5)
        Me.GroupBox5.Controls.Add(Me.RadioButton6)
        Me.GroupBox5.Controls.Add(Me.CheckedListBox3)
        Me.GroupBox5.Controls.Add(Me.Label13)
        Me.GroupBox5.Controls.Add(Me.CheckedListBox4)
        Me.GroupBox5.Controls.Add(Me.CheckedListBox5)
        Me.GroupBox5.Controls.Add(Me.Label14)
        Me.GroupBox5.Controls.Add(Me.Label15)
        Me.GroupBox5.Location = New System.Drawing.Point(381, 27)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(299, 402)
        Me.GroupBox5.TabIndex = 24
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Intra College Event"
        '
        'RadioButton5
        '
        Me.RadioButton5.AutoSize = True
        Me.RadioButton5.Location = New System.Drawing.Point(192, 261)
        Me.RadioButton5.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton5.Name = "RadioButton5"
        Me.RadioButton5.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton5.TabIndex = 11
        Me.RadioButton5.TabStop = True
        Me.RadioButton5.Text = "No"
        Me.RadioButton5.UseVisualStyleBackColor = True
        '
        'RadioButton6
        '
        Me.RadioButton6.AutoSize = True
        Me.RadioButton6.Location = New System.Drawing.Point(111, 261)
        Me.RadioButton6.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton6.Name = "RadioButton6"
        Me.RadioButton6.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton6.TabIndex = 10
        Me.RadioButton6.TabStop = True
        Me.RadioButton6.Text = "Yes"
        Me.RadioButton6.UseVisualStyleBackColor = True
        '
        'CheckedListBox3
        '
        Me.CheckedListBox3.FormattingEnabled = True
        Me.CheckedListBox3.Location = New System.Drawing.Point(111, 150)
        Me.CheckedListBox3.Name = "CheckedListBox3"
        Me.CheckedListBox3.Size = New System.Drawing.Size(120, 79)
        Me.CheckedListBox3.Sorted = True
        Me.CheckedListBox3.TabIndex = 9
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(16, 150)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(78, 26)
        Me.Label13.TabIndex = 16
        Me.Label13.Text = "Extra Curricular" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Activities"
        '
        'CheckedListBox4
        '
        Me.CheckedListBox4.FormattingEnabled = True
        Me.CheckedListBox4.Location = New System.Drawing.Point(111, 292)
        Me.CheckedListBox4.Name = "CheckedListBox4"
        Me.CheckedListBox4.Size = New System.Drawing.Size(120, 64)
        Me.CheckedListBox4.Sorted = True
        Me.CheckedListBox4.TabIndex = 12
        '
        'CheckedListBox5
        '
        Me.CheckedListBox5.FormattingEnabled = True
        Me.CheckedListBox5.Location = New System.Drawing.Point(111, 41)
        Me.CheckedListBox5.Name = "CheckedListBox5"
        Me.CheckedListBox5.Size = New System.Drawing.Size(120, 79)
        Me.CheckedListBox5.Sorted = True
        Me.CheckedListBox5.TabIndex = 8
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(27, 262)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(37, 13)
        Me.Label14.TabIndex = 12
        Me.Label14.Text = "Sports"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(16, 41)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(67, 13)
        Me.Label15.TabIndex = 11
        Me.Label15.Text = "Co-Curricular"
        '
        'GroupBox6
        '
        Me.GroupBox6.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox6.Controls.Add(Me.RadioButton7)
        Me.GroupBox6.Controls.Add(Me.RadioButton8)
        Me.GroupBox6.Controls.Add(Me.CheckedListBox6)
        Me.GroupBox6.Controls.Add(Me.Label16)
        Me.GroupBox6.Controls.Add(Me.TextBox1)
        Me.GroupBox6.Controls.Add(Me.TextBox2)
        Me.GroupBox6.Controls.Add(Me.TextBox3)
        Me.GroupBox6.Controls.Add(Me.TextBox4)
        Me.GroupBox6.Controls.Add(Me.Label17)
        Me.GroupBox6.Controls.Add(Me.Label18)
        Me.GroupBox6.Controls.Add(Me.Label19)
        Me.GroupBox6.Controls.Add(Me.Label20)
        Me.GroupBox6.Location = New System.Drawing.Point(38, 359)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(302, 329)
        Me.GroupBox6.TabIndex = 23
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Student Info"
        '
        'RadioButton7
        '
        Me.RadioButton7.AutoSize = True
        Me.RadioButton7.Location = New System.Drawing.Point(190, 183)
        Me.RadioButton7.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton7.Name = "RadioButton7"
        Me.RadioButton7.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton7.TabIndex = 6
        Me.RadioButton7.TabStop = True
        Me.RadioButton7.Text = "No"
        Me.RadioButton7.UseVisualStyleBackColor = True
        '
        'RadioButton8
        '
        Me.RadioButton8.AutoSize = True
        Me.RadioButton8.Location = New System.Drawing.Point(124, 183)
        Me.RadioButton8.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton8.Name = "RadioButton8"
        Me.RadioButton8.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton8.TabIndex = 5
        Me.RadioButton8.TabStop = True
        Me.RadioButton8.Text = "Yes"
        Me.RadioButton8.UseVisualStyleBackColor = True
        '
        'CheckedListBox6
        '
        Me.CheckedListBox6.FormattingEnabled = True
        Me.CheckedListBox6.Location = New System.Drawing.Point(124, 212)
        Me.CheckedListBox6.Name = "CheckedListBox6"
        Me.CheckedListBox6.Size = New System.Drawing.Size(120, 79)
        Me.CheckedListBox6.Sorted = True
        Me.CheckedListBox6.TabIndex = 7
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Location = New System.Drawing.Point(50, 183)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(62, 13)
        Me.Label16.TabIndex = 13
        Me.Label16.Text = "Scholarship"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(124, 150)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 20)
        Me.TextBox1.TabIndex = 4
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(124, 114)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 20)
        Me.TextBox2.TabIndex = 3
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(124, 83)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 20)
        Me.TextBox3.TabIndex = 2
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(124, 50)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 20)
        Me.TextBox4.TabIndex = 1
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(50, 150)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(32, 13)
        Me.Label17.TabIndex = 8
        Me.Label17.Text = "Class"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(50, 114)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(40, 13)
        Me.Label18.TabIndex = 7
        Me.Label18.Text = "Course"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(50, 83)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(35, 13)
        Me.Label19.TabIndex = 6
        Me.Label19.Text = "Name"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(50, 53)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(44, 13)
        Me.Label20.TabIndex = 5
        Me.Label20.Text = "Reg No"
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.office.My.Resources.Resources.otheractivities
        Me.PictureBox2.Location = New System.Drawing.Point(38, 22)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(302, 313)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox2.TabIndex = 22
        Me.PictureBox2.TabStop = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(227, 695)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 46)
        Me.Button2.TabIndex = 25
        Me.Button2.Text = "Reset"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox7.Controls.Add(Me.CheckedListBox7)
        Me.GroupBox7.Controls.Add(Me.RadioButton9)
        Me.GroupBox7.Controls.Add(Me.RadioButton10)
        Me.GroupBox7.Controls.Add(Me.Label21)
        Me.GroupBox7.Controls.Add(Me.CheckedListBox8)
        Me.GroupBox7.Controls.Add(Me.RadioButton11)
        Me.GroupBox7.Controls.Add(Me.RadioButton12)
        Me.GroupBox7.Controls.Add(Me.Label22)
        Me.GroupBox7.Location = New System.Drawing.Point(388, 426)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(299, 315)
        Me.GroupBox7.TabIndex = 21
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Inter College Events"
        '
        'CheckedListBox7
        '
        Me.CheckedListBox7.FormattingEnabled = True
        Me.CheckedListBox7.Location = New System.Drawing.Point(111, 187)
        Me.CheckedListBox7.Name = "CheckedListBox7"
        Me.CheckedListBox7.Size = New System.Drawing.Size(120, 34)
        Me.CheckedListBox7.Sorted = True
        Me.CheckedListBox7.TabIndex = 18
        '
        'RadioButton9
        '
        Me.RadioButton9.AutoSize = True
        Me.RadioButton9.Location = New System.Drawing.Point(207, 163)
        Me.RadioButton9.Name = "RadioButton9"
        Me.RadioButton9.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton9.TabIndex = 17
        Me.RadioButton9.TabStop = True
        Me.RadioButton9.Text = "No"
        Me.RadioButton9.UseVisualStyleBackColor = True
        '
        'RadioButton10
        '
        Me.RadioButton10.AutoSize = True
        Me.RadioButton10.Location = New System.Drawing.Point(111, 163)
        Me.RadioButton10.Name = "RadioButton10"
        Me.RadioButton10.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton10.TabIndex = 16
        Me.RadioButton10.TabStop = True
        Me.RadioButton10.Text = "Yes"
        Me.RadioButton10.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(27, 165)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(57, 52)
        Me.Label21.TabIndex = 22
        Me.Label21.Text = "Performing" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Arts" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " and" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Literature"
        '
        'CheckedListBox8
        '
        Me.CheckedListBox8.FormattingEnabled = True
        Me.CheckedListBox8.Location = New System.Drawing.Point(111, 63)
        Me.CheckedListBox8.Name = "CheckedListBox8"
        Me.CheckedListBox8.Size = New System.Drawing.Size(120, 64)
        Me.CheckedListBox8.Sorted = True
        Me.CheckedListBox8.TabIndex = 15
        '
        'RadioButton11
        '
        Me.RadioButton11.AutoSize = True
        Me.RadioButton11.Location = New System.Drawing.Point(192, 38)
        Me.RadioButton11.Name = "RadioButton11"
        Me.RadioButton11.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton11.TabIndex = 14
        Me.RadioButton11.TabStop = True
        Me.RadioButton11.Text = "No"
        Me.RadioButton11.UseVisualStyleBackColor = True
        '
        'RadioButton12
        '
        Me.RadioButton12.AutoSize = True
        Me.RadioButton12.Location = New System.Drawing.Point(123, 38)
        Me.RadioButton12.Name = "RadioButton12"
        Me.RadioButton12.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton12.TabIndex = 13
        Me.RadioButton12.TabStop = True
        Me.RadioButton12.Text = "Yes"
        Me.RadioButton12.UseVisualStyleBackColor = True
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(27, 42)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(37, 13)
        Me.Label22.TabIndex = 18
        Me.Label22.Text = "Sports"
        '
        'GroupBox8
        '
        Me.GroupBox8.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox8.Controls.Add(Me.RadioButton13)
        Me.GroupBox8.Controls.Add(Me.RadioButton14)
        Me.GroupBox8.Controls.Add(Me.CheckedListBox9)
        Me.GroupBox8.Controls.Add(Me.Label23)
        Me.GroupBox8.Controls.Add(Me.CheckedListBox10)
        Me.GroupBox8.Controls.Add(Me.CheckedListBox11)
        Me.GroupBox8.Controls.Add(Me.Label24)
        Me.GroupBox8.Controls.Add(Me.Label25)
        Me.GroupBox8.Location = New System.Drawing.Point(388, 12)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(299, 402)
        Me.GroupBox8.TabIndex = 24
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Intra College Event"
        '
        'RadioButton13
        '
        Me.RadioButton13.AutoSize = True
        Me.RadioButton13.Location = New System.Drawing.Point(192, 261)
        Me.RadioButton13.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton13.Name = "RadioButton13"
        Me.RadioButton13.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton13.TabIndex = 11
        Me.RadioButton13.TabStop = True
        Me.RadioButton13.Text = "No"
        Me.RadioButton13.UseVisualStyleBackColor = True
        '
        'RadioButton14
        '
        Me.RadioButton14.AutoSize = True
        Me.RadioButton14.Location = New System.Drawing.Point(111, 261)
        Me.RadioButton14.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton14.Name = "RadioButton14"
        Me.RadioButton14.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton14.TabIndex = 10
        Me.RadioButton14.TabStop = True
        Me.RadioButton14.Text = "Yes"
        Me.RadioButton14.UseVisualStyleBackColor = True
        '
        'CheckedListBox9
        '
        Me.CheckedListBox9.FormattingEnabled = True
        Me.CheckedListBox9.Location = New System.Drawing.Point(111, 150)
        Me.CheckedListBox9.Name = "CheckedListBox9"
        Me.CheckedListBox9.Size = New System.Drawing.Size(120, 79)
        Me.CheckedListBox9.Sorted = True
        Me.CheckedListBox9.TabIndex = 9
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(16, 150)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(78, 26)
        Me.Label23.TabIndex = 16
        Me.Label23.Text = "Extra Curricular" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & " Activities"
        '
        'CheckedListBox10
        '
        Me.CheckedListBox10.FormattingEnabled = True
        Me.CheckedListBox10.Location = New System.Drawing.Point(111, 292)
        Me.CheckedListBox10.Name = "CheckedListBox10"
        Me.CheckedListBox10.Size = New System.Drawing.Size(120, 64)
        Me.CheckedListBox10.Sorted = True
        Me.CheckedListBox10.TabIndex = 12
        '
        'CheckedListBox11
        '
        Me.CheckedListBox11.FormattingEnabled = True
        Me.CheckedListBox11.Location = New System.Drawing.Point(111, 41)
        Me.CheckedListBox11.Name = "CheckedListBox11"
        Me.CheckedListBox11.Size = New System.Drawing.Size(120, 79)
        Me.CheckedListBox11.Sorted = True
        Me.CheckedListBox11.TabIndex = 8
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(27, 262)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(37, 13)
        Me.Label24.TabIndex = 12
        Me.Label24.Text = "Sports"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(16, 41)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(67, 13)
        Me.Label25.TabIndex = 11
        Me.Label25.Text = "Co-Curricular"
        '
        'GroupBox9
        '
        Me.GroupBox9.BackColor = System.Drawing.Color.Wheat
        Me.GroupBox9.Controls.Add(Me.RadioButton15)
        Me.GroupBox9.Controls.Add(Me.RadioButton16)
        Me.GroupBox9.Controls.Add(Me.CheckedListBox12)
        Me.GroupBox9.Controls.Add(Me.Label26)
        Me.GroupBox9.Controls.Add(Me.TextBox5)
        Me.GroupBox9.Controls.Add(Me.TextBox6)
        Me.GroupBox9.Controls.Add(Me.TextBox7)
        Me.GroupBox9.Controls.Add(Me.TextBox8)
        Me.GroupBox9.Controls.Add(Me.Label27)
        Me.GroupBox9.Controls.Add(Me.Label28)
        Me.GroupBox9.Controls.Add(Me.Label29)
        Me.GroupBox9.Controls.Add(Me.Label30)
        Me.GroupBox9.Location = New System.Drawing.Point(26, 343)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(302, 329)
        Me.GroupBox9.TabIndex = 23
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Student Info"
        '
        'RadioButton15
        '
        Me.RadioButton15.AutoSize = True
        Me.RadioButton15.Location = New System.Drawing.Point(190, 183)
        Me.RadioButton15.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton15.Name = "RadioButton15"
        Me.RadioButton15.Size = New System.Drawing.Size(39, 17)
        Me.RadioButton15.TabIndex = 6
        Me.RadioButton15.TabStop = True
        Me.RadioButton15.Text = "No"
        Me.RadioButton15.UseVisualStyleBackColor = True
        '
        'RadioButton16
        '
        Me.RadioButton16.AutoSize = True
        Me.RadioButton16.Location = New System.Drawing.Point(124, 183)
        Me.RadioButton16.Margin = New System.Windows.Forms.Padding(2)
        Me.RadioButton16.Name = "RadioButton16"
        Me.RadioButton16.Size = New System.Drawing.Size(43, 17)
        Me.RadioButton16.TabIndex = 5
        Me.RadioButton16.TabStop = True
        Me.RadioButton16.Text = "Yes"
        Me.RadioButton16.UseVisualStyleBackColor = True
        '
        'CheckedListBox12
        '
        Me.CheckedListBox12.FormattingEnabled = True
        Me.CheckedListBox12.Location = New System.Drawing.Point(124, 212)
        Me.CheckedListBox12.Name = "CheckedListBox12"
        Me.CheckedListBox12.Size = New System.Drawing.Size(120, 79)
        Me.CheckedListBox12.Sorted = True
        Me.CheckedListBox12.TabIndex = 7
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(50, 183)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(62, 13)
        Me.Label26.TabIndex = 13
        Me.Label26.Text = "Scholarship"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(124, 150)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 20)
        Me.TextBox5.TabIndex = 4
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(124, 114)
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(100, 20)
        Me.TextBox6.TabIndex = 3
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(124, 83)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(100, 20)
        Me.TextBox7.TabIndex = 2
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(124, 50)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 20)
        Me.TextBox8.TabIndex = 1
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(50, 150)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(32, 13)
        Me.Label27.TabIndex = 8
        Me.Label27.Text = "Class"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(50, 114)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(40, 13)
        Me.Label28.TabIndex = 7
        Me.Label28.Text = "Course"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(50, 83)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(35, 13)
        Me.Label29.TabIndex = 6
        Me.Label29.Text = "Name"
        '
        'Label30
        '
        Me.Label30.AutoSize = True
        Me.Label30.Location = New System.Drawing.Point(50, 53)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(44, 13)
        Me.Label30.TabIndex = 5
        Me.Label30.Text = "Reg No"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.office.My.Resources.Resources.otheractivities
        Me.PictureBox3.Location = New System.Drawing.Point(26, 12)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(302, 313)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox3.TabIndex = 22
        Me.PictureBox3.TabStop = False
        '
        'Label31
        '
        Me.Label31.AutoSize = True
        Me.Label31.Location = New System.Drawing.Point(230, 57)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(11, 13)
        Me.Label31.TabIndex = 14
        Me.Label31.Text = "*"
        '
        'ad_lstartsact
        '
        Me.ad_lstartsact.FormattingEnabled = True
        Me.ad_lstartsact.Location = New System.Drawing.Point(111, 187)
        Me.ad_lstartsact.Name = "ad_lstartsact"
        Me.ad_lstartsact.Size = New System.Drawing.Size(120, 34)
        Me.ad_lstartsact.Sorted = True
        Me.ad_lstartsact.TabIndex = 18
        '
        'Sports
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.SlateGray
        Me.ClientSize = New System.Drawing.Size(722, 799)
        Me.Controls.Add(Me.TabControl1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Name = "Sports"
        Me.Text = "Sports"
        Me.TabControl1.ResumeLayout(False)
        Me.Add.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Edit.ResumeLayout(False)
        Me.Delete.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox9.ResumeLayout(False)
        Me.GroupBox9.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents Add As System.Windows.Forms.TabPage
    Friend WithEvents Edit As System.Windows.Forms.TabPage
    Friend WithEvents Delete As System.Windows.Forms.TabPage
    Friend WithEvents View As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents ad_reset As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents label1 As System.Windows.Forms.Label
    Friend WithEvents ad_txtregno As System.Windows.Forms.TextBox
    Friend WithEvents ad_txtcourse As System.Windows.Forms.TextBox
    Friend WithEvents ad_txtname As System.Windows.Forms.TextBox
    Friend WithEvents ad_txtclass As System.Windows.Forms.TextBox
    Friend WithEvents ad_lstscoact As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents ad_lstsports As System.Windows.Forms.CheckedListBox
    Friend WithEvents ad_lstintsports As System.Windows.Forms.CheckedListBox
    Friend WithEvents ad_rdno As System.Windows.Forms.RadioButton
    Friend WithEvents ad_rdyes As System.Windows.Forms.RadioButton
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents ad_lstextact As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents ad_lstsch As System.Windows.Forms.CheckedListBox
    Friend WithEvents ad_rdartno As System.Windows.Forms.RadioButton
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents ad_rdarty As System.Windows.Forms.RadioButton
    Friend WithEvents ad_rdsno As System.Windows.Forms.RadioButton
    Friend WithEvents ad_rdsyes As System.Windows.Forms.RadioButton
    Friend WithEvents ad_rdscno As System.Windows.Forms.RadioButton
    Friend WithEvents ad_rdscyes As System.Windows.Forms.RadioButton
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckedListBox1 As System.Windows.Forms.CheckedListBox
    Friend WithEvents RadioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents CheckedListBox2 As System.Windows.Forms.CheckedListBox
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton5 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton6 As System.Windows.Forms.RadioButton
    Friend WithEvents CheckedListBox3 As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents CheckedListBox4 As System.Windows.Forms.CheckedListBox
    Friend WithEvents CheckedListBox5 As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton7 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton8 As System.Windows.Forms.RadioButton
    Friend WithEvents CheckedListBox6 As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckedListBox7 As System.Windows.Forms.CheckedListBox
    Friend WithEvents RadioButton9 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton10 As System.Windows.Forms.RadioButton
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents CheckedListBox8 As System.Windows.Forms.CheckedListBox
    Friend WithEvents RadioButton11 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton12 As System.Windows.Forms.RadioButton
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton13 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton14 As System.Windows.Forms.RadioButton
    Friend WithEvents CheckedListBox9 As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents CheckedListBox10 As System.Windows.Forms.CheckedListBox
    Friend WithEvents CheckedListBox11 As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents GroupBox9 As System.Windows.Forms.GroupBox
    Friend WithEvents RadioButton15 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton16 As System.Windows.Forms.RadioButton
    Friend WithEvents CheckedListBox12 As System.Windows.Forms.CheckedListBox
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents ad_lstartsact As System.Windows.Forms.CheckedListBox
End Class
