﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Salary
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.txtid = New System.Windows.Forms.TextBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.txtbasic = New System.Windows.Forms.TextBox
        Me.txtda = New System.Windows.Forms.TextBox
        Me.txthra = New System.Windows.Forms.TextBox
        Me.txtgross = New System.Windows.Forms.TextBox
        Me.txtlic = New System.Windows.Forms.TextBox
        Me.txtother = New System.Windows.Forms.TextBox
        Me.txtpf = New System.Windows.Forms.TextBox
        Me.txtit = New System.Windows.Forms.TextBox
        Me.txttotal = New System.Windows.Forms.TextBox
        Me.txtpt = New System.Windows.Forms.TextBox
        Me.txtnet = New System.Windows.Forms.TextBox
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.txtdesg = New System.Windows.Forms.TextBox
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.cmbdept = New System.Windows.Forms.ComboBox
        Me.btcalculate = New System.Windows.Forms.Button
        Me.Label17 = New System.Windows.Forms.Label
        Me.cmbmonth = New System.Windows.Forms.ComboBox
        Me.btview = New System.Windows.Forms.Button
        Me.Label18 = New System.Windows.Forms.Label
        Me.txtgi = New System.Windows.Forms.TextBox
        Me.txtfbf = New System.Windows.Forms.TextBox
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtloan = New System.Windows.Forms.TextBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(8, 69)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 14)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = " Staff Id"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(5, 134)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 14)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(5, 180)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(72, 14)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Designation"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(8, 233)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(72, 14)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Basic Salary"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(17, 268)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(22, 14)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "DA"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(17, 309)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 14)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "HRA"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(17, 354)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(63, 14)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Gross Pay"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(252, 72)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(25, 14)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "LIC"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(222, 104)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(96, 14)
        Me.Label10.TabIndex = 9
        Me.Label10.Text = "Other Deduction"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(227, 230)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(20, 14)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "PF"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(222, 268)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(70, 14)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "Income Tax"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(222, 303)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(70, 14)
        Me.Label13.TabIndex = 12
        Me.Label13.Text = "Total salary"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(222, 333)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(94, 14)
        Me.Label14.TabIndex = 13
        Me.Label14.Text = "Proffession Tax"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(227, 371)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(47, 14)
        Me.Label15.TabIndex = 14
        Me.Label15.Text = "Net Pay"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(5, 24)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(72, 14)
        Me.Label16.TabIndex = 15
        Me.Label16.Text = "Department"
        '
        'txtid
        '
        Me.txtid.Location = New System.Drawing.Point(95, 69)
        Me.txtid.Name = "txtid"
        Me.txtid.Size = New System.Drawing.Size(100, 20)
        Me.txtid.TabIndex = 16
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(95, 131)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 20)
        Me.txtname.TabIndex = 17
        '
        'txtbasic
        '
        Me.txtbasic.Location = New System.Drawing.Point(95, 230)
        Me.txtbasic.Name = "txtbasic"
        Me.txtbasic.Size = New System.Drawing.Size(100, 20)
        Me.txtbasic.TabIndex = 20
        '
        'txtda
        '
        Me.txtda.Location = New System.Drawing.Point(104, 262)
        Me.txtda.Name = "txtda"
        Me.txtda.Size = New System.Drawing.Size(100, 20)
        Me.txtda.TabIndex = 21
        Me.txtda.Text = "56.25 "
        '
        'txthra
        '
        Me.txthra.Location = New System.Drawing.Point(104, 303)
        Me.txthra.Name = "txthra"
        Me.txthra.Size = New System.Drawing.Size(100, 20)
        Me.txthra.TabIndex = 22
        Me.txthra.Text = "7 "
        '
        'txtgross
        '
        Me.txtgross.Location = New System.Drawing.Point(104, 351)
        Me.txtgross.Name = "txtgross"
        Me.txtgross.Size = New System.Drawing.Size(100, 20)
        Me.txtgross.TabIndex = 23
        '
        'txtlic
        '
        Me.txtlic.Location = New System.Drawing.Point(347, 75)
        Me.txtlic.Name = "txtlic"
        Me.txtlic.Size = New System.Drawing.Size(100, 20)
        Me.txtlic.TabIndex = 25
        '
        'txtother
        '
        Me.txtother.Location = New System.Drawing.Point(347, 101)
        Me.txtother.Name = "txtother"
        Me.txtother.Size = New System.Drawing.Size(100, 20)
        Me.txtother.TabIndex = 26
        '
        'txtpf
        '
        Me.txtpf.Location = New System.Drawing.Point(337, 227)
        Me.txtpf.Name = "txtpf"
        Me.txtpf.Size = New System.Drawing.Size(100, 20)
        Me.txtpf.TabIndex = 27
        '
        'txtit
        '
        Me.txtit.Location = New System.Drawing.Point(337, 262)
        Me.txtit.Name = "txtit"
        Me.txtit.Size = New System.Drawing.Size(100, 20)
        Me.txtit.TabIndex = 28
        '
        'txttotal
        '
        Me.txttotal.Location = New System.Drawing.Point(337, 297)
        Me.txttotal.Name = "txttotal"
        Me.txttotal.Size = New System.Drawing.Size(100, 20)
        Me.txttotal.TabIndex = 29
        '
        'txtpt
        '
        Me.txtpt.Location = New System.Drawing.Point(337, 330)
        Me.txtpt.Name = "txtpt"
        Me.txtpt.Size = New System.Drawing.Size(100, 20)
        Me.txtpt.TabIndex = 30
        '
        'txtnet
        '
        Me.txtnet.Location = New System.Drawing.Point(337, 368)
        Me.txtnet.Name = "txtnet"
        Me.txtnet.Size = New System.Drawing.Size(100, 20)
        Me.txtnet.TabIndex = 31
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.salary_negotiation_965853_1_
        Me.PictureBox1.Location = New System.Drawing.Point(532, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(373, 285)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 36
        Me.PictureBox1.TabStop = False
        '
        'txtdesg
        '
        Me.txtdesg.Location = New System.Drawing.Point(95, 179)
        Me.txtdesg.Name = "txtdesg"
        Me.txtdesg.Size = New System.Drawing.Size(100, 20)
        Me.txtdesg.TabIndex = 37
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(452, 315)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(498, 167)
        Me.Grid.TabIndex = 39
        '
        'cmbdept
        '
        Me.cmbdept.FormattingEnabled = True
        Me.cmbdept.Location = New System.Drawing.Point(95, 24)
        Me.cmbdept.Name = "cmbdept"
        Me.cmbdept.Size = New System.Drawing.Size(100, 21)
        Me.cmbdept.TabIndex = 40
        '
        'btcalculate
        '
        Me.btcalculate.Location = New System.Drawing.Point(169, 428)
        Me.btcalculate.Name = "btcalculate"
        Me.btcalculate.Size = New System.Drawing.Size(100, 23)
        Me.btcalculate.TabIndex = 41
        Me.btcalculate.Text = "CALCULATE"
        Me.btcalculate.UseVisualStyleBackColor = True
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Location = New System.Drawing.Point(252, 10)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(37, 13)
        Me.Label17.TabIndex = 42
        Me.Label17.Text = "Month"
        '
        'cmbmonth
        '
        Me.cmbmonth.FormattingEnabled = True
        Me.cmbmonth.Items.AddRange(New Object() {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"})
        Me.cmbmonth.Location = New System.Drawing.Point(316, 7)
        Me.cmbmonth.Name = "cmbmonth"
        Me.cmbmonth.Size = New System.Drawing.Size(121, 21)
        Me.cmbmonth.TabIndex = 43
        '
        'btview
        '
        Me.btview.Location = New System.Drawing.Point(60, 428)
        Me.btview.Name = "btview"
        Me.btview.Size = New System.Drawing.Size(85, 23)
        Me.btview.TabIndex = 44
        Me.btview.Text = "VIEW"
        Me.btview.UseVisualStyleBackColor = True
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(222, 52)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(119, 17)
        Me.Label18.TabIndex = 45
        Me.Label18.Text = "Group Insurence"
        '
        'txtgi
        '
        Me.txtgi.Location = New System.Drawing.Point(347, 52)
        Me.txtgi.Name = "txtgi"
        Me.txtgi.Size = New System.Drawing.Size(100, 20)
        Me.txtgi.TabIndex = 47
        '
        'txtfbf
        '
        Me.txtfbf.Location = New System.Drawing.Point(337, 134)
        Me.txtfbf.Name = "txtfbf"
        Me.txtfbf.Size = New System.Drawing.Size(100, 20)
        Me.txtfbf.TabIndex = 49
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(229, 137)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(95, 13)
        Me.Label19.TabIndex = 50
        Me.Label19.Text = "Family Benifit Fund"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(227, 170)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(31, 13)
        Me.Label8.TabIndex = 51
        Me.Label8.Text = "Loan"
        '
        'txtloan
        '
        Me.txtloan.Location = New System.Drawing.Point(337, 170)
        Me.txtloan.Name = "txtloan"
        Me.txtloan.Size = New System.Drawing.Size(100, 20)
        Me.txtloan.TabIndex = 52
        '
        'Salary
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Chocolate
        Me.ClientSize = New System.Drawing.Size(956, 510)
        Me.Controls.Add(Me.txtloan)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.txtfbf)
        Me.Controls.Add(Me.txtgi)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.btview)
        Me.Controls.Add(Me.cmbmonth)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.btcalculate)
        Me.Controls.Add(Me.cmbdept)
        Me.Controls.Add(Me.Grid)
        Me.Controls.Add(Me.txtdesg)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.txtnet)
        Me.Controls.Add(Me.txtpt)
        Me.Controls.Add(Me.txttotal)
        Me.Controls.Add(Me.txtit)
        Me.Controls.Add(Me.txtpf)
        Me.Controls.Add(Me.txtother)
        Me.Controls.Add(Me.txtlic)
        Me.Controls.Add(Me.txtgross)
        Me.Controls.Add(Me.txthra)
        Me.Controls.Add(Me.txtda)
        Me.Controls.Add(Me.txtbasic)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.txtid)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Salary"
        Me.Text = "Salary"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtid As System.Windows.Forms.TextBox
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtbasic As System.Windows.Forms.TextBox
    Friend WithEvents txtda As System.Windows.Forms.TextBox
    Friend WithEvents txthra As System.Windows.Forms.TextBox
    Friend WithEvents txtgross As System.Windows.Forms.TextBox
    Friend WithEvents txtlic As System.Windows.Forms.TextBox
    Friend WithEvents txtother As System.Windows.Forms.TextBox
    Friend WithEvents txtpf As System.Windows.Forms.TextBox
    Friend WithEvents txtit As System.Windows.Forms.TextBox
    Friend WithEvents txttotal As System.Windows.Forms.TextBox
    Friend WithEvents txtpt As System.Windows.Forms.TextBox
    Friend WithEvents txtnet As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents txtdesg As System.Windows.Forms.TextBox
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents cmbdept As System.Windows.Forms.ComboBox
    Friend WithEvents btcalculate As System.Windows.Forms.Button
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents cmbmonth As System.Windows.Forms.ComboBox
    Friend WithEvents btview As System.Windows.Forms.Button
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents txtgi As System.Windows.Forms.TextBox
    Friend WithEvents txtfbf As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtloan As System.Windows.Forms.TextBox
End Class
