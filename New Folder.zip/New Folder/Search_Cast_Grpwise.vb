﻿Imports System.Data.SqlClient

Public Class Search_Cast_Grpwise




    Private Sub Search_Cast_Grpwise_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_course()
        load_cast()
    End Sub


    Sub load_course()
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)

        Loop
        connection_close()
    End Sub

    Sub load_cast()
        connection_open()
        qry = "select distinct(Cast_grp) from Tbl_std1"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcast.Items.Add(dr(0).ToString)
        Loop
        connection_close()
    End Sub



    Private Sub btnshow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnshow.Click
        connection_open()
        qry = "select Name,Course,Class,Cast_grp from Tbl_std1 where Cast_grp='" & cmbcast.Text & "' and Course='" & cmbcourse.Text & "' and Class='" & cmbclass.Text & "'"
        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_std1")

        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub

    Private Sub cmbcourse_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbcourse.SelectedIndexChanged
        cmbcourse.Text = "----Select-----"
    End Sub

    Private Sub cmbclass_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbclass.SelectedIndexChanged
        cmbclass.Text = "-----Select-----"
    End Sub
End Class