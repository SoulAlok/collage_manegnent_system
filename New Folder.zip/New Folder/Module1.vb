﻿

Imports System.Data.SqlClient
Module general
    'Public con As New SqlConnection("Data Source=NAUSHAD-PC;Initial Catalog=SAM_OFFICEAUTOMATION;Integrated Security=True")
    Public connetionString As String
    Public cnn, con As SqlConnection
    Public qry As String
    Public cmd As SqlCommand
    Public dr As SqlDataReader
    Public dr1 As SqlDataReader
    Public adp As SqlDataAdapter
    Public ds As New DataSet
    Public ds1 As New DataSet
    Public qry1 As String
    Public cmd1 As SqlCommand
    Public dept As String
    Public status As String
    Public utype As String
    Public crs, sem, exam As String
    Public mon, dpt As String


End Module

