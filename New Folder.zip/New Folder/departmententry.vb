﻿Imports System.Data.SqlClient

Public Class departmententry

    Private Sub deptadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deptadd.Click
        connection_open()
        qry = "insert into Tbl_dept(Id,Name) values (" & txtid.Text & ",'" & txtname.Text & "')"
        If txtid.Text = "" Then
            MsgBox("Please Enter the Id", MsgBoxStyle.Information, "Office Automation")

        ElseIf txtname.Text = "" Then
            MsgBox("Please Enter the Name", MsgBoxStyle.Information, "Office Automation")
        Else
            qry1 = "select * from Tbl_dept where Id=" & txtid.Text & ""
            cmd1 = New SqlCommand(qry1, cnn)
            dr = cmd1.ExecuteReader()
            If dr.Read = False Then
                cmd = New SqlCommand(qry, cnn)
                dr.Close()
                cmd.ExecuteNonQuery()
                MsgBox("Successfully Entered into the DataBase", MsgBoxStyle.MsgBoxRight, "Successful")
                'grid fill
                ds.Clear()
                qry = "select * from Tbl_dept"
                adp = New SqlDataAdapter(qry, cnn)
                adp.Fill(ds, "Tbl_dept")
                Grid.DataSource = ds
                Grid.DataMember = ds.Tables(0).ToString
                connection_close()
            End If
            connection_close()
        End If
    End Sub

    Private Sub deptdelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deptdelete.Click
        connection_open()
        qry = "delete from Tbl_dept where ID=" & txtid.Text & ""
        cmd = New SqlCommand(qry, cnn)
        Dim g = MsgBox("Are you Sure you want to delete the record?", MsgBoxStyle.YesNoCancel, "Fill")
        If g = MsgBoxResult.Yes Then
            cmd.ExecuteNonQuery()
            MsgBox("Successfully Deleted the Record of  " & txtid.Text & " ", MsgBoxStyle.MsgBoxRight, "Deleted")
        Else

            MsgBox("Operation Aborted", MsgBoxStyle.AbortRetryIgnore, "Fill")


        End If
        ds.Clear()
        qry = "select * from Tbl_dept"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_dept")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub

    Private Sub deptrst_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deptrst.Click
        txtid.Text = ""
        txtname.Text = ""
        deptid()
    End Sub
    Private Sub txtname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtid.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Sub deptid()
        connection_open()
        qry = "Select * from Tbl_dept"
        Try
            cmd = New SqlCommand(qry, cnn)
            dr = cmd.ExecuteReader()
            While dr.Read()
                txtid.Text = dr.Item(0) + 1
            End While
            dr.Close()
            cmd.Dispose()
        Catch ex As Exception
            MsgBox("Invalid Userid! ")
        End Try
        connection_close()
    End Sub

    Private Sub departmententry_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        deptid()
        view()
        'connection_open()
        'qry = "select * from Tbl_dept"
        'adp = New SqlDataAdapter(qry, cnn)
        'adp.Fill(ds, "Tbl_dept")
        'Grid.DataSource = ds
        'Grid.DataMember = ds.Tables(0).ToString
        'connection_close()
    End Sub


    Private Sub deptupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles deptupdate.Click
        connection_open()

        qry1 = "update Tbl_dept set Name='" & txtname.Text & "'where Id='" & txtid.Text & "' "
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()
        view()
        connection_close()
    End Sub

    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        Dim a
        a = Grid.CurrentRow.Index
        txtid.Text = Grid.Item(0, a).Value
        txtname.Text = Grid.Item(1, a).Value
    End Sub

    Sub view()
        connection_close()
        connection_open()

        cmd = New SqlCommand("select * from Tbl_dept", cnn)
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        Grid.Rows.Clear()
        Do While dr.Read = True
            Grid.Rows.Add(dr(0), dr(1))
        Loop
        connection_close()
    End Sub

    
End Class