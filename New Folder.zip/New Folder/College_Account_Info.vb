﻿Imports System.Data.SqlClient

Public Class College_Account_Info


    Private Sub butcredit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butcredit.Click
        connection_open()
        qry = "select * from Tbl_CreditAmt"
        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_CreditAmt")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()

    End Sub

    Private Sub butdebit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butdebit.Click
        connection_open()
        qry = "select * from Tbl_DebitAmt"
        adp = New SqlDataAdapter(qry, cnn)
        ds1.Clear()
        adp.Fill(ds1, "Tbl_DebitAmt")
        Grid.DataSource = ds1
        Grid.DataMember = ds1.Tables(0).ToString
        connection_close()
    End Sub

    Private Sub butamt_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butamt.Click
        connection_open()
        'qry = "select Credit_Amt - (Debit_Amt) from Tbl_CreditAmt,Tbl_DebitAmt"
        'cmd = New SqlCommand(qry,cnn)
        'dr = cmd.ExecuteReader
        'If dr.Read = True Then

        '    txtamt.Text = dr(0).ToString
        '    dr.Close()
        'Else

        '    MsgBox("Amount is 0", MsgBoxStyle.Information, "Office Automation")
        '    dr.Close()
        'End If




        qry = "select sum(Credit_Amt) from Tbl_CreditAmt"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Dim c = 0
        If dr.Read = True Then
            c = dr(0).ToString
            dr.Close()
        End If


        qry1 = "select sum(Debit_Amt) from Tbl_DebitAmt"
        cmd = New SqlCommand(qry1, cnn)
        dr1 = cmd.ExecuteReader
        Dim d = 0
        If dr1.Read = True Then
            d = dr1(0).ToString
            dr1.Close()
        End If

        Dim s = 0
        s = Val(c) - Val(d)
        txtamt.Text = Val(s)

        connection_close()






    End Sub

    Private Sub College_Account_Info_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class