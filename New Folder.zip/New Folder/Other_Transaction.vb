﻿Imports System.Data.SqlClient

Public Class Other_Transaction


    Private Sub butok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles butok.Click
        connection_open()

        If rdcredit.Checked = True Then
            qry = "insert into Tbl_CreditAmt(Date,Credit_Amt,Description) values ('" & dt.Value & "'," & txtamt.Text & ",'" & txtdes.Text & "')"
        ElseIf rddebit.Checked = True Then
            qry = "insert into Tbl_DebitAmt(Date,Debit_Amt,Description) values ('" & dt.Value & "'," & txtamt.Text & ",'" & txtdes.Text & "')"
        End If
        cmd = New SqlCommand(qry, cnn)
        cmd.ExecuteNonQuery()
        MsgBox(" Record Inserted", MsgBoxStyle.Information, "OFFICE AUTOATION")

        connection_close()
    End Sub
End Class