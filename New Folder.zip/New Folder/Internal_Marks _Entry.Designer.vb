﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Internal_Marks__Entry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.txtname = New System.Windows.Forms.TextBox
        Me.Lbnmae = New System.Windows.Forms.Label
        Me.butOK = New System.Windows.Forms.Button
        Me.cmbscode = New System.Windows.Forms.ComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.cmbexam = New System.Windows.Forms.ComboBox
        Me.cmbsem = New System.Windows.Forms.ComboBox
        Me.cmbcourse = New System.Windows.Forms.ComboBox
        Me.txtregno = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtmax = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.txtobt = New System.Windows.Forms.TextBox
        Me.txtmin = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.resclear = New System.Windows.Forms.Button
        Me.butsave = New System.Windows.Forms.Button
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.btnupdate = New System.Windows.Forms.Button
        Me.btnview = New System.Windows.Forms.Button
        Me.Gridview = New System.Windows.Forms.DataGridView
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Gridview, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.txtname)
        Me.GroupBox1.Controls.Add(Me.Lbnmae)
        Me.GroupBox1.Controls.Add(Me.butOK)
        Me.GroupBox1.Controls.Add(Me.cmbscode)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.cmbexam)
        Me.GroupBox1.Controls.Add(Me.cmbsem)
        Me.GroupBox1.Controls.Add(Me.cmbcourse)
        Me.GroupBox1.Controls.Add(Me.txtregno)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(310, 309)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Course and Semester Details"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(118, 283)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(150, 20)
        Me.txtname.TabIndex = 17
        '
        'Lbnmae
        '
        Me.Lbnmae.AutoSize = True
        Me.Lbnmae.Location = New System.Drawing.Point(24, 276)
        Me.Lbnmae.Name = "Lbnmae"
        Me.Lbnmae.Size = New System.Drawing.Size(35, 13)
        Me.Lbnmae.TabIndex = 16
        Me.Lbnmae.Text = "Name"
        '
        'butOK
        '
        Me.butOK.Location = New System.Drawing.Point(229, 212)
        Me.butOK.Name = "butOK"
        Me.butOK.Size = New System.Drawing.Size(75, 23)
        Me.butOK.TabIndex = 15
        Me.butOK.Text = "OK"
        Me.butOK.UseVisualStyleBackColor = True
        '
        'cmbscode
        '
        Me.cmbscode.FormattingEnabled = True
        Me.cmbscode.Location = New System.Drawing.Point(118, 173)
        Me.cmbscode.Name = "cmbscode"
        Me.cmbscode.Size = New System.Drawing.Size(150, 21)
        Me.cmbscode.TabIndex = 14
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 173)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(71, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Subject Code"
        '
        'cmbexam
        '
        Me.cmbexam.FormattingEnabled = True
        Me.cmbexam.Items.AddRange(New Object() {"1st Internal", "2nd Internal"})
        Me.cmbexam.Location = New System.Drawing.Point(118, 126)
        Me.cmbexam.Name = "cmbexam"
        Me.cmbexam.Size = New System.Drawing.Size(150, 21)
        Me.cmbexam.TabIndex = 12
        '
        'cmbsem
        '
        Me.cmbsem.FormattingEnabled = True
        Me.cmbsem.Items.AddRange(New Object() {"ISem", "IISem", "IIISem", "IVSem", "VSem", "VISem"})
        Me.cmbsem.Location = New System.Drawing.Point(118, 82)
        Me.cmbsem.Name = "cmbsem"
        Me.cmbsem.Size = New System.Drawing.Size(150, 21)
        Me.cmbsem.TabIndex = 3
        '
        'cmbcourse
        '
        Me.cmbcourse.FormattingEnabled = True
        Me.cmbcourse.Location = New System.Drawing.Point(118, 22)
        Me.cmbcourse.Name = "cmbcourse"
        Me.cmbcourse.Size = New System.Drawing.Size(150, 21)
        Me.cmbcourse.TabIndex = 2
        '
        'txtregno
        '
        Me.txtregno.Location = New System.Drawing.Point(118, 241)
        Me.txtregno.Name = "txtregno"
        Me.txtregno.Size = New System.Drawing.Size(150, 20)
        Me.txtregno.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 85)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Semester"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Course"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 126)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(33, 13)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Exam"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(24, 241)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(39, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Regno"
        '
        'txtmax
        '
        Me.txtmax.Location = New System.Drawing.Point(159, 68)
        Me.txtmax.Name = "txtmax"
        Me.txtmax.Size = New System.Drawing.Size(100, 20)
        Me.txtmax.TabIndex = 4
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.txtobt)
        Me.GroupBox2.Controls.Add(Me.txtmax)
        Me.GroupBox2.Controls.Add(Me.txtmin)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 327)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(310, 144)
        Me.GroupBox2.TabIndex = 18
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Marks Entry"
        '
        'txtobt
        '
        Me.txtobt.Location = New System.Drawing.Point(159, 107)
        Me.txtobt.Name = "txtobt"
        Me.txtobt.Size = New System.Drawing.Size(96, 20)
        Me.txtobt.TabIndex = 5
        '
        'txtmin
        '
        Me.txtmin.Location = New System.Drawing.Point(159, 33)
        Me.txtmin.Name = "txtmin"
        Me.txtmin.Size = New System.Drawing.Size(100, 20)
        Me.txtmin.TabIndex = 3
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(64, 110)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(82, 13)
        Me.Label8.TabIndex = 2
        Me.Label8.Text = "Obtained Marks"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(65, 74)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(59, 13)
        Me.Label7.TabIndex = 1
        Me.Label7.Text = "Max Marks"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(65, 33)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 13)
        Me.Label6.TabIndex = 0
        Me.Label6.Text = "Min Marks"
        '
        'resclear
        '
        Me.resclear.BackColor = System.Drawing.Color.White
        Me.resclear.ForeColor = System.Drawing.Color.Blue
        Me.resclear.Location = New System.Drawing.Point(352, 477)
        Me.resclear.Name = "resclear"
        Me.resclear.Size = New System.Drawing.Size(87, 27)
        Me.resclear.TabIndex = 16
        Me.resclear.Text = "CLEAR"
        Me.resclear.UseVisualStyleBackColor = False
        '
        'butsave
        '
        Me.butsave.BackColor = System.Drawing.Color.White
        Me.butsave.ForeColor = System.Drawing.Color.Blue
        Me.butsave.Location = New System.Drawing.Point(24, 477)
        Me.butsave.Name = "butsave"
        Me.butsave.Size = New System.Drawing.Size(87, 27)
        Me.butsave.TabIndex = 15
        Me.butsave.Text = "SAVE"
        Me.butsave.UseVisualStyleBackColor = False
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(374, 46)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(324, 160)
        Me.Grid.TabIndex = 20
        Me.Grid.Visible = False
        '
        'btnupdate
        '
        Me.btnupdate.Location = New System.Drawing.Point(130, 481)
        Me.btnupdate.Name = "btnupdate"
        Me.btnupdate.Size = New System.Drawing.Size(75, 23)
        Me.btnupdate.TabIndex = 21
        Me.btnupdate.Text = "UPDATE"
        Me.btnupdate.UseVisualStyleBackColor = True
        '
        'btnview
        '
        Me.btnview.Location = New System.Drawing.Point(222, 481)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 23)
        Me.btnview.TabIndex = 22
        Me.btnview.Text = "VIEW"
        Me.btnview.UseVisualStyleBackColor = True
        '
        'Gridview
        '
        Me.Gridview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Gridview.Location = New System.Drawing.Point(374, 265)
        Me.Gridview.Name = "Gridview"
        Me.Gridview.Size = New System.Drawing.Size(324, 150)
        Me.Gridview.TabIndex = 23
        Me.Gridview.Visible = False
        '
        'Panel1
        '
        Me.Panel1.Location = New System.Drawing.Point(362, 28)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(347, 190)
        Me.Panel1.TabIndex = 24
        '
        'Panel2
        '
        Me.Panel2.Location = New System.Drawing.Point(362, 244)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(347, 185)
        Me.Panel2.TabIndex = 0
        '
        'Internal_Marks__Entry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Chocolate
        Me.ClientSize = New System.Drawing.Size(795, 525)
        Me.Controls.Add(Me.Gridview)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.btnupdate)
        Me.Controls.Add(Me.Grid)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.resclear)
        Me.Controls.Add(Me.butsave)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Panel2)
        Me.Name = "Internal_Marks__Entry"
        Me.Text = "Internal_Marks__Entry"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Gridview, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbscode As System.Windows.Forms.ComboBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents cmbexam As System.Windows.Forms.ComboBox
    Friend WithEvents cmbsem As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcourse As System.Windows.Forms.ComboBox
    Friend WithEvents txtregno As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtmax As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtobt As System.Windows.Forms.TextBox
    Friend WithEvents txtmin As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents resclear As System.Windows.Forms.Button
    Friend WithEvents butsave As System.Windows.Forms.Button
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents butOK As System.Windows.Forms.Button
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents Lbnmae As System.Windows.Forms.Label
    Friend WithEvents btnupdate As System.Windows.Forms.Button
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents Gridview As System.Windows.Forms.DataGridView
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
