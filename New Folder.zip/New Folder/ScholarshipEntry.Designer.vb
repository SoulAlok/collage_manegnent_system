﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ScholarshipEntry
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtname = New System.Windows.Forms.TextBox
        Me.txtamt = New System.Windows.Forms.TextBox
        Me.sclradd = New System.Windows.Forms.Button
        Me.sclrdelete = New System.Windows.Forms.Button
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.sclrreset = New System.Windows.Forms.Button
        Me.sclrupdate = New System.Windows.Forms.Button
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(70, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Scholarship"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(12, 70)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(49, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Amount"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(107, 9)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(139, 21)
        Me.txtname.TabIndex = 4
        '
        'txtamt
        '
        Me.txtamt.Location = New System.Drawing.Point(107, 70)
        Me.txtamt.Name = "txtamt"
        Me.txtamt.Size = New System.Drawing.Size(139, 21)
        Me.txtamt.TabIndex = 5
        '
        'sclradd
        '
        Me.sclradd.BackColor = System.Drawing.Color.White
        Me.sclradd.ForeColor = System.Drawing.Color.Blue
        Me.sclradd.Location = New System.Drawing.Point(362, 243)
        Me.sclradd.Name = "sclradd"
        Me.sclradd.Size = New System.Drawing.Size(87, 27)
        Me.sclradd.TabIndex = 9
        Me.sclradd.Text = "ADD"
        Me.sclradd.UseVisualStyleBackColor = False
        '
        'sclrdelete
        '
        Me.sclrdelete.BackColor = System.Drawing.Color.White
        Me.sclrdelete.ForeColor = System.Drawing.Color.Blue
        Me.sclrdelete.Location = New System.Drawing.Point(472, 243)
        Me.sclrdelete.Name = "sclrdelete"
        Me.sclrdelete.Size = New System.Drawing.Size(87, 27)
        Me.sclrdelete.TabIndex = 11
        Me.sclrdelete.Text = "DELETE"
        Me.sclrdelete.UseVisualStyleBackColor = False
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.White
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[False]
        Me.Grid.DefaultCellStyle = DataGridViewCellStyle1
        Me.Grid.Location = New System.Drawing.Point(3, 136)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(266, 182)
        Me.Grid.TabIndex = 12
        '
        'sclrreset
        '
        Me.sclrreset.BackColor = System.Drawing.Color.White
        Me.sclrreset.ForeColor = System.Drawing.Color.Blue
        Me.sclrreset.Location = New System.Drawing.Point(472, 287)
        Me.sclrreset.Name = "sclrreset"
        Me.sclrreset.Size = New System.Drawing.Size(87, 27)
        Me.sclrreset.TabIndex = 13
        Me.sclrreset.Text = "RESET"
        Me.sclrreset.UseVisualStyleBackColor = False
        '
        'sclrupdate
        '
        Me.sclrupdate.BackColor = System.Drawing.Color.White
        Me.sclrupdate.ForeColor = System.Drawing.Color.Blue
        Me.sclrupdate.Location = New System.Drawing.Point(362, 287)
        Me.sclrupdate.Name = "sclrupdate"
        Me.sclrupdate.Size = New System.Drawing.Size(87, 27)
        Me.sclrupdate.TabIndex = 15
        Me.sclrupdate.Text = "UPDATE"
        Me.sclrupdate.UseVisualStyleBackColor = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.LinkColor = System.Drawing.Color.White
        Me.LinkLabel1.Location = New System.Drawing.Point(508, 333)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(41, 15)
        Me.LinkLabel1.TabIndex = 18
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "BACK"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.Students_Scholarships_1_
        Me.PictureBox1.Location = New System.Drawing.Point(366, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(193, 227)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 14
        Me.PictureBox1.TabStop = False
        '
        'ScholarshipEntry
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(593, 357)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.sclrupdate)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.sclrreset)
        Me.Controls.Add(Me.Grid)
        Me.Controls.Add(Me.sclrdelete)
        Me.Controls.Add(Me.sclradd)
        Me.Controls.Add(Me.txtamt)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.White
        Me.Name = "ScholarshipEntry"
        Me.Text = "ScholarshipEntry"
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents txtamt As System.Windows.Forms.TextBox
    Friend WithEvents sclradd As System.Windows.Forms.Button
    Friend WithEvents sclrdelete As System.Windows.Forms.Button
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents sclrreset As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents sclrupdate As System.Windows.Forms.Button
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
End Class
