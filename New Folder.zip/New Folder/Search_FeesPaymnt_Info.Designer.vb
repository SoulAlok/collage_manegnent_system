﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Search_FeesPaymnt_Info
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.btnshow = New System.Windows.Forms.Button
        Me.cmbcourse = New System.Windows.Forms.ComboBox
        Me.cmbclass = New System.Windows.Forms.ComboBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.rdpaid = New System.Windows.Forms.RadioButton
        Me.rdunpaid = New System.Windows.Forms.RadioButton
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(317, 138)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(371, 150)
        Me.Grid.TabIndex = 0
        '
        'btnshow
        '
        Me.btnshow.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnshow.Location = New System.Drawing.Point(33, 297)
        Me.btnshow.Name = "btnshow"
        Me.btnshow.Size = New System.Drawing.Size(75, 42)
        Me.btnshow.TabIndex = 1
        Me.btnshow.Text = "SHOW"
        Me.btnshow.UseVisualStyleBackColor = True
        '
        'cmbcourse
        '
        Me.cmbcourse.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbcourse.FormattingEnabled = True
        Me.cmbcourse.Location = New System.Drawing.Point(183, 12)
        Me.cmbcourse.Name = "cmbcourse"
        Me.cmbcourse.Size = New System.Drawing.Size(121, 25)
        Me.cmbcourse.TabIndex = 2
        '
        'cmbclass
        '
        Me.cmbclass.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbclass.FormattingEnabled = True
        Me.cmbclass.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbclass.Location = New System.Drawing.Point(468, 12)
        Me.cmbclass.Name = "cmbclass"
        Me.cmbclass.Size = New System.Drawing.Size(121, 25)
        Me.cmbclass.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(30, 20)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 17)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "Select The Course"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(347, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 17)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Select The Class"
        '
        'rdpaid
        '
        Me.rdpaid.AutoSize = True
        Me.rdpaid.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdpaid.Location = New System.Drawing.Point(18, 84)
        Me.rdpaid.Name = "rdpaid"
        Me.rdpaid.Size = New System.Drawing.Size(54, 21)
        Me.rdpaid.TabIndex = 6
        Me.rdpaid.TabStop = True
        Me.rdpaid.Text = "Paid"
        Me.rdpaid.UseVisualStyleBackColor = True
        '
        'rdunpaid
        '
        Me.rdunpaid.AutoSize = True
        Me.rdunpaid.Font = New System.Drawing.Font("Times New Roman", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rdunpaid.Location = New System.Drawing.Point(203, 84)
        Me.rdunpaid.Name = "rdunpaid"
        Me.rdunpaid.Size = New System.Drawing.Size(72, 21)
        Me.rdunpaid.TabIndex = 7
        Me.rdunpaid.TabStop = True
        Me.rdunpaid.Text = "Unpaid"
        Me.rdunpaid.UseVisualStyleBackColor = True
        '
        'Search_FeesPaymnt_Info
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(700, 351)
        Me.Controls.Add(Me.rdunpaid)
        Me.Controls.Add(Me.rdpaid)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbclass)
        Me.Controls.Add(Me.cmbcourse)
        Me.Controls.Add(Me.btnshow)
        Me.Controls.Add(Me.Grid)
        Me.Name = "Search_FeesPaymnt_Info"
        Me.Text = "Search_FeesPaymnt_Info"
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents btnshow As System.Windows.Forms.Button
    Friend WithEvents cmbcourse As System.Windows.Forms.ComboBox
    Friend WithEvents cmbclass As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents rdpaid As System.Windows.Forms.RadioButton
    Friend WithEvents rdunpaid As System.Windows.Forms.RadioButton
End Class
