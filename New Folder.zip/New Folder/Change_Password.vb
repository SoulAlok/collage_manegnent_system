﻿Imports System.Data.SqlClient

Public Class Change_Password



    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        If txtolduname.Text = "" Or txtnewuname.Text = "" Or txtcnewuname.Text = "" Then
            MsgBox("please enter all the details", MsgBoxStyle.Question, "ENTER DETAILS")
        ElseIf txtnewuname.Text <> txtcnewuname.Text Then
            MsgBox("The New Username Is Not Confirmed Correctly", MsgBoxStyle.Question, "NOT CONFIRMED")
        Else
            connection_open()
            qry = "select * from tbl_login where uname='" & txtolduname.Text & "'"
            cmd = New SqlCommand(qry, cnn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                connection_close()

                connection_open()
                qry = "update tbl_login set uname='" & txtnewuname.Text & "' where uname='" & txtolduname.Text & "'"
                cmd = New SqlCommand(qry, cnn)
                cmd.ExecuteNonQuery()
                MsgBox("Admin Username is Changed", MsgBoxStyle.Information, "CHANGE USERNAME")
                connection_close()

            Else
                connection_close()
                MsgBox("The old Username Is Wrong", MsgBoxStyle.Question, "WRONG USERNAME")
            End If
        End If
    End Sub

    Private Sub btnbck_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnbck.Click
        Me.Close()
    End Sub


    Private Sub btnaddps_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnaddps.Click

        If txtoldupass.Text = "" Or txtnewupass.Text = "" Or txtcnewupass.Text = "" Then
            MsgBox("please enter all the details", MsgBoxStyle.Question, "ENTER DETAILS")
        ElseIf txtnewupass.Text <> txtcnewupass.Text Then
            MsgBox("The New Password Is Not Confirmed Correctly", MsgBoxStyle.Question, "NOT CONFIRMED")
        Else
            connection_open()
            qry = "select * from tbl_login where upass='" & txtoldupass.Text & "'"
            cmd = New SqlCommand(qry, cnn)
            dr = cmd.ExecuteReader
            If dr.Read = True Then
                connection_close()

                connection_open()
                qry = "update tbl_login set upass='" & txtnewupass.Text & "' where upass='" & txtoldupass.Text & "'"
                cmd = New SqlCommand(qry, cnn)
                cmd.ExecuteNonQuery()
                MsgBox("Admin Password Is Changed", MsgBoxStyle.Information, "CHANGE PASSWORD")
                connection_close()
                ' Catch ex As Exception
                ' MsgBox("THE OLD USERNAME IS WRONG", MsgBoxStyle.Question, "ENTER DETAILS")
                'End Try
            Else
                connection_close()
                MsgBox("The old Password Is Wrong", MsgBoxStyle.Question, "WRONG PASSWORD")
            End If
        End If
    End Sub

    Private Sub btnbkps_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnbkps.Click
        Me.Close()
    End Sub

    Private Sub btnclrps_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclrps.Click
        txtoldupass.Text = ""
        txtnewupass.Text = ""
        txtcnewupass.Text = ""
    End Sub

    Private Sub btnclr_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnclr.Click
        txtolduname.Text = ""
        txtnewuname.Text = ""
        txtcnewuname.Text = ""
    End Sub

    Private Sub txtolduname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtolduname.KeyPress
        If Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtolduname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtcnewuname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtcnewuname.KeyPress
        If Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtcnewuname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtnewuname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnewuname.KeyPress
        If Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtnewuname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub Change_Password_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class