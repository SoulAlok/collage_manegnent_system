﻿Imports System.Data.SqlClient

Public Class Employee_report

    Private Sub Employee_report_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'connection_close()
        'connection_open()
        'qry = "select * from Tbl_Salary where Month= '" & mon & "' and dept='" & dpt & "' "
        'adp = New SqlDataAdapter(qry, cnn)
        'ds = New DataSet

        'adp.Fill(ds, "Tbl_Salary")

        'Dim mt As New e
        'mt.SetDataSource(ds)

        'CrystalReportViewer1.ReportSource = mt
        'mt.Refresh()
        'CrystalReportViewer1.Show()
        'connection_close()
    End Sub
End Class