﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class RegNum
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.grpadd = New System.Windows.Forms.GroupBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtadno = New System.Windows.Forms.TextBox
        Me.btnview = New System.Windows.Forms.Button
        Me.txtname = New System.Windows.Forms.MaskedTextBox
        Me.txtnum = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.btnreset = New System.Windows.Forms.Button
        Me.btnadd = New System.Windows.Forms.Button
        Me.grpcourse = New System.Windows.Forms.GroupBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.cmbclass = New System.Windows.Forms.ComboBox
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmbcourse = New System.Windows.Forms.ComboBox
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.GridView = New System.Windows.Forms.DataGridView
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.grpadd.SuspendLayout()
        Me.grpcourse.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.GridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TabControl1.ItemSize = New System.Drawing.Size(91, 28)
        Me.TabControl1.Location = New System.Drawing.Point(-2, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(796, 555)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.BackColor = System.Drawing.Color.LightGreen
        Me.TabPage1.Controls.Add(Me.Panel1)
        Me.TabPage1.Controls.Add(Me.grpadd)
        Me.TabPage1.Controls.Add(Me.grpcourse)
        Me.TabPage1.Controls.Add(Me.Panel2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 32)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(788, 519)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Register Number"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Grid)
        Me.Panel1.Location = New System.Drawing.Point(269, 15)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(200, 318)
        Me.Panel1.TabIndex = 3
        Me.Panel1.Visible = False
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(17, 18)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(163, 297)
        Me.Grid.TabIndex = 0
        Me.Grid.Visible = False
        '
        'grpadd
        '
        Me.grpadd.BackColor = System.Drawing.Color.PaleTurquoise
        Me.grpadd.Controls.Add(Me.Label6)
        Me.grpadd.Controls.Add(Me.Label5)
        Me.grpadd.Controls.Add(Me.Label4)
        Me.grpadd.Controls.Add(Me.txtadno)
        Me.grpadd.Controls.Add(Me.btnview)
        Me.grpadd.Controls.Add(Me.txtname)
        Me.grpadd.Controls.Add(Me.txtnum)
        Me.grpadd.Controls.Add(Me.Label2)
        Me.grpadd.Controls.Add(Me.btnreset)
        Me.grpadd.Controls.Add(Me.btnadd)
        Me.grpadd.Location = New System.Drawing.Point(20, 356)
        Me.grpadd.Name = "grpadd"
        Me.grpadd.Size = New System.Drawing.Size(702, 143)
        Me.grpadd.TabIndex = 2
        Me.grpadd.TabStop = False
        Me.grpadd.Text = "Register No"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(285, 60)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(52, 17)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "RegNo"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(42, 109)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(45, 17)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Name"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(36, 60)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(94, 17)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Admission No"
        '
        'txtadno
        '
        Me.txtadno.Location = New System.Drawing.Point(139, 60)
        Me.txtadno.Name = "txtadno"
        Me.txtadno.Size = New System.Drawing.Size(100, 23)
        Me.txtadno.TabIndex = 5
        '
        'btnview
        '
        Me.btnview.Location = New System.Drawing.Point(529, 110)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 26)
        Me.btnview.TabIndex = 4
        Me.btnview.Text = "View"
        Me.btnview.UseVisualStyleBackColor = True
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(139, 109)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 23)
        Me.txtname.TabIndex = 3
        '
        'txtnum
        '
        Me.txtnum.Location = New System.Drawing.Point(378, 57)
        Me.txtnum.Name = "txtnum"
        Me.txtnum.Size = New System.Drawing.Size(100, 23)
        Me.txtnum.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(136, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(377, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Enter the Register No. of the Student in th Space Provided"
        '
        'btnreset
        '
        Me.btnreset.Location = New System.Drawing.Point(610, 109)
        Me.btnreset.Name = "btnreset"
        Me.btnreset.Size = New System.Drawing.Size(75, 28)
        Me.btnreset.TabIndex = 1
        Me.btnreset.Text = "Reset"
        Me.btnreset.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.Location = New System.Drawing.Point(438, 110)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 28)
        Me.btnadd.TabIndex = 0
        Me.btnadd.Text = "Add"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'grpcourse
        '
        Me.grpcourse.BackColor = System.Drawing.Color.PaleTurquoise
        Me.grpcourse.Controls.Add(Me.Label3)
        Me.grpcourse.Controls.Add(Me.cmbclass)
        Me.grpcourse.Controls.Add(Me.Button1)
        Me.grpcourse.Controls.Add(Me.Label1)
        Me.grpcourse.Controls.Add(Me.cmbcourse)
        Me.grpcourse.Location = New System.Drawing.Point(20, 15)
        Me.grpcourse.Name = "grpcourse"
        Me.grpcourse.Size = New System.Drawing.Size(210, 318)
        Me.grpcourse.TabIndex = 0
        Me.grpcourse.TabStop = False
        Me.grpcourse.Text = "Course"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(27, 105)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 17)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Class"
        '
        'cmbclass
        '
        Me.cmbclass.FormattingEnabled = True
        Me.cmbclass.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbclass.Location = New System.Drawing.Point(98, 102)
        Me.cmbclass.Name = "cmbclass"
        Me.cmbclass.Size = New System.Drawing.Size(83, 24)
        Me.cmbclass.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(76, 267)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "OK"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 29)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(60, 17)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Courses"
        '
        'cmbcourse
        '
        Me.cmbcourse.AllowDrop = True
        Me.cmbcourse.FormattingEnabled = True
        Me.cmbcourse.ItemHeight = 16
        Me.cmbcourse.Location = New System.Drawing.Point(98, 22)
        Me.cmbcourse.Name = "cmbcourse"
        Me.cmbcourse.Size = New System.Drawing.Size(83, 24)
        Me.cmbcourse.TabIndex = 0
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.GridView)
        Me.Panel2.Location = New System.Drawing.Point(505, 15)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(277, 315)
        Me.Panel2.TabIndex = 0
        Me.Panel2.Visible = False
        '
        'GridView
        '
        Me.GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridView.Location = New System.Drawing.Point(16, 22)
        Me.GridView.Name = "GridView"
        Me.GridView.Size = New System.Drawing.Size(247, 290)
        Me.GridView.TabIndex = 1
        Me.GridView.Visible = False
        '
        'RegNum
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Khaki
        Me.ClientSize = New System.Drawing.Size(806, 556)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "RegNum"
        Me.Text = "RegNum"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.Panel1.ResumeLayout(False)
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.grpadd.ResumeLayout(False)
        Me.grpadd.PerformLayout()
        Me.grpcourse.ResumeLayout(False)
        Me.grpcourse.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        CType(Me.GridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents grpadd As System.Windows.Forms.GroupBox
    Friend WithEvents btnreset As System.Windows.Forms.Button
    Friend WithEvents btnadd As System.Windows.Forms.Button
    Friend WithEvents grpcourse As System.Windows.Forms.GroupBox
    Friend WithEvents cmbcourse As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtname As System.Windows.Forms.MaskedTextBox
    Friend WithEvents txtnum As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents cmbclass As System.Windows.Forms.ComboBox
    Friend WithEvents GridView As System.Windows.Forms.DataGridView
    Friend WithEvents txtadno As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
End Class
