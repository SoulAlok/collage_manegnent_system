﻿Imports System.Data.SqlClient
Public Class RegNum

    Private Sub RegNum_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)

        Loop
        connection_close()


    End Sub



    Private Sub OK_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Panel2.Visible = False
        GridView.Visible = False
        view1()

    End Sub

    Private Sub RegGrid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        connection_open()
        Dim a
        a = Grid.CurrentRow.Index
        txtadno.Text = Grid.Item(0, a).Value.ToString
        txtname.Text = Grid.Item(1, a).Value.ToString
        connection_close()
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click
        Dim i As Integer
        connection_open()
        Dim qry2 As String
        qry2 = "select donation,tuition,special,total from Tbl_Fees where course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
        cmd = New SqlCommand(qry2, cnn)
        Dim dr1 As SqlDataReader
        dr1 = cmd.ExecuteReader
        Dim don = 0, tun = 0, spl = 0, tot = 0
        If dr1.Read = True Then
            don = dr1(0).ToString
            tun = dr1(1).ToString
            spl = dr1(2).ToString
            tot = dr1(3).ToString
        End If
        dr1.Close()
        qry = "select * from Tbl_Regno where Adno=" & txtadno.Text & ""
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader

        If dr.Read = False Then
            dr.Close()

            qry1 = "insert into Tbl_Regno (Adno,regno,name,course,class) values (" & txtadno.Text & "," & txtnum.Text & ", '" & txtname.Text & "', '" & cmbcourse.Text & "'," & cmbclass.Text & ")"
            cmd1 = New SqlCommand(qry1, cnn)
            cmd1.ExecuteNonQuery()
            MsgBox(" Record insereted Successfully", MsgBoxStyle.MsgBoxRight, "Office Automation")

            Dim qry3 As String
            qry3 = "Insert into Tbl_Feespayment(course,year,regno,name,donation,tuition,fees_amt,con_amt,tot_fee,paid,balance,pay_type) values('" & _
            cmbcourse.Text & "'," & cmbclass.Text & "," & txtnum.Text & ",'" & txtname.Text & "'," & don & "," & tun & "," & spl & ",0," & tot & ",0, " & tot & ",'Unpaid')"

            ' qry3 = "Insert into Tbl_Feespayment(course,year,regno,name,tot_fee,balance) values('" & _
            'cmbcourse.Text & "'," & cmbclass.Text & "," & txtnum.Text & ",'" & txtname.Text & "'," & tot & "," & tot & ")"

            cmd1 = New SqlCommand(qry3, cnn)
            i = cmd1.ExecuteNonQuery()
            If i = 1 Then
                MessageBox.Show("Executed")
            Else
                MessageBox.Show("error")
            End If
            ds1.Clear()

            qry = "select * from Tbl_Regno where course='" & cmbcourse.Text & "' and class=" & cmbclass.Text & ""
            adp = New SqlDataAdapter(qry, cnn)
            adp.Fill(ds1, "Tbl_Regno")
            GridView.DataSource = ds1
            GridView.DataMember = ds1.Tables(0).ToString
            cmbcourse.Focus()

            connection_close()
        Else
            MsgBox("Record already exists", MsgBoxStyle.Information, "Office Automation")
            cmbcourse.Focus()
            connection_close()
        End If
        connection_close()
    End Sub

    Private Sub btnreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        ds.Clear()
        Grid.Refresh()

        cmbcourse.Text = ""
        txtname.Text = ""
        txtnum.Text = ""
        cmbclass.Text = ""

    End Sub


    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        Panel1.Visible = False
        Grid.Visible = False
        view2()


    End Sub
    Private Sub GridView_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles GridView.DoubleClick
        connection_open()
        Dim a
        a = GridView.CurrentRow.Index
        txtnum.Text = GridView.Item(0, a).Value.ToString
        txtname.Text = GridView.Item(1, a).Value.ToString
        connection_close()
    End Sub

    Private Sub txtnum_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtnum.KeyPress
        If Char.IsLetter(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtnum.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub
    Sub view1()
        ds.Clear()
        Panel1.Visible = True
        Grid.Visible = True
        connection_close()
        
        connection_open()
        qry = "select Adno,Name from Tbl_std1 where Course='" & cmbcourse.Text & "' and Class=" & cmbclass.Text & " and Status='false'"

        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_std1")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()



    End Sub
    Sub view2()
        ds1.Clear()
        Panel2.Visible = True
        GridView.Visible = True
        connection_open()
        qry = "select * from Tbl_Regno where course='" & cmbcourse.Text & "'and class=" & cmbclass.Text & ""
        adp = New SqlDataAdapter(qry, cnn)
        ds1.Clear()
        adp.Fill(ds1, "Tbl_Regno")

        GridView.DataSource = ds1
        GridView.DataMember = ds1.Tables(0).ToString
        connection_close()


    End Sub

    Private Sub TabPage1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabPage1.Click

    End Sub
End Class