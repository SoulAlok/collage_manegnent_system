﻿Imports System.Data.SqlClient

Public Class Employee_hidden_records

    Private Sub btrestore_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btrestore.Click
        connection_open()
        qry = "update Tbl_Employee set status='false' where Id='" & txtid.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        ' Do While 
        cmd.ExecuteNonQuery()
        MsgBox("The Selected Record has been restored", MsgBoxStyle.MsgBoxRight, "Office Automation")
        connection_close()
        'loop
    End Sub

    Private Sub GridRestore_CellContentDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles GridRestore.CellContentDoubleClick
        connection_open()
        Dim a = GridRestore.CurrentRow.Index
        txtid.Text = GridRestore.Item(0, a).Value.ToString
        connection_close()

    End Sub

    Private Sub linkback_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles linkback.LinkClicked
        connection_open()

        Employee_Details.Show()
        ds.Clear()
        '  Employee_Details.Grid.Rows.Clear()



        qry = "select * from Tbl_Employee where status ='False'"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_Employee")
        Employee_Details.Grid.DataSource = ds
        Employee_Details.Grid.DataMember = ds.Tables(0).ToString
        connection_close()


        Me.Close()
    End Sub

    Private Sub Employee_hidden_records_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connection_open()



        qry = "select * from Tbl_Employee where status='true'"
        ds.Clear()
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_Employee")
        GridRestore.DataSource = ds
        GridRestore.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub
End Class
    
