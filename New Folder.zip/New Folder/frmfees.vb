﻿Imports System.Data.SqlClient

Public Class frmfees
    Public payment
    Sub pay()
        If rdcomplete.Checked = True Then
            payment = "Complete"
        Else
            payment = "Partial"
        End If
    End Sub
    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        connection_close()
        connection_open()
        pay()
        qry1 = "update  Tbl_Feespayment set con_amt=" & txtcon.Text & ",tot_fee=" & txttot.Text & ",paid=" & txtpaid.Text & ",balance=" & txtbalance.Text & ",pay_type='" & payment & "' where regno=" & txtregno.Text & " and course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()
        view1()
        connection_close()
    End Sub

    Private Sub frmfees_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        cmbcourse.Text = "----- Select -----"
        cmbclass.Text = "----- Select -----"
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)
        Loop
        connection_close()
    End Sub

    Private Sub btnreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        cmbcourse.Text = "----- Select -----"
        cmbclass.Text = "----- Select -----"
        txtregno.Text = ""
        txtname.Text = ""
        txtdonation.Text = ""
        txttuition.Text = ""
        txtfee.Text = ""
        txttot.Text = ""
        txtpaid.Text = ""
        txtbalance.Text = ""
        rdpartial.Checked = False
        rdcomplete.Checked = False
    End Sub

   

    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        connection_open()
        Dim b
        b = Grid.CurrentRow.Index
        txtregno.Text = Grid.Item(0, b).Value.ToString
        txtname.Text = Grid.Item(1, b).Value.ToString
        txtdonation.Text = Grid.Item(2, b).Value.ToString
        txttuition.Text = Grid.Item(3, b).Value.ToString
        txtfee.Text = Grid.Item(4, b).Value.ToString
        txtcon.Text = Grid.Item(5, b).Value.ToString
        txttot.Text = Grid.Item(6, b).Value.ToString
        txtpaid.Text = Grid.Item(7, b).Value.ToString
        txtbalance.Text = Grid.Item(8, b).Value.ToString
        payment = Grid.Item(9, b).Value.ToString
        connection_close()
    End Sub

    Private Sub rdpartial_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdpartial.CheckedChanged
        lblbal.Enabled = True
        txtbalance.Enabled = True
    End Sub

    Private Sub rdcomplete_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdcomplete.CheckedChanged
        lblbal.Enabled = False
        txtbalance.Enabled = False
    End Sub

    Private Sub txtpaid_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtpaid.TextChanged
        Dim x
        Dim y
        Dim z
        x = txttot.Text
        y = txtpaid.Text
        z = Val(x) - Val(y)
        txtbalance.Text = Val(z)
    End Sub

    Private Sub cmbclass_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbclass.SelectedIndexChanged
        connection_open()
        'qry = "select donation,tuition,special,total from Tbl_Fees where course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
        'cmd = New SqlCommand(qry, cnn)
        'dr = cmd.ExecuteReader
        'Dim a = 0
        'Dim b = 0
        'Dim c = 0
        'Dim d = 0

        'If dr.Read = True Then
        '    a = dr(0).ToString
        '    b = dr(1).ToString
        '    c = dr(2).ToString
        '    d = dr(3).ToString
        'End If


        'txtdonation.Text = a
        'txttuition.Text = b
        'txtfee.Text = c
        'txttot.Text = d
        view1()
        connection_close()
    End Sub
    Public Sub view1()

        connection_close()
        connection_open()

        cmd = New SqlCommand("select * from Tbl_Feespayment where course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & "", cnn)

        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)

        Grid.Rows.Clear()
        Do While dr.Read = True
            Grid.Rows.Add(dr(2), dr(3), dr(4), dr(5), dr(6), dr(7), dr(8), dr(9), dr(10), dr(11))
        Loop
        connection_close()
    End Sub

    Private Sub txtcon_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtcon.TextChanged
        Dim t = 0
        Dim c = 0
        Dim tot = 0

        t = Val(txttot.Text)
        c = Val(txtcon.Text)
        tot = t - c
        txttot.Text = tot
    End Sub

End Class