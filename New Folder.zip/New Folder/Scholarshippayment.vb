﻿Imports System.Data.SqlClient

Public Class Scholarshippayment


    Private Sub btsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BTNADD.Click
        connection_open()
        qry = "select * from Tbl_scr_pay where name='" & txtname.Text & "' and course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & " and sch_name='" & cmbscholar.Text & "' and amount='" & txtamt.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        If dr.Read = False Then
            dr.Close()
            qry = "insert into Tbl_scr_pay (course,year,name,cast_grp,date,sch_name,amount) values('" & cmbcourse.Text & "'," & cmbclass.Text & ",'" & txtname.Text & "','" & txtcastgroup.Text & "','" & dt.Value & "','" & cmbscholar.Text & "'," & txtamt.Text & ")"
            cmd = New SqlCommand(qry, cnn)
            cmd.ExecuteNonQuery()
            MsgBox("Record Entered Successfully", MsgBoxStyle.Information, "Office Automation")
            view2()
            connection_close()
        Else
            MsgBox("Record already exists", MsgBoxStyle.Information, "Office Automation")
            cmbcourse.Focus()
            connection_close()
        End If
        connection_close()



    End Sub

    Private Sub Scholarshippayment_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_course()
        load_scholarship()
    End Sub
    Sub load_course()
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)

        Loop
        connection_close()
    End Sub

    Sub load_scholarship()
        connection_open()
        qry = "select Name from Tbl_scr"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbscholar.Items.Add(dr(0).ToString)
        Loop
        connection_close()
    End Sub


    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        connection_open()
        Dim a
        a = Grid.CurrentRow.Index
        txtname.Text = Grid.Item(0, a).Value.ToString
        txtcastgroup.Text = Grid.Item(1, a).Value.ToString
        connection_close()
    End Sub

    Sub view1()
        ds.Clear()
        Panel1.Visible = True
        Grid.Visible = True
        connection_open()

        qry = "select Name,Cast_grp from Tbl_std1 where Course='" & cmbcourse.Text & "' and Class=" & cmbclass.Text & ""
        adp = New SqlDataAdapter(qry, cnn)
        ds1.Clear()
        adp.Fill(ds, "Tbl_std1")

        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()

    End Sub
    Sub view2()
        ds1.Clear()
        Panel2.Visible = True
        gridview.Visible = True
        connection_open()

        qry = "select * from Tbl_scr_pay where course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
        adp = New SqlDataAdapter(qry, cnn)
        ds1.Clear()
        adp.Fill(ds1, "Tbl_scr_pay")

        gridview.DataSource = ds1
        gridview.DataMember = ds1.Tables(0).ToString
        connection_close()

    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click
        Panel2.Visible = False
        gridview.Visible = False
        view1()
    End Sub

    Private Sub view_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles view.Click
        Panel1.Visible = False
        Grid.Visible = False
        view2()

    End Sub
End Class