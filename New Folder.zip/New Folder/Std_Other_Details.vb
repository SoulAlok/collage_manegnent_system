﻿Imports System.Data.SqlClient
Public Class Std_Other_Details
    Private Sub Std_Other_Details_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        load_course()

    End Sub
   
    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles grid.DoubleClick

        connection_open()
        Dim b
        b = grid.CurrentRow.Index

        ad_txtregno.Text = grid.Item(0, b).Value.ToString
        ad_txtname.Text = grid.Item(1, b).Value.ToString
        connection_close()
    End Sub

    Private Sub btnview_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnview.Click
        'ds.Tables.Clear()
        connection_open()
        'grid.Visible = True
        'Panel1.Visible = True
        Panel2.Visible = True
        gridview.Visible = True

        ds1.Clear()
        qry = "select * from Tbl_st_other where course ='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds1, "Tbl_st_other")
        gridview.DataSource = ds1
        gridview.DataMember = ds1.Tables(0).ToString

        connection_close()



    End Sub

    Private Sub btreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click

        cmbcourse.Text = ""
        cmbclass.Text = ""
        ad_txtregno.Text = ""
        ad_txtname.Text = ""
        rchtxtcc.Text = ""
        rchtxtcc.Text = ""
        rchtxtintrasports.Text = ""
        rchtxtintersports.Text = ""
        rchtxtinterlitertr.Text = ""
        ds.Tables.Clear()
    End Sub
    Private Sub GridView_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles gridview.DoubleClick

        connection_open()
        Dim b
        b = gridview.CurrentRow.Index

        ad_txtregno.Text = gridview.Item(0, b).Value.ToString
        ad_txtname.Text = gridview.Item(1, b).Value.ToString
        cmbcourse.Text = gridview.Item(2, b).Value.ToString
        cmbclass.Text = gridview.Item(3, b).Value.ToString
        rchtxtcc.Text = gridview.Item(5, b).Value.ToString
        rchtxtec.Text = gridview.Item(6, b).Value.ToString
        rchtxtintrasports.Text = gridview.Item(7, b).Value.ToString
        rchtxtintersports.Text = gridview.Item(8, b).Value.ToString
        rchtxtinterlitertr.Text = gridview.Item(9, b).Value.ToString

    End Sub

    Private Sub btnok_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnok.Click

        'ds1.Tables.Clear()
        connection_open()
        Panel1.Visible = True
        grid.Visible = True
        'Panel1.Visible = True
        'Panel1.Enabled = True

        qry = "select regno,name from Tbl_Regno where course='" & cmbcourse.Text & "' and class=" & cmbclass.Text & ""

        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_Regno")
        grid.DataSource = ds
        grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub

    Private Sub btnadd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnadd.Click

        connection_open()

        qry = "select * from Tbl_st_other where regno=" & ad_txtregno.Text & ""
        cmd = New SqlCommand(qry, cnn)
        Dim dr As SqlDataReader
        dr = cmd.ExecuteReader
        If dr.Read = False Then
            dr.Close()
            qry = "insert into Tbl_st_other (course,year,regno,name,cc,ec,intra_sports,inter_sports,other) values('" & cmbcourse.Text & "'," & cmbclass.Text & "," & ad_txtregno.Text & ",'" & ad_txtname.Text & "','" & rchtxtcc.Text & "','" & rchtxtec.Text & "','" & rchtxtintrasports.Text & "','" & rchtxtintersports.Text & "','" & rchtxtinterlitertr.Text & "')"
            cmd = New SqlCommand(qry, cnn)
            cmd.ExecuteNonQuery()
            MsgBox("Record Entered Successfully", MsgBoxStyle.Information, "Office Automation")
            grid.Visible = False
            Panel1.Visible = False
            gridview.Visible = True
            Panel2.Visible = True

            ds.Clear()
            qry = "select * from Tbl_st_other where course='" & cmbcourse.Text & "' and year=" & cmbclass.Text & ""
            adp = New SqlDataAdapter(qry, cnn)
            adp.Fill(ds, "Tbl_st_other")
            gridview.DataSource = ds
            gridview.DataMember = ds.Tables(0).ToString
            connection_close()
        Else
            MsgBox("Record already exists", MsgBoxStyle.Information, "Office Automation")
            cmbcourse.Focus()
            connection_close()
        End If
        connection_close()
    End Sub

    Private Sub btnupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Panel2.Visible = True
        gridview.Visible = True


        connection_close()
        connection_open()
        qry1 = "update  Tbl_st_other set course='" & cmbcourse.Text & "',year='" & cmbclass.Text & "',name='" & ad_txtname.Text & "',cc='" & rchtxtcc.Text & "',ec='" & rchtxtec.Text & "',intra_sports='" & rchtxtintrasports.Text & "',inter_sports='" & rchtxtintersports.Text & "',other='" & rchtxtinterlitertr.Text & "' where regno=" & ad_txtregno.Text & ""
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()
        'grid fill
        qry = "select * from Tbl_st_other "
        adp = New SqlDataAdapter(qry, cnn)

        adp.Fill(ds, "Tbl_st_other")
        gridview.DataSource = ds
        gridview.DataMember = ds.Tables(0).ToString

        connection_close()


    End Sub

   
    Sub load_course()
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)
        Loop
        connection_close()
    End Sub

    
    Private Sub rchtxtintrasports_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles rchtxtintrasports.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(rchtxtintrasports.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub rchtxtintersports_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles rchtxtintersports.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(rchtxtintersports.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub rchtxtinterlitertr_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles rchtxtinterlitertr.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(rchtxtinterlitertr.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub rchtxtec_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles rchtxtec.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(rchtxtec.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub rchtxtcc_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles rchtxtcc.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(rchtxtcc.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub
End Class