﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Feespayment
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtregno = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.lblbal = New System.Windows.Forms.Label
        Me.txtfee = New System.Windows.Forms.TextBox
        Me.txtcon = New System.Windows.Forms.TextBox
        Me.txttot = New System.Windows.Forms.TextBox
        Me.txtpaid = New System.Windows.Forms.TextBox
        Me.txtbal = New System.Windows.Forms.TextBox
        Me.btadd = New System.Windows.Forms.Button
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.txttuition = New System.Windows.Forms.TextBox
        Me.txtdonation = New System.Windows.Forms.TextBox
        Me.rdpartial = New System.Windows.Forms.RadioButton
        Me.rdcomplete = New System.Windows.Forms.RadioButton
        Me.btupdate = New System.Windows.Forms.Button
        Me.btreset = New System.Windows.Forms.Button
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.Label4 = New System.Windows.Forms.Label
        Me.cmbcourse = New System.Windows.Forms.ComboBox
        Me.cmbclass = New System.Windows.Forms.ComboBox
        Me.butok = New System.Windows.Forms.Button
        Me.btnview = New System.Windows.Forms.Button
        Me.buttot = New System.Windows.Forms.Button
        Me.txtname = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.GridView = New System.Windows.Forms.DataGridView
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.GridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(31, 49)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(32, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Class"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(30, 133)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Reg No"
        '
        'txtregno
        '
        Me.txtregno.Location = New System.Drawing.Point(112, 126)
        Me.txtregno.Name = "txtregno"
        Me.txtregno.Size = New System.Drawing.Size(120, 20)
        Me.txtregno.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(25, 284)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(64, 13)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Fee Amount"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(25, 331)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(67, 13)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Conscession"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(26, 357)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 13)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Total Fees"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(22, 463)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(54, 13)
        Me.Label8.TabIndex = 11
        Me.Label8.Text = "Fees Paid"
        '
        'lblbal
        '
        Me.lblbal.AutoSize = True
        Me.lblbal.Enabled = False
        Me.lblbal.Location = New System.Drawing.Point(19, 506)
        Me.lblbal.Name = "lblbal"
        Me.lblbal.Size = New System.Drawing.Size(49, 13)
        Me.lblbal.TabIndex = 12
        Me.lblbal.Text = "Balance "
        '
        'txtfee
        '
        Me.txtfee.Location = New System.Drawing.Point(107, 277)
        Me.txtfee.Name = "txtfee"
        Me.txtfee.Size = New System.Drawing.Size(120, 20)
        Me.txtfee.TabIndex = 14
        '
        'txtcon
        '
        Me.txtcon.Location = New System.Drawing.Point(106, 324)
        Me.txtcon.Name = "txtcon"
        Me.txtcon.Size = New System.Drawing.Size(120, 20)
        Me.txtcon.TabIndex = 15
        Me.txtcon.Text = "0"
        '
        'txttot
        '
        Me.txttot.Location = New System.Drawing.Point(106, 357)
        Me.txttot.Name = "txttot"
        Me.txttot.Size = New System.Drawing.Size(120, 20)
        Me.txttot.TabIndex = 16
        '
        'txtpaid
        '
        Me.txtpaid.Location = New System.Drawing.Point(107, 460)
        Me.txtpaid.Name = "txtpaid"
        Me.txtpaid.Size = New System.Drawing.Size(120, 20)
        Me.txtpaid.TabIndex = 17
        '
        'txtbal
        '
        Me.txtbal.Enabled = False
        Me.txtbal.Location = New System.Drawing.Point(107, 503)
        Me.txtbal.Name = "txtbal"
        Me.txtbal.Size = New System.Drawing.Size(120, 20)
        Me.txtbal.TabIndex = 18
        '
        'btadd
        '
        Me.btadd.Location = New System.Drawing.Point(246, 558)
        Me.btadd.Name = "btadd"
        Me.btadd.Size = New System.Drawing.Size(75, 23)
        Me.btadd.TabIndex = 21
        Me.btadd.Text = "ADD"
        Me.btadd.UseVisualStyleBackColor = True
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(26, 217)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(50, 13)
        Me.Label11.TabIndex = 25
        Me.Label11.Text = "Donation"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(26, 251)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(65, 13)
        Me.Label12.TabIndex = 26
        Me.Label12.Text = "Tuition Fees"
        '
        'txttuition
        '
        Me.txttuition.Location = New System.Drawing.Point(107, 244)
        Me.txttuition.Name = "txttuition"
        Me.txttuition.Size = New System.Drawing.Size(120, 20)
        Me.txttuition.TabIndex = 27
        '
        'txtdonation
        '
        Me.txtdonation.Location = New System.Drawing.Point(107, 210)
        Me.txtdonation.Name = "txtdonation"
        Me.txtdonation.Size = New System.Drawing.Size(120, 20)
        Me.txtdonation.TabIndex = 28
        '
        'rdpartial
        '
        Me.rdpartial.AutoSize = True
        Me.rdpartial.Location = New System.Drawing.Point(19, 421)
        Me.rdpartial.Name = "rdpartial"
        Me.rdpartial.Size = New System.Drawing.Size(54, 17)
        Me.rdpartial.TabIndex = 29
        Me.rdpartial.Text = "Partial"
        Me.rdpartial.UseVisualStyleBackColor = True
        '
        'rdcomplete
        '
        Me.rdcomplete.AutoSize = True
        Me.rdcomplete.Checked = True
        Me.rdcomplete.Location = New System.Drawing.Point(112, 421)
        Me.rdcomplete.Name = "rdcomplete"
        Me.rdcomplete.Size = New System.Drawing.Size(69, 17)
        Me.rdcomplete.TabIndex = 30
        Me.rdcomplete.TabStop = True
        Me.rdcomplete.Text = "Complete"
        Me.rdcomplete.UseVisualStyleBackColor = True
        '
        'btupdate
        '
        Me.btupdate.Location = New System.Drawing.Point(327, 558)
        Me.btupdate.Name = "btupdate"
        Me.btupdate.Size = New System.Drawing.Size(75, 23)
        Me.btupdate.TabIndex = 31
        Me.btupdate.Text = "UPDATE"
        Me.btupdate.UseVisualStyleBackColor = True
        '
        'btreset
        '
        Me.btreset.Location = New System.Drawing.Point(489, 558)
        Me.btreset.Name = "btreset"
        Me.btreset.Size = New System.Drawing.Size(75, 23)
        Me.btreset.TabIndex = 32
        Me.btreset.Text = "RESET"
        Me.btreset.UseVisualStyleBackColor = True
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(24, 12)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(287, 177)
        Me.Grid.TabIndex = 33
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(649, 568)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(35, 13)
        Me.LinkLabel1.TabIndex = 35
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "BACK"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(26, 15)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 13)
        Me.Label4.TabIndex = 36
        Me.Label4.Text = "Course"
        '
        'cmbcourse
        '
        Me.cmbcourse.FormattingEnabled = True
        Me.cmbcourse.Location = New System.Drawing.Point(106, 12)
        Me.cmbcourse.Name = "cmbcourse"
        Me.cmbcourse.Size = New System.Drawing.Size(121, 21)
        Me.cmbcourse.TabIndex = 37
        '
        'cmbclass
        '
        Me.cmbclass.FormattingEnabled = True
        Me.cmbclass.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbclass.Location = New System.Drawing.Point(107, 41)
        Me.cmbclass.Name = "cmbclass"
        Me.cmbclass.Size = New System.Drawing.Size(121, 21)
        Me.cmbclass.TabIndex = 38
        '
        'butok
        '
        Me.butok.Location = New System.Drawing.Point(129, 78)
        Me.butok.Name = "butok"
        Me.butok.Size = New System.Drawing.Size(75, 23)
        Me.butok.TabIndex = 39
        Me.butok.Text = "OK"
        Me.butok.UseVisualStyleBackColor = True
        '
        'btnview
        '
        Me.btnview.Location = New System.Drawing.Point(408, 558)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 23)
        Me.btnview.TabIndex = 40
        Me.btnview.Text = "VIEW"
        Me.btnview.UseVisualStyleBackColor = True
        '
        'buttot
        '
        Me.buttot.Location = New System.Drawing.Point(29, 383)
        Me.buttot.Name = "buttot"
        Me.buttot.Size = New System.Drawing.Size(75, 23)
        Me.buttot.TabIndex = 41
        Me.buttot.Text = "TOTAL"
        Me.buttot.UseVisualStyleBackColor = True
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(112, 160)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(120, 20)
        Me.txtname.TabIndex = 5
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(30, 163)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Name"
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Grid)
        Me.Panel1.Location = New System.Drawing.Point(408, 22)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(326, 208)
        Me.Panel1.TabIndex = 42
        Me.Panel1.Visible = False
        '
        'Panel2
        '
        Me.Panel2.Controls.Add(Me.GridView)
        Me.Panel2.Location = New System.Drawing.Point(305, 336)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(495, 183)
        Me.Panel2.TabIndex = 43
        Me.Panel2.Visible = False
        '
        'GridView
        '
        Me.GridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.GridView.Location = New System.Drawing.Point(22, 21)
        Me.GridView.Name = "GridView"
        Me.GridView.Size = New System.Drawing.Size(452, 150)
        Me.GridView.TabIndex = 0
        '
        'Feespayment
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(843, 605)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.buttot)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.butok)
        Me.Controls.Add(Me.cmbclass)
        Me.Controls.Add(Me.cmbcourse)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.btreset)
        Me.Controls.Add(Me.btupdate)
        Me.Controls.Add(Me.rdcomplete)
        Me.Controls.Add(Me.rdpartial)
        Me.Controls.Add(Me.txtdonation)
        Me.Controls.Add(Me.txttuition)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btadd)
        Me.Controls.Add(Me.txtbal)
        Me.Controls.Add(Me.txtpaid)
        Me.Controls.Add(Me.txttot)
        Me.Controls.Add(Me.txtcon)
        Me.Controls.Add(Me.txtfee)
        Me.Controls.Add(Me.lblbal)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.txtregno)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Feespayment"
        Me.Text = "Feespayment"
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        CType(Me.GridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtregno As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents lblbal As System.Windows.Forms.Label
    Friend WithEvents txtfee As System.Windows.Forms.TextBox
    Friend WithEvents txtcon As System.Windows.Forms.TextBox
    Friend WithEvents txttot As System.Windows.Forms.TextBox
    Friend WithEvents txtpaid As System.Windows.Forms.TextBox
    Friend WithEvents txtbal As System.Windows.Forms.TextBox
    Friend WithEvents btadd As System.Windows.Forms.Button
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txttuition As System.Windows.Forms.TextBox
    Friend WithEvents txtdonation As System.Windows.Forms.TextBox
    Friend WithEvents rdpartial As System.Windows.Forms.RadioButton
    Friend WithEvents rdcomplete As System.Windows.Forms.RadioButton
    Friend WithEvents btupdate As System.Windows.Forms.Button
    Friend WithEvents btreset As System.Windows.Forms.Button
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmbcourse As System.Windows.Forms.ComboBox
    Friend WithEvents cmbclass As System.Windows.Forms.ComboBox
    Friend WithEvents butok As System.Windows.Forms.Button
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents buttot As System.Windows.Forms.Button
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents GridView As System.Windows.Forms.DataGridView
End Class
