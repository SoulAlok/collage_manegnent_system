﻿Imports System.Data.SqlClient

Public Class ScholarshipEntry

    Private Sub sclradd_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sclradd.Click
        connection_open()
        qry = "insert into Tbl_scr(Name,Amt) values ('" & txtname.Text & "'," & txtamt.Text & ")"
        If txtname.Text = "" Then
            MsgBox("Please Enter the Scholarship Name", MsgBoxStyle.Information, "Office Automation")

        ElseIf txtamt.Text = "" Then
            MsgBox("Please Enter Amount", MsgBoxStyle.Information, "Office Automation")
        Else
            qry1 = "select * from Tbl_scr where Name='" & txtname.Text & "'"
            cmd1 = New SqlCommand(qry1, cnn)
            dr = cmd1.ExecuteReader()
            If dr.Read = False Then
                cmd = New SqlCommand(qry, cnn)
                dr.Close()
                cmd.ExecuteNonQuery()
                MsgBox("Successfully Entered into the DataBase", MsgBoxStyle.MsgBoxRight, "Successful")
                'grid fill
                ds.Clear()


                qry = "select * from Tbl_scr"
                adp = New SqlDataAdapter(qry, cnn)

                adp.Fill(ds, "Tbl_scr")
                Grid.DataSource = ds
                Grid.DataMember = ds.Tables(0).ToString

                connection_close()
            End If
            connection_close()
        End If
    End Sub

    Private Sub sclrupdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sclrupdate.Click
        connection_open()

        qry1 = "update Tbl_scr set Amt=" & txtamt.Text & " where Name='" & txtname.Text & "'"
        cmd1 = New SqlCommand(qry1, cnn)
        cmd1.ExecuteNonQuery()
        MsgBox("Record Updated Sucessfully", MsgBoxStyle.MsgBoxRight, "Office Automation")
        ds.Clear()
        'grid fill
        qry = "select * from Tbl_scr"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_scr")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub

    Private Sub Grid_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Grid.DoubleClick
        Dim a
        a = Grid.CurrentRow.Index
        txtname.Text = Grid.Item(0, a).Value
        txtamt.Text = Grid.Item(1, a).Value
    End Sub

    Private Sub sclrreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sclrreset.Click
        txtname.Text = ""
        txtamt.Text = ""

    End Sub

    Private Sub ScholarshipEntry_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ds.Clear()
        connection_open()
        qry = "select * from Tbl_scr"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_scr")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub

    Private Sub sclrdelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles sclrdelete.Click
        connection_open()
        qry = "delete from Tbl_scr where Name='" & txtname.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        Dim g = MsgBox("Are you Sure you want to delete the record?", MsgBoxStyle.YesNoCancel, "Fill")
        If g = MsgBoxResult.Yes Then
            cmd.ExecuteNonQuery()
            MsgBox("Successfully Deleted the Record of  '" & txtname.Text & "' ", MsgBoxStyle.MsgBoxRight, "Deleted")
        Else

            MsgBox("Operation Aborted", MsgBoxStyle.AbortRetryIgnore, "Fill")


        End If
        ds.Clear()
        qry = "select * from Tbl_scr"
        adp = New SqlDataAdapter(qry, cnn)
        adp.Fill(ds, "Tbl_scr")
        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString

        connection_close()
    End Sub

    Private Sub txtname_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtname.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtname.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub

    Private Sub txtamt_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtamt.KeyPress
        If Char.IsDigit(e.KeyChar) Or Char.IsPunctuation(e.KeyChar) Then
            e.Handled = True
        Else
            If Len(txtamt.Text) < 25 Or Char.IsControl(e.KeyChar) Then
                e.Handled = False
            Else
                e.Handled = True
            End If
        End If
    End Sub
End Class