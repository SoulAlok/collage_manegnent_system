﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Otherdetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.butadd = New System.Windows.Forms.Button
        Me.butdelete = New System.Windows.Forms.Button
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.butupdate = New System.Windows.Forms.Button
        Me.butreset = New System.Windows.Forms.Button
        Me.LinkLabel1 = New System.Windows.Forms.LinkLabel
        Me.Label9 = New System.Windows.Forms.Label
        Me.cmbcourse = New System.Windows.Forms.ComboBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.Grid = New System.Windows.Forms.DataGridView
        Me.cmbclass = New System.Windows.Forms.ComboBox
        Me.cmbcompinter = New System.Windows.Forms.ComboBox
        Me.cmbcompintra = New System.Windows.Forms.ComboBox
        Me.cmbsports = New System.Windows.Forms.ComboBox
        Me.cmbother = New System.Windows.Forms.ComboBox
        Me.btnview = New System.Windows.Forms.Button
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtname = New System.Windows.Forms.TextBox
        Me.cmbextra = New System.Windows.Forms.ComboBox
        Me.cmbsclor = New System.Windows.Forms.ComboBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.TextBox1 = New System.Windows.Forms.TextBox
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(6, 141)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(111, 15)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Scholarship Details"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label2.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label2.Location = New System.Drawing.Point(12, 188)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(146, 15)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Extra Curricular Activities"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label3.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label3.Location = New System.Drawing.Point(6, 244)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(232, 15)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Participation in Inter-College Competition"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label4.Location = New System.Drawing.Point(0, 300)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(232, 15)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Participation in Intra-College Competition"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 11.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Underline), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label5.Location = New System.Drawing.Point(6, 344)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(151, 17)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Special Achievements"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label6.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label6.Location = New System.Drawing.Point(17, 389)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(41, 15)
        Me.Label6.TabIndex = 9
        Me.Label6.Text = "Sports"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.BackColor = System.Drawing.Color.DarkKhaki
        Me.Label7.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Label7.Location = New System.Drawing.Point(14, 422)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(90, 15)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Other Activities"
        '
        'butadd
        '
        Me.butadd.BackColor = System.Drawing.Color.White
        Me.butadd.ForeColor = System.Drawing.Color.Blue
        Me.butadd.Location = New System.Drawing.Point(204, 522)
        Me.butadd.Name = "butadd"
        Me.butadd.Size = New System.Drawing.Size(92, 38)
        Me.butadd.TabIndex = 16
        Me.butadd.Text = "ADD"
        Me.butadd.UseVisualStyleBackColor = False
        '
        'butdelete
        '
        Me.butdelete.BackColor = System.Drawing.Color.White
        Me.butdelete.ForeColor = System.Drawing.Color.Blue
        Me.butdelete.Location = New System.Drawing.Point(539, 513)
        Me.butdelete.Name = "butdelete"
        Me.butdelete.Size = New System.Drawing.Size(92, 38)
        Me.butdelete.TabIndex = 18
        Me.butdelete.Text = "DELETE"
        Me.butdelete.UseVisualStyleBackColor = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.office.My.Resources.Resources.otheractivities
        Me.PictureBox1.Location = New System.Drawing.Point(430, 18)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(215, 217)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 19
        Me.PictureBox1.TabStop = False
        '
        'butupdate
        '
        Me.butupdate.BackColor = System.Drawing.Color.White
        Me.butupdate.ForeColor = System.Drawing.Color.Blue
        Me.butupdate.Location = New System.Drawing.Point(322, 513)
        Me.butupdate.Name = "butupdate"
        Me.butupdate.Size = New System.Drawing.Size(92, 38)
        Me.butupdate.TabIndex = 20
        Me.butupdate.Text = "UPDATE"
        Me.butupdate.UseVisualStyleBackColor = False
        '
        'butreset
        '
        Me.butreset.BackColor = System.Drawing.Color.White
        Me.butreset.ForeColor = System.Drawing.Color.Blue
        Me.butreset.Location = New System.Drawing.Point(662, 513)
        Me.butreset.Name = "butreset"
        Me.butreset.Size = New System.Drawing.Size(92, 38)
        Me.butreset.TabIndex = 21
        Me.butreset.Text = "RESET"
        Me.butreset.UseVisualStyleBackColor = False
        '
        'LinkLabel1
        '
        Me.LinkLabel1.AutoSize = True
        Me.LinkLabel1.Location = New System.Drawing.Point(713, 575)
        Me.LinkLabel1.Name = "LinkLabel1"
        Me.LinkLabel1.Size = New System.Drawing.Size(41, 15)
        Me.LinkLabel1.TabIndex = 22
        Me.LinkLabel1.TabStop = True
        Me.LinkLabel1.Text = "BACK"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(6, 46)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(45, 15)
        Me.Label9.TabIndex = 23
        Me.Label9.Text = "Course"
        '
        'cmbcourse
        '
        Me.cmbcourse.FormattingEnabled = True
        Me.cmbcourse.Location = New System.Drawing.Point(244, 43)
        Me.cmbcourse.Name = "cmbcourse"
        Me.cmbcourse.Size = New System.Drawing.Size(180, 23)
        Me.cmbcourse.TabIndex = 24
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(14, 82)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(36, 15)
        Me.Label10.TabIndex = 26
        Me.Label10.Text = "Class"
        '
        'Grid
        '
        Me.Grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Grid.Location = New System.Drawing.Point(443, 269)
        Me.Grid.Name = "Grid"
        Me.Grid.Size = New System.Drawing.Size(292, 150)
        Me.Grid.TabIndex = 28
        '
        'cmbclass
        '
        Me.cmbclass.FormattingEnabled = True
        Me.cmbclass.Items.AddRange(New Object() {"1", "2", "3"})
        Me.cmbclass.Location = New System.Drawing.Point(244, 74)
        Me.cmbclass.Name = "cmbclass"
        Me.cmbclass.Size = New System.Drawing.Size(121, 23)
        Me.cmbclass.TabIndex = 31
        '
        'cmbcompinter
        '
        Me.cmbcompinter.FormattingEnabled = True
        Me.cmbcompinter.Location = New System.Drawing.Point(244, 236)
        Me.cmbcompinter.Name = "cmbcompinter"
        Me.cmbcompinter.Size = New System.Drawing.Size(121, 23)
        Me.cmbcompinter.TabIndex = 32
        '
        'cmbcompintra
        '
        Me.cmbcompintra.FormattingEnabled = True
        Me.cmbcompintra.Location = New System.Drawing.Point(244, 292)
        Me.cmbcompintra.Name = "cmbcompintra"
        Me.cmbcompintra.Size = New System.Drawing.Size(121, 23)
        Me.cmbcompintra.TabIndex = 33
        '
        'cmbsports
        '
        Me.cmbsports.FormattingEnabled = True
        Me.cmbsports.Location = New System.Drawing.Point(220, 370)
        Me.cmbsports.Name = "cmbsports"
        Me.cmbsports.Size = New System.Drawing.Size(121, 23)
        Me.cmbsports.TabIndex = 34
        '
        'cmbother
        '
        Me.cmbother.FormattingEnabled = True
        Me.cmbother.Location = New System.Drawing.Point(220, 414)
        Me.cmbother.Name = "cmbother"
        Me.cmbother.Size = New System.Drawing.Size(121, 23)
        Me.cmbother.TabIndex = 35
        '
        'btnview
        '
        Me.btnview.Location = New System.Drawing.Point(430, 513)
        Me.btnview.Name = "btnview"
        Me.btnview.Size = New System.Drawing.Size(75, 38)
        Me.btnview.TabIndex = 36
        Me.btnview.Text = "VIEW"
        Me.btnview.UseVisualStyleBackColor = True
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(17, 109)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(38, 15)
        Me.Label8.TabIndex = 37
        Me.Label8.Text = "Name"
        '
        'txtname
        '
        Me.txtname.Location = New System.Drawing.Point(244, 109)
        Me.txtname.Name = "txtname"
        Me.txtname.Size = New System.Drawing.Size(100, 21)
        Me.txtname.TabIndex = 38
        '
        'cmbextra
        '
        Me.cmbextra.FormattingEnabled = True
        Me.cmbextra.Location = New System.Drawing.Point(244, 185)
        Me.cmbextra.Name = "cmbextra"
        Me.cmbextra.Size = New System.Drawing.Size(160, 23)
        Me.cmbextra.TabIndex = 39
        '
        'cmbsclor
        '
        Me.cmbsclor.FormattingEnabled = True
        Me.cmbsclor.Location = New System.Drawing.Point(244, 141)
        Me.cmbsclor.Name = "cmbsclor"
        Me.cmbsclor.Size = New System.Drawing.Size(160, 23)
        Me.cmbsclor.TabIndex = 40
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 9)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(42, 15)
        Me.Label12.TabIndex = 29
        Me.Label12.Text = "RegNo"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(220, 6)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(180, 21)
        Me.TextBox1.TabIndex = 30
        '
        'Otherdetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkKhaki
        Me.ClientSize = New System.Drawing.Size(808, 642)
        Me.Controls.Add(Me.cmbsclor)
        Me.Controls.Add(Me.cmbextra)
        Me.Controls.Add(Me.txtname)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnview)
        Me.Controls.Add(Me.cmbother)
        Me.Controls.Add(Me.cmbsports)
        Me.Controls.Add(Me.cmbcompintra)
        Me.Controls.Add(Me.cmbcompinter)
        Me.Controls.Add(Me.cmbclass)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Grid)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.cmbcourse)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.LinkLabel1)
        Me.Controls.Add(Me.butreset)
        Me.Controls.Add(Me.butupdate)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.butdelete)
        Me.Controls.Add(Me.butadd)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Times New Roman", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.Name = "Otherdetails"
        Me.Text = "Otherdetails"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Grid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents butadd As System.Windows.Forms.Button
    Friend WithEvents butdelete As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents butupdate As System.Windows.Forms.Button
    Friend WithEvents butreset As System.Windows.Forms.Button
    Friend WithEvents LinkLabel1 As System.Windows.Forms.LinkLabel
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents cmbcourse As System.Windows.Forms.ComboBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Grid As System.Windows.Forms.DataGridView
    Friend WithEvents cmbclass As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcompinter As System.Windows.Forms.ComboBox
    Friend WithEvents cmbcompintra As System.Windows.Forms.ComboBox
    Friend WithEvents cmbsports As System.Windows.Forms.ComboBox
    Friend WithEvents cmbother As System.Windows.Forms.ComboBox
    Friend WithEvents btnview As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtname As System.Windows.Forms.TextBox
    Friend WithEvents cmbextra As System.Windows.Forms.ComboBox
    Friend WithEvents cmbsclor As System.Windows.Forms.ComboBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
