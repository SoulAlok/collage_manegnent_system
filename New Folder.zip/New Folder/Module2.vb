﻿Imports System.Data.SqlClient

Module Module2
    Public Sub connection_open()

        connetionString = "Data Source=SVS-PC;Initial Catalog=SAM_OFFICEAUTOMATION;Integrated Security=True"
        cnn = New SqlConnection(connetionString)
        Try
            cnn.Open()
        Catch ex As Exception
            MsgBox("Can not open connection ! ")
        End Try

    End Sub
    Public Sub connection_close()
        cnn.Close()
    End Sub
End Module
