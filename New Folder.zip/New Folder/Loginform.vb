﻿Imports System.Data.SqlClient
Public Class Loginform

    Sub clear()
        cmbuser.Text = ""
        txtuser.Text = ""
        txtpasswd.Text = ""
    End Sub
    Private Sub btnreset_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnreset.Click
        clear()

    End Sub

    Private Sub btnlogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnlogin.Click
        connection_open()
        qry = "select * from TableLogin where usertype='" & cmbuser.Text & "' and username='" & txtuser.Text & "' and password= '" & txtpasswd.Text & "'"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader()
        If dr.Read = True Then
            MsgBox("login successful", MsgBoxStyle.Information, "login")
            Me.Hide()
            connection_close()

        Else
            MsgBox("Invalid Username/Password", MsgBoxStyle.Critical, "failure")
            connection_close()

        End If
    End Sub

    

    'Private Sub cmbuser_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbuser.SelectedIndexChanged
    '    If cmbuser.Text = "ADMIN" Then

    '    End If
    'End Sub

    'Private Sub login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


    Private Sub Loginform_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnexit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnexit.Click
        End
    End Sub
End Class
