﻿Imports System.Data.SqlClient
Public Class Search_Coursewise

    Private Sub Search_Coursewise_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        connection_open()
        qry = "select C_Name from Tbl_crs"
        cmd = New SqlCommand(qry, cnn)
        dr = cmd.ExecuteReader
        Do While dr.Read = True
            cmbcourse.Items.Add(dr(0).ToString)
        Loop
        connection_close()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        connection_open()
        qry = "select Name,Course,Class from Tbl_std1 where Course='" & cmbcourse.Text & "'"
        adp = New SqlDataAdapter(qry, cnn)
        ds.Clear()
        adp.Fill(ds, "Tbl_std1")

        Grid.DataSource = ds
        Grid.DataMember = ds.Tables(0).ToString
        connection_close()
    End Sub
End Class