﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ResultReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label4 = New System.Windows.Forms.Label
        Me.repcourse = New System.Windows.Forms.ListBox
        Me.repsem = New System.Windows.Forms.ListBox
        Me.repexm = New System.Windows.Forms.ListBox
        Me.repregno = New System.Windows.Forms.ListBox
        Me.shmksheet = New System.Windows.Forms.Button
        Me.rfmksheet = New System.Windows.Forms.Button
        Me.clrmksheet = New System.Windows.Forms.Button
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.GroupBox1.SuspendLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.repregno)
        Me.GroupBox1.Controls.Add(Me.repexm)
        Me.GroupBox1.Controls.Add(Me.repsem)
        Me.GroupBox1.Controls.Add(Me.repcourse)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(28, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(765, 112)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Generate marksheet"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(22, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(40, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Course"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(187, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Semester"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(393, 34)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Exam"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(592, 34)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(39, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Regno"
        '
        'repcourse
        '
        Me.repcourse.FormattingEnabled = True
        Me.repcourse.Items.AddRange(New Object() {"BA", "BCOM", "BSC", "BCA", "BBM"})
        Me.repcourse.Location = New System.Drawing.Point(61, 34)
        Me.repcourse.Name = "repcourse"
        Me.repcourse.Size = New System.Drawing.Size(120, 30)
        Me.repcourse.TabIndex = 4
        '
        'repsem
        '
        Me.repsem.FormattingEnabled = True
        Me.repsem.Items.AddRange(New Object() {"I SEM", "II SEM", "III SEM", "IV SEM", "V SEM", "VI SEM"})
        Me.repsem.Location = New System.Drawing.Point(267, 34)
        Me.repsem.Name = "repsem"
        Me.repsem.Size = New System.Drawing.Size(120, 30)
        Me.repsem.TabIndex = 5
        '
        'repexm
        '
        Me.repexm.FormattingEnabled = True
        Me.repexm.Items.AddRange(New Object() {"1st INTERNAL", "2nd INTERNAL", "SEMESTER"})
        Me.repexm.Location = New System.Drawing.Point(459, 35)
        Me.repexm.Name = "repexm"
        Me.repexm.Size = New System.Drawing.Size(120, 30)
        Me.repexm.TabIndex = 6
        '
        'repregno
        '
        Me.repregno.FormattingEnabled = True
        Me.repregno.Location = New System.Drawing.Point(634, 34)
        Me.repregno.Name = "repregno"
        Me.repregno.Size = New System.Drawing.Size(120, 30)
        Me.repregno.TabIndex = 7
        '
        'shmksheet
        '
        Me.shmksheet.Location = New System.Drawing.Point(53, 171)
        Me.shmksheet.Name = "shmksheet"
        Me.shmksheet.Size = New System.Drawing.Size(155, 23)
        Me.shmksheet.TabIndex = 1
        Me.shmksheet.Text = "SHOWMARKSHEET"
        Me.shmksheet.UseVisualStyleBackColor = True
        '
        'rfmksheet
        '
        Me.rfmksheet.Location = New System.Drawing.Point(281, 171)
        Me.rfmksheet.Name = "rfmksheet"
        Me.rfmksheet.Size = New System.Drawing.Size(185, 23)
        Me.rfmksheet.TabIndex = 2
        Me.rfmksheet.Text = "REFRESHMARKSHEET"
        Me.rfmksheet.UseVisualStyleBackColor = True
        '
        'clrmksheet
        '
        Me.clrmksheet.Location = New System.Drawing.Point(532, 171)
        Me.clrmksheet.Name = "clrmksheet"
        Me.clrmksheet.Size = New System.Drawing.Size(114, 23)
        Me.clrmksheet.TabIndex = 3
        Me.clrmksheet.Text = "CLEARMRAKSHEET"
        Me.clrmksheet.UseVisualStyleBackColor = True
        '
        'DataGridView1
        '
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Location = New System.Drawing.Point(6, 254)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(776, 96)
        Me.DataGridView1.TabIndex = 4
        '
        'ResultReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(805, 362)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.clrmksheet)
        Me.Controls.Add(Me.rfmksheet)
        Me.Controls.Add(Me.shmksheet)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "ResultReport"
        Me.Text = "ResultReport"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents repexm As System.Windows.Forms.ListBox
    Friend WithEvents repsem As System.Windows.Forms.ListBox
    Friend WithEvents repcourse As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents repregno As System.Windows.Forms.ListBox
    Friend WithEvents shmksheet As System.Windows.Forms.Button
    Friend WithEvents rfmksheet As System.Windows.Forms.Button
    Friend WithEvents clrmksheet As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
End Class
